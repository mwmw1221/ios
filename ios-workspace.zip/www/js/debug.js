(function () {
    // ----------------------------------------------------
    // 1. TWORZENIE GŁÓWNYCH ELEMENTÓW
    // ----------------------------------------------------
    const logBox = document.createElement('div');
    logBox.id = 'page-console-log';
    
    // Kontener na treść logów (to się przewija)
    const logContent = document.createElement('div');
    logContent.id = 'page-log-content';
    logContent.style.maxHeight = '35vh'; 
    logContent.style.overflowY = 'auto'; 
    logBox.appendChild(logContent);

    // 2. TWORZENIE I STYLOWANIE KONTROLEK
    const controls = document.createElement('div');
    controls.style.display = 'flex';
    controls.style.gap = '10px'; // Odstęp między grupami przycisków
    controls.style.marginTop = '5px';
    
    // Grupa przewijania
    const scrollControls = document.createElement('div');
    scrollControls.style.display = 'flex';
    scrollControls.style.flexGrow = 1;

    const upButton = document.createElement('button');
    upButton.textContent = '▲ Góra';
    upButton.style.cssText = 'padding: 5px; cursor: pointer; background: #555; color: white; border: none; flex-grow: 1; margin-right: 5px;';

    const downButton = document.createElement('button');
    downButton.textContent = '▼ Dół';
    downButton.style.cssText = 'padding: 5px; cursor: pointer; background: #555; color: white; border: none; flex-grow: 1; margin-left: 5px;';
    
    scrollControls.appendChild(upButton);
    scrollControls.appendChild(downButton);
    controls.appendChild(scrollControls);

    // Przycisk Pokaż/Ukryj
    const toggleButton = document.createElement('button');
    toggleButton.textContent = 'Ukryj'; // Domyślnie widoczny, więc przycisk ma tekst 'Ukryj'
    toggleButton.style.cssText = 'padding: 5px; cursor: pointer; background: #007bff; color: white; border: none; width: 100px;';
    controls.appendChild(toggleButton);

    logBox.appendChild(controls); // Dodaj kontrolki do głównego bloku

    // 3. STYLOWANIE GŁÓWNEGO KONTENERA LOGÓW
    logBox.style.cssText = `
        position: fixed;
        bottom: 10px;
        right: 10px;
        width: 400px; /* Nieco szerszy, żeby pomieścić wszystkie przyciski */
        background: rgba(0, 0, 0, 0.9);
        color: white;
        padding: 10px;
        border: 2px solid #333;
        font-family: monospace;
        font-size: 12px;
        z-index: 99999;
        pointer-events: all; 
        transition: height 0.3s, opacity 0.3s;
    `;
    
    // Dodajemy główny kontener do body
    if (document.body) {
         document.body.appendChild(logBox);
    } else {
         // Na wypadek, gdyby skrypt nie miał defer, używamy DOMContentLoaded
         document.addEventListener('DOMContentLoaded', () => document.body.appendChild(logBox));
    }

    // ----------------------------------------------------
    // 4. LOGIKA POKAŻ/UKRYJ
    // ----------------------------------------------------
    let isVisible = true;
    
    toggleButton.onclick = function() {
        isVisible = !isVisible;
        
        // Ukryj/Pokaż treść logów i kontrolki przewijania
        logContent.style.display = isVisible ? 'block' : 'none';
        scrollControls.style.display = isVisible ? 'flex' : 'none';
        
        // Zmień tekst przycisku
        toggleButton.textContent = isVisible ? 'Ukryj' : 'Pokaż';
        
        // Zmień kolor przycisku po ukryciu
        toggleButton.style.backgroundColor = isVisible ? '#007bff' : '#28a745';
        
        // Zmień wysokość głównego bloku, aby zajmował tylko przycisk Pokaż
        logBox.style.height = isVisible ? '' : (controls.offsetHeight + 20) + 'px';
    };

    // 5. FUNKCJE I LOGIKA PRZEWIJANIA (bez zmian)
    const scrollAmount = 50; 
    
    upButton.onclick = function() {
        logContent.scrollTop -= scrollAmount;
    };
    
    downButton.onclick = function() {
        logContent.scrollTop += scrollAmount;
    };

    function appendLog(type, message, color) {
        const entry = document.createElement('p');
        entry.style.margin = '2px 0';
        entry.style.padding = '0';
        entry.style.color = color;
        entry.innerHTML = `**[${type.toUpperCase()}]**: ${message}`;
        
        logContent.appendChild(entry); 
        logContent.scrollTop = logContent.scrollHeight;
    }
    
    // 6. PRZECHWYTYWANIE KONTYNUACJA (bez zmian)
    const originalConsoleLog = console.log;
    const originalConsoleError = console.error;
    const originalConsoleWarn = console.warn;

    console.log = function (...args) {
        const message = args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ');
        appendLog('log', message, '#00ff00');
        originalConsoleLog.apply(console, args);
    };

    console.error = function (...args) {
        const message = args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ');
        appendLog('error', message, '#ff4d4d');
        originalConsoleError.apply(console, args);
    };

    console.warn = function (...args) {
        const message = args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ');
        appendLog('warn', message, '#ffff66');
        originalConsoleWarn.apply(console, args);
    };
    
    // Przechwytywanie globalnych błędów JS (synchronicznych)
    window.onerror = function (message, source, lineno, colno, error) {
        const errorText = `${message} (${source}:${lineno}:${colno})`;
        appendLog('GLOBAL_ERROR', errorText, '#ff4d4d');
        return false;
    };

    // Przechwytywanie nieobsłużonych odrzuceń obietnic (asynchronicznych błędów fetch/Promise)
    window.addEventListener('unhandledrejection', function(event) {
        let reason = event.reason;
        let message = 'Unhandled Promise Rejection';
        let errorDetails = '';

        if (reason instanceof Error) {
            errorDetails = reason.message;
        } else if (typeof reason === 'string') {
            errorDetails = reason;
        } else if (reason && typeof reason.message === 'string') {
            errorDetails = reason.message;
        } else {
            errorDetails = JSON.stringify(reason);
        }

        appendLog('PROMISE_REJECT', `${message}: ${errorDetails}`, '#ffaa00');
    });

})();