angular.module('app.services')
    .factory('NewHuntService', [
        "$http",
        "$state",
        "$q",
        "$cordovaToast",
        "ApiEndpoint",
        "Session",
        function (
            $http,
            $state,
            $q,
            $cordovaToast,
            ApiEndpoint,
            Session
        ) {
            // var permitsList;

            return {
                getPermitsList: function () {
                    return Session.request("getAllPermits", { cId: circuitId })
                        .then(function (result) {
                            return result.data.permits;
                        });
                },
                getAllPermits: function (osobyId, type) {
                    return Session.request("getAllPermits", { osobyId: osobyId, type: type })
                        .then(function (result) {
                            return result.data.permits;
                        });
                },
                getAllPermitsForCheckbox: function (osobyId, type) {
                    return Session.request("getAllPermits", { osobyId: osobyId, type: type })
                        .then(function (result) {
                            var permitObject = new Array();

                            var permits = result.data.permits;
                            for (var i = 0; i < permits.length; i++) {
                                permitObject.push({
                                    id: permits[i][0],
                                    permitNumber: permits[i][1],
                                    number: permits[i][2],
                                    name: permits[i][3],
                                    name2: permits[i][4],
                                    circuitId: permits[i][5],
                                    t1: permits[i][6],
                                    t2: permits[i][7]
                                });
                            }
                            return permitObject;
                        });
                },
                getDistrictsList: function (circuitId) {
                    return Session.request("getDistricts", { cId: circuitId })
                        .then(function (result) {
                            return result.data.districts;
                        });
                },
                getEquipmentList: function (circuitId) {
                    return Session.request("getEquipment", { cId: circuitId })
                        .then(function (result) {
                            return result.data.equipment;
                        });
                },
                addHunt: function (data) {
                    return Session.request("addHunt", data)
                        .then(function (result) {
                            return result.data;
                        }, function(err) {
                            return err;
                        })
                },
                getAnotherHunters: function (circuitId) {
                    return Session.request("getAnotherHunters", { obwId: circuitId })
                        .then(function (result) {
                            return result.data.anotherHunter;
                        })
                },
                getAnotherHuntersForSelect: function () {
                    return Session.request("getAnotherHunters")
                        .then(function (result) {
                            return result.data;
                        })
                },
                checkDistrictOccupied: function (data) {
                    return Session.request("checkDistrictOccupied", data)
                        .then(function (result) {
                            return result.data;
                        })
                }
            }
        }]);