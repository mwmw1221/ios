angular.module('app.services')
    .factory('CircuitsMapService', [
        "$http",
        "$state",
        "$q",
        "$cordovaToast",
        "ApiEndpoint",
        "LocalStorage",
        "Session",
        function (
            $http,
            $state,
            $q,
            $cordovaToast,
            ApiEndpoint,
            LocalStorage,
            Session
        ) {
            var registerTypes;


            return {
                getCircuitMap: function (circuitId) {
                    return Session.request("getCircuitMap", { cId: circuitId })
                        .then(function (result) {
                            return result;
                        });
                },
                getDistrictPolygons: function (circuitId, districtId) {
                    return Session.request("getDistrictPolygons", { cId: circuitId, districtId: districtId })
                        .then(function (result) {
                            return result;
                        })
                },
                getRegisterTypes: function () {
                    return this.registerTypes;
                },
                setRegisterTypes: function (registerTypes) {
                    this.registerTypes = registerTypes;
                },
                getRegisterTypesList: function () {
                    return Session.request("getRegisterTypes")
                        .then(function (result) {
                            return result.data.types;
                        })
                },
                getRegistersDataNew: function (circuitId, typId) {
                    return Session.request("getRegistersDataNew", { cId: circuitId, typId: typId })
                        .then(function (result) {
                            return result.data.register;
                        })
                },
                getCarPosition: function () {
                    return Session.request("getCarPosition")
                        .then(function (result) {
                            return result.data;
                        })
                },
                setCarPosition: function (lng, lat) {
                    return Session.request("setCarPosition", { longitude: lng, latitude: lat })
                        .then(function (result) {
                            return result.data;
                        })
                },
                setCarPosition: function (lng, lat) {
                    return Session.request("setCarPosition", { longitude: lng, latitude: lat })
                        .then(function (result) {
                            return result.data;
                        })
                },
                getTtxBox: function () {
                    return Session.request("getTtxBox")
                        .then(function (result) {
                            return result.data;
                        })
                },
                getTtxBoxPosition: function (boxId) {
                    return Session.request('getTtxBoxPosition', { boxId: boxId })
                        .then(function (result) {
                            return result.data;
                        })
                },
                getHuntersPosition: function(circuitId) {
                    return Session.request('getHuntersPosition', { circuitId: circuitId })
                        .then(function (result) {
                            return result.data;
                        })
                }
            }
        }]);