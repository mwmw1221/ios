angular.module('app.services')
    .factory('MyPermissionsService', [
        "$http",
        "$state",
        "$q",
        "$cordovaToast",
        "ApiEndpoint",
        "Session",
        function (
            $http,
            $state,
            $q,
            $cordovaToast,
            ApiEndpoint,
            Session
        ) {
            return {
                getMyPermissionsList: function (year) {
                    return Session.request("getMyPermits", {year: year})
                        .then(function (result) {
                            return result.data.permits;
                        });
                },
                getMyPermissionAnimals: function (id) {
                    return Session.request("getMyPermitAnimal", {permitId: id})
                        .then(function (result) {
                            return result.data.animals;
                        });
                }
            }
        }]);