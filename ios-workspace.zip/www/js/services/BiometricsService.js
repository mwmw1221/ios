angular.module('app.services')
    .factory('BiometricsService', [
        "$q",
        "LocalStorage",
        function (
            $q,
            LocalStorage
        ) {
            const BIOMETRICS_ENABLED_PREFIX = 'biometricsEnabled_';
            const BIOMETRICS_AUTOLOGIN_PREFIX = 'biometricsAutologin_';

            return {
                // Sprawdza czy urządzenie ma biometrię
                isBiometricsAvailable: function() {
                    var deferred = $q.defer();
                    
                    // Sprawdzaj czy plugin jest dostępny
                    if (typeof window.Fingerprint === 'undefined') {
                        console.log("Fingerprint plugin nie dostępny");
                        deferred.resolve(false);
                        return deferred.promise;
                    }

                    window.Fingerprint.isAvailable(
                        function(result) {
                            console.log("Biometria dostępna, typ:", result);
                            // result może być 'finger', 'face' lub inne
                            deferred.resolve(true);
                        },
                        function(error) {
                            console.error("Błąd podczas sprawdzania biometrii:", error);
                            deferred.resolve(false);
                        }
                    );

                    return deferred.promise;
                },

                // Sprawdza czy biometria jest włączona dla danego użytkownika
                isBiometricsEnabled: function(login) {
                    if (!login) return false;
                    var enabled = LocalStorage.get(BIOMETRICS_ENABLED_PREFIX + login);
                    return enabled === 'true' || enabled === true;
                },

                // Sprawdza czy autologin biometrią jest włączony dla danego użytkownika
                isAutologinEnabled: function(login) {
                    if (!login) return false;
                    var enabled = LocalStorage.get(BIOMETRICS_AUTOLOGIN_PREFIX + login);
                    return enabled === 'true' || enabled === true;
                },

                // Włącza biometrię dla danego użytkownika
                enableBiometrics: function(login) {
                    if (!login) return;
                    LocalStorage.set(BIOMETRICS_ENABLED_PREFIX + login, 'true');
                    console.log("Biometria włączona dla:", login);
                },

                // Wyłącza biometrię dla danego użytkownika
                disableBiometrics: function(login) {
                    if (!login) return;
                    LocalStorage.set(BIOMETRICS_ENABLED_PREFIX + login, 'false');
                    console.log("Biometria wyłączona dla:", login);
                },

                // Włącza/wyłącza autologin biometrią dla użytkownika
                setAutologin: function(login, enabled) {
                    if (!login) return;
                    LocalStorage.set(BIOMETRICS_AUTOLOGIN_PREFIX + login, enabled ? 'true' : 'false');
                    console.log("Autologin biometrią ustawiony dla:", login, enabled);
                },

                // Sprawdza biometrię
                authenticate: function(reason) {
                    var deferred = $q.defer();
                    
                    if (typeof window.Fingerprint === 'undefined') {
                        deferred.reject("Fingerprint plugin nie dostępny");
                        return deferred.promise;
                    }

                    var options = {
                        description: reason || "Uwierzytelnij się biometrią",
                        fallbackButtonTitle: "Użyj PIN-u"
                    };

                    window.Fingerprint.show(options,
                        function(result) {
                            console.log("Biometria potwierdzona");
                            deferred.resolve(true);
                        },
                        function(error) {
                            console.error("Błąd biometrii:", error);
                            // Obsługa poszczególnych błędów
                            var errorMsg = typeof error === 'string' ? error : (error && error.message) || error;
                            
                            if (errorMsg.indexOf('Cancelled') > -1 || errorMsg.indexOf('cancelled') > -1) {
                                deferred.reject("Anulowano");
                            } else {
                                deferred.reject(errorMsg);
                            }
                        }
                    );

                    return deferred.promise;
                }
            };
        }
    ]);
