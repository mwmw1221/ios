angular.module('app.services')
    .factory('OhzDemandService', [
        "Session",
        function (
            Session
        ) {
            return {
                getDemandZG: function () {
                    return Session.request("getDemandZG")
                        .then(function (result) {
                            return result.data.demandList;
                        });
                },
                getDemandZGInfo: function (id) {
                    return Session.request("getDemandZGInfo", { demandId: id })
                        .then(function (result) {
                            return result.data;
                        });
                },
                setDemandZGDecision(demandId, decision) {
                    return Session.request("setDemandZGDecision", { demandId: demandId, decision: decision })
                        .then(function (result) {
                            return result.data;
                        })
                }
            }
        }]);