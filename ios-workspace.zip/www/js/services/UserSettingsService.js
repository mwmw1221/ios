angular.module('app.services')
    .factory('UserSettingsService', [
        "Session",
        function (
            Session
        ) {
            return {

                getUserSettings: function () {
                    return Session.request("getUserSettings")
                        .then(function (result) {
                            return result.data.settings
                        });
                },
                saveUserSettings: function (values) {
                    var convertedToMap = new Map(values.map(i => [i.CODE, i.VAL]));
                    var convertedToString = [...convertedToMap].map(([key, value]) => `${key}:${value}`).join(', ');
                    var data = '{' + convertedToString + '}';

                    return Session.request("saveUserSettings", { values: data })
                        .then(function (result) {
                            return result.data;
                        });
                },
                setLanguage: function (lang) {
                    return Session.request("setLanguage", { lang: lang })
                        .then(function (result) {
                            return result
                        });
                }
            }
        }]);