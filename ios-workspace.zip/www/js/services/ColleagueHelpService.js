angular.module('app.services')
    .factory('ColleagueHelpService', [
        "$http",
        "$state",
        "$q",
        "$cordovaToast",
        "ApiEndpoint",
        "Session",
        function (
            $http,
            $state,
            $q,
            $cordovaToast,
            ApiEndpoint,
            Session
        ) {
            return {
                getColleagueHelp: function () {
                    return Session.request("getColeageHelp")
                        .then(function (result) {
                            return result.data.persons;
                        });
                }
            }
        }]);