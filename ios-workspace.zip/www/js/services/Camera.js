angular.module('app.services')
    .factory('Camera', [
        "$q",
        "Session",
        "ApiEndpoint",
        "$cordovaFileTransfer",
        "$base64",
        "$ionicLoading",
        function (
            $q,
            Session,
            ApiEndpoint,
            $cordovaFileTransfer,
            $base64,
            $ionicLoading
        ) {
            var huntingId;
            var animalId;

            var PHOTO_OPTIONS = {
                quality: 80,
                destinationType: navigator.camera.DestinationType.FILE_URI,
                encodingType:  navigator.camera.EncodingType.JPEG,
                targetHeight: 1000
            };

            return {
                getPicture: function (source) {
                    PHOTO_OPTIONS.sourceType = source;
                    var q = $q.defer();
            
                    navigator.camera.getPicture(
                        function (result) {
                            if(PHOTO_OPTIONS.sourceType == 0) {
                                result = "file://" + result;
                            }
                            q.resolve(result);
                        },
                        function (err) {
                            q.reject(err);
                        }, PHOTO_OPTIONS);
                    return q.promise;
                },
                resolveFile: function (url) {
                    $ionicLoading.show();
                    var q = $q.defer();
                
                    window.resolveLocalFileSystemURL(url, function (fileEntry) {
                        console.log('got a file entry');
                        fileEntry.file(function (file) {
                            console.log('now i have a file ob');
                            console.dir(file);
                            var reader = new FileReader();
                            reader.onloadend = function (e) {
                                console.log(e);
                                var imgBlob = new Blob([this.result], { type: file.type });
                                var response = {
                                    imgBlob: imgBlob,
                                    file: file
                                };
                                $ionicLoading.hide();
                                q.resolve(response);
                            };
                            reader.readAsArrayBuffer(file);
                        }, function (e) {
                            console.log('error getting file', e);
                            q.reject(e);
                        });
                    }, function (e) {
                        console.log('Error resolving fs url', e);
                        q.reject(e);
                    });
                    return q.promise;
                },
                setTemporaryId: function (huntingId, animalId) {
                    this.huntingId = huntingId;
                    this.animalId = animalId;
                },
                getFileList: function (huntingId) {
                    return Session.request("getFileList", { huntingId: huntingId })
                        .then(function (result) {
                            return result.data;
                        }, function (err) {
                            console.log(err);
                        });
                },
                uploadPhoto: function (fileUrl, huntingId, animalId, fileTypeId) {
                    $ionicLoading.show();

                    var q = $q.defer();
                    var fd = new FormData();

                    window.resolveLocalFileSystemURL(fileUrl, function (fileEntry) {
                        console.log('got a file entry');
                        fileEntry.file(function (file) {
                            console.log('now i have a file ob');
                            console.dir(file);
                            var reader = new FileReader();
                            reader.onloadend = function (e) {
                                console.log(e);
                                var imgBlob = new Blob([this.result], { type: file.type });
                                console.log(imgBlob);
                                console.log(file.type);

                                fd.append('file', imgBlob, file.name);

                                var session = Session.getSession();

                                if (huntingId != null) fd.append('huntingId', huntingId);
                                if (animalId != null) fd.append('animalId', animalId);
                                if (fileTypeId != null) fd.append('fileTypeId', fileTypeId);

                                fd.append('_SessionID', session._SessionID);
                                fd.append('_SessionKey', session._SessionKey);

                                console.log("all things done");

                                var request = new XMLHttpRequest();
                                request.onprogress = function () {

                                }
                                request.onload = function () {
                                    if (request.readyState == 4 && request.status == 200) {
                                        var response = JSON.parse(request.responseText);
                                        $ionicLoading.hide();
                                        if (response["error"]) {
                                            q.reject(response["error"]);
                                        } else {
                                            console.log('upload success');
                                            var message = 'Zdjęcie zostało dodane';
                                            q.resolve(message);
                                        }
                                    }
                                };
                                request.open('POST', ApiEndpoint.url + "uploadPhoto");
                                // request.setRequestHeader('Authorization', 'Basic ' + $base64.encode('jpalio' + ':' + 'Torn'));

                                request.send(fd);
                            };
                            reader.readAsArrayBuffer(file);
                        }, function (e) {
                            console.log('error getting file', e);
                            q.reject('Nie udało się dodać zdjęcia');
                        });
                    }, function (e) {
                        console.log('Error resolving fs url', e);
                        q.reject('Nie udało się dodać zdjęcia');
                    });

                    return q.promise;
                }
            }
        }]);
