angular.module('app.services')
    .factory('CollectivePlanService', [
        "$http",
        "$state",
        "$q",
        "$cordovaToast",
        "ApiEndpoint",
        "Session",
        function (
            $http,
            $state,
            $q,
            $cordovaToast,
            ApiEndpoint,
            Session
        ) {
            return {
                getCollectivePlanList: function () {
                    return Session.request("getCollectivePlanList")
                        .then(function (result) {
                            var planList = result.data.planList;
                            for (var i = 0; i < planList.length; i++) {
                                planList[i].DATA_OD = (
                                    new Date(
                                        planList[i].DATA_OD.time - planList[i].DATA_OD.timezoneOffset * 60 * 1000
                                    )
                                ).toISOString().substring(0, 10);
                            }

                            return planList;
                        });
                },
                getCollectivePlanDetails: function (id) {
                    return Session.request("getCollectivePlanDetails", { huntingId: id })
                        .then(function (result) {
                            var collectivePlan = result.data.planDetails;
                            collectivePlan.DATA_OD = (new Date(
                                collectivePlan.DATA_OD.time - collectivePlan.DATA_OD.timezoneOffset * 60 * 1000
                            )).toISOString().substring(0, 10);
                            return result.data;
                        });
                },
                collectiveSignIn: function (huntingId) {
                    return Session.request("collectiveSignIn", { huntingId: huntingId })
                        .then(function (result) {
                            return result.data;
                        });
                },
                collectiveSignOut: function (huntingId) {
                    return Session.request("collectiveSignOut", { huntingId: huntingId })
                        .then(function (result) {
                            return result.data;
                        });
                }
            }
        }]);