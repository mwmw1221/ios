angular.module('app.services')
    .factory('HuntDamageService', [
        "$q",
        "Session",
        "ApiEndpoint",
        "$base64",
        "$ionicLoading",
        "UtilsService",
        function (
            $q,
            Session,
            ApiEndpoint,
            $base64,
            $ionicLoading,
            UtilsService
        ) {
            return {
                getHuntDamages: function (circuitId, year) {
                    console.log(circuitId);
                    return Session.request("getHuntDamages", { circuitId: circuitId, year: year })
                        .then(function (result) {
                            return result.data.damegeList;
                        }, function (err) {
                            return err;
                        })
                },
                getHuntDamageFarmers: function () {
                    return Session.request("getHuntDamageFarmers", )
                        .then(function (result) {
                            return result.data.farmers;
                        }, function (err) {
                            return err;
                        })
                },
                addHuntDamage: function (data) {
                    $ionicLoading.show();

                    var q = $q.defer();
                    var fd = new FormData();

                    var session = Session.getSession();

                    fd.append('_SessionID', session._SessionID);
                    fd.append('_SessionKey', session._SessionKey);

                    [].forEach.call(data.file, function (file) {
                        fd.append('file[]', file.imgBlob, file.file.name);
                    });

                    if (data.circuitId != null) fd.append('circuitId', data.circuitId);
                    if (data.farmerName != null) fd.append('farmerName', data.farmerName);
                    if (data.farmerContact != null) fd.append('farmerContact', data.farmerContact);
                    if (data.farmerId != null) fd.append('farmerId', data.farmerId);
                    if (data.cropType != null) fd.append('cropType', data.cropType);
                    if (data.protNr != null) fd.append('protNr', data.protNr);
                    if (data.longitude != null) fd.append('longitude', data.longitude);
                    if (data.latitude != null) fd.append('latitude', data.latitude);
                    if (data.coords != null) fd.append('coords', data.coords);
                    if (data.date != null) {
                        var date = UtilsService.convertDateToString(data.date);
                        fd.append('date', date);
                    }


                    var request = new XMLHttpRequest();
                   
                    request.onprogress = function () {

                    }
                    request.onload = function () {
                        if (request.readyState == 4 && request.status == 200) {
                            var response = JSON.parse(request.responseText);
                            $ionicLoading.hide();
                            if (response["error"]) {
                                q.reject(response["error"]);
                            } else {
                                console.log('upload success');
                                var message = 'Zdjęcie zostało dodane';
                                q.resolve(message);
                            }
                        }
                    };
                    request.open('POST', ApiEndpoint.url + "addHuntDamage");
                    // request.setRequestHeader('Authorization', 'Basic ' + $base64.encode('jpalio' + ':' + 'Torn'));

                    request.send(fd);
                    return q.promise;
                },
                editHuntDamage: function (data) {
                    $ionicLoading.show();

                    var q = $q.defer();
                    var fd = new FormData();

                    var session = Session.getSession();

                    fd.append('_SessionID', session._SessionID);
                    fd.append('_SessionKey', session._SessionKey);

                    [].forEach.call(data.file, function (file) {
                        fd.append('file[]', file.imgBlob, file.file.name);
                    });

                    if (data.damageId != null) fd.append('damageId', data.damageId);
                    if (data.cropType != null) fd.append('cropType', data.cropType);
                    if (data.protNr != null) fd.append('protNr', data.protNr);
                    if (data.longitude != null) fd.append('longitude', data.longitude);
                    if (data.latitude != null) fd.append('latitude', data.latitude);
                    if (data.coords != null) fd.append('coords', data.coords);
                    if (data.description != null) fd.append('description', data.description);
                    if (data.date != null) {
                        var date = UtilsService.convertDateToString(data.date);
                        fd.append('date', date);
                    }


                    var request = new XMLHttpRequest();
                    request.onprogress = function () {

                    }
                    request.onload = function () {
                        if (request.readyState == 4 && request.status == 200) {
                            var response = JSON.parse(request.responseText);
                            $ionicLoading.hide();
                            if (response["error"]) {
                                q.reject(response["error"]);
                            } else {
                                console.log('upload success');
                                var message = 'Zdjęcie zostało dodane';
                                q.resolve(message);
                            }
                        }
                    };
                    request.open('POST', ApiEndpoint.url + "updateHuntDamage");
                    // request.setRequestHeader('Authorization', 'Basic ' + $base64.encode('jpalio' + ':' + 'Torn'));

                    request.send(fd);
                    return q.promise;
                },
                getHuntDamageInfo(damageId) {
                    return Session.request("getHuntDamageInfo", { damageId: damageId })
                        .then(function (result) {
                            return result.data;
                        }, function (err) {
                            return err;
                        })
                },
                getHuntDamageNewNumber() {
                    return Session.request("getHuntDamageNewNumber")
                        .then(function (result) {
                            return result.data.protNr;
                        }, function (err) {
                            return err;
                        })
                }
            }
        }]);