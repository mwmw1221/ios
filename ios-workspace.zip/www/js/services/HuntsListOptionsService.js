angular.module('app.services')
    .factory('HuntsListOptionsService', [
        "LocalStorage",
        "$translate",
        "$cordovaToast",
        function (
            LocalStorage,
            $translate,
            $cordovaToast
        ) {
            var settings = !angular.equals(LocalStorage.getObject("huntsListOptions"), {}) ? LocalStorage.getObject("huntsListOptions") : {
                hunter: true,
                place: true,
                game: true,
                startDate: true,
                shots: true,
                size: 2,
                comments: true
            };

            var sizes = [{
                value: 1,
                label: $translate.instant('Large')
            }, {
                value: 2,
                label: $translate.instant('Medium')
            }, {
                value: 3,
                label: $translate.instant('Small')
            }];

            return {
                getSettings: function () {
                    return settings;
                },
                saveSettings: function (data) {
                    LocalStorage.setObject("huntsListOptions", data);
                    $translate('Saved').then($cordovaToast.showLongBottom);
                },
                getSizes: function () {
                    return sizes;
                }
            }
        }]);