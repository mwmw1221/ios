angular.module('app.services')
    .factory('MapUtils', [
        "$http",
        "ApiEndpoint",
        function (
            $http,
            ApiEndpoint,
        ) {

            return {
                _arrayBufferToBase64: function (buffer) {
                    var binary = '';
                    var bytes = new Uint8Array(buffer);
                    var len = bytes.byteLength;
                    for (var i = 0; i < len; i++) {
                        binary += String.fromCharCode(bytes[i]);
                    }
                    return window.btoa(binary);
                },
                getIcon: function (url) {
                    // Angular $http() and then() both return promises themselves 
                    return $http({
                        method: 'GET',
                        url: ApiEndpoint.HOST + url,
                        responseType: 'arraybuffer'
                    }).then(function (response) {
                        var str = _arrayBufferToBase64(response.data);
                        return str;
                    }, function (response) {
                        console.error('error in getting static img.');
                    });
                },
                resolveIcons: function () {
                    var promises = [];
                    for (var i in registerTypes) {
                        var promise = getIcon(registerTypes[i].zdj);
                        promises.push(promise);
                    }
                    $q.all(promises).then(function (response) {
                        for (var i = 0; i < registerTypes.length; i++) {
                            registerTypes[i].zdj = response[i];
                        }
                    })
                },
                getBaseLayers: function () {
                    var osm = L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
                        attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors'
                    });
                    var arcGis = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}.png", {
                        attribution: 'Source: Esri, DigitalGlobe, GeoEye, Earthstar Geographics, CNES/Airbus DS, USDA, USGS, AeroGRID, IGN, and the GIS User Community'
                    });

                    //orto
                    var geoOrto = L.tileLayer.wms("https://mapy.geoportal.gov.pl/wss/service/img/guest/ORTO/MapServer/WMSServer?", {
                        layers: 'Raster',
                        format: 'image/png',
                        transparent: false,
                        id: "GEOPORTAL_ORTO",
                        crs: L.CRS.EPSG4326,
                        version: '1.3.0'
                    })

                    //TOPO
                    var geoTopo = L.tileLayer.wms("https://mapy.geoportal.gov.pl/wss/service/img/guest/TOPO/MapServer/WMSServer?", {
                        layers: 'Raster',
                        format: 'image/png',
                        transparent: false,
                        id: "GEOPORTAL_TOPO",
                        crs: L.CRS.EPSG4326,
                        version: '1.3.0'
                    });

                    var baseLayers = {
                        "OpenStreetMap": osm,
                        "ArcGis": arcGis,
                        "Orto": geoOrto,
                        "TOPO": geoTopo
                    };

                    return baseLayers;
                },
                getOverlays: function () {
                    // opisy
                    var ArcGIS2 = L.tileLayer("https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}.png");
                    var dzialki = L.tileLayer.wms("https://mapy.geoportal.gov.pl/wss/service/pub/guest/G2_GO_WMS/MapServer/WMSServer?", {
                        layers: 'Dzialki,NumeryDzialek',
                        format: 'image/png',
                        transparent: true,
                        id: "dzialki",
                        crs: L.CRS.EPSG4326,
                        version: '1.3.0',
                        tileSize: 512
                    });
                    var oddzialy = L.tileLayer.wms("http://mapserver.bdl.lasy.gov.pl/ArcGIS/services/WMS_BDL/mapserver/WMSServer?", {
                        layers: '0,1,2,3',
                        format: 'image/png',
                        transparent: true,
                        id: "oddzialy",
                        crs: L.CRS.EPSG4326,
                        version: '1.3.0',
                        tileSize: 512
                    });
                    var rdpl = L.tileLayer.wms("http://mapserver.bdl.lasy.gov.pl/ArcGIS/services/WMS_BDL/mapserver/WMSServer?", {
                        layers: '4,5',
                        format: 'image/png',
                        transparent: true,
                        id: "rdpl",
                        crs: L.CRS.EPSG4326,
                        version: '1.3.0',
                        tileSize: 512
                    });

                    var overlays = {
                        "Opisy": ArcGIS2,
                        "Działki": dzialki,
                        "Oddziały leśne": oddzialy,
                        "Rdpl i nadleśnictwa": rdpl
                    }

                    return overlays;
                }
            }
        }]);