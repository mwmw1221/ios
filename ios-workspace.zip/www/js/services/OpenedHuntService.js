angular.module('app.services')
    .factory('OpenedHuntService', [
        "$http",
        "$state",
        "$q",
        "$cordovaToast",
        "ApiEndpoint",
        "Session",
        function (
            $http,
            $state,
            $q,
            $cordovaToast,
            ApiEndpoint,
            Session
        ) {
            var animals = [];
            var huntingId;

            return {
                getAnimalsRequest: function (huntingId) {
                    return Session.request("getAnimals", { huntingId: huntingId })
                        .then(function (result) {
                            // if (result.data.animals) {
                            //     for (var i = 0; i < result.data.animals.length; i++) {
                            //         var tempDate;
                            //         tempDate = new Date(result.data.animals[i][3].time + 3600000);
                            //         result.data.animals[i][3] = tempDate.toISOString().substring(0, 10) + ' ' + tempDate.toISOString().substring(11, 16);
                            //     }
                            // }
                            return result.data.animals;
                        });
                },
                dropAnimal: function (huntingId, animalId) {
                    return Session.request("dropAnimal", { huntingId: huntingId, animalId: animalId })
                        .then(function (result) {

                        });
                },
                setAnimals: function (animals) {
                    this.animals = animals;
                },
                getAnimals: function () {
                    return this.animals;
                },
                getHuntingInfo: function (huntingId) {
                    return Session.request("getHuntingInfo", { huntingId: huntingId })
                        .then(function (result) {
                            var dataOd = new Date(result.data.hunting.DATAOD.time);
                            var dataDo = new Date(result.data.hunting.DATADO.time);
                            var dataPrzedl;
                            if (result.data.hunting.DATAPRZEDL != null) {
                                dataPrzedl = new Date(result.data.hunting.DATAPRZEDL.time - result.data.hunting.DATAPRZEDL.timezoneOffset * 60 * 1000);
                                result.data.hunting.DATAPRZEDL = dataPrzedl.toISOString().substring(0, 10);
                            }
                            var dataRozpoczecia = new Date(result.data.hunting.DATAROZP.time - result.data.hunting.DATAROZP.timezoneOffset * 60 * 1000);
                            if (new Date() >= dataRozpoczecia) {
                                result.data.hunting.possibleToDelete = false;
                            } else {
                                result.data.hunting.possibleToDelete = true;
                            }
                            result.data.hunting.DATAOD = dataOd.toISOString().substring(0, 10);
                            result.data.hunting.DATADO = dataDo.toISOString().substring(0, 10);
                            result.data.hunting.DATAROZP = dataRozpoczecia.toISOString().substring(0, 10) + ' ' + dataRozpoczecia.toISOString().substring(11, 16);


                            if (result.data.hunting.DATAZAKON != null) {
                                var dataZakonczenia = new Date(result.data.hunting.DATAZAKON.time - result.data.hunting.DATAZAKON.timezoneOffset * 60 * 1000);
                                result.data.hunting.DATAZAKON = dataZakonczenia.toISOString().substring(0, 10) + ' ' + dataZakonczenia.toISOString().substring(11, 16);
                            }

                            for (var i = 0; i < result.data.animals.length; i++) {
                                var tempDate;
                                tempDate = new Date(result.data.animals[i][3].time - result.data.animals[i][3].timezoneOffset * 60 * 1000);
                                result.data.animals[i][3] = tempDate.toISOString().substring(0, 10) + ' ' + tempDate.toISOString().substring(11, 16);
                            }
                            result.data.hunting.animals = result.data.animals;
                            result.data.hunting.permits = result.data.permits;
                            result.data.hunting.districts = result.data.districts;
                            return result.data.hunting;
                        });
                },
                addShooting: function (data) {
                    return Session.request("addAnimal", data)
                        .then(function (result) {
                            return result.data;
                        })
                },
                editShooting: function (data) {
                    return Session.request("editAnimal", data)
                        .then(function (result) {
                            return result;
                        })
                },
                endHunt: function (data) {
                    return Session.request("endHunt", data)
                        .then(function (result) {
                            return result.data;
                        })
                },
                changePlannedEndDate: function (data) {
                    return Session.request("changeEndDate", data)
                        .then(function (result) {
                            return result.data;
                        })
                },
                addHuntingPermits: function (huntingId) {
                    return Session.request("changeEndDate", data)
                        .then(function (result) {
                            return result.data;
                        })
                },
                deleteHunting: function (huntingId) {
                    return Session.request("deleteHunting", huntingId)
                        .then(function (result) {
                            return result;
                        })
                },
                getAntlerTypes: function(animalId) {
                    return Session.request("getAntlerTypes", {animalId: animalId})
                        .then(function(result) {
                            return result.data.antlers;
                        })
                },
                getFileList: function(huntingId) {
                    return Session.request("getFileList", {huntingId: huntingId})
                        .then(function(result) {
                            return result.data.files;
                        })
                },
                changeHuntingDescription: function(huntingId, description) {
                    return Session.request("changeHuntingDescription", {
                        huntingId: huntingId,
                        description: description
                    }).then(function(result) {
                        return result.data;
                    })
                },
                updateShotCount: function(huntingId, shotCount) {
                    return Session.request("updateShotCount", {huntingId: huntingId, shotCount: shotCount})
                        .then(function(result){
                            return result.data;
                        }, function(err) {
                            return err;
                        })
                },
                getClinicalSymptoms: function() {
                    return Session.request("getClinicalSymptoms")
                        .then(function(result){
                            return result.data.data;
                        }, function(err) {
                            return err;
                        })
                }
            }
        }]);