angular.module('app.services')
    .factory('PositionService', [
        "Session",
        "$cordovaGeolocation",
        '$translate',
        function (
            Session,
            $cordovaGeolocation,
            $translate
        ) {
            var currentPosition;
            var watch;

            var currentPositionOptions = {
                timeout: 8000,
                enableHighAccuracy: false
            };

            var watchOptions = {
                timeout: 500,
                enableHighAccuracy: true
            };

            return {
                getPosition: function () {
                    return this.currentPosition;
                },
                getLatitude: function () {
                    return this.currentPosition.coords.latitude;
                },
                getLongitude: function () {
                    return this.currentPosition.coords.longitude;
                },
                setPosition: function (position) {
                    var self = this;
                    console.log(position);
                    currentPosition.coords = position.coords;

                    console.log(self.position);
                },
                onSuccessPosition: function (position) {
                    setPosition(position);
                },
                onErrorPosition: function (err) {
                    console.log(err);
                    return err;
                },
                getCurrentPosition: function () {
                    var self = this;
                    return $cordovaGeolocation.getCurrentPosition(currentPositionOptions)
                        .then(function (position) {
                            self.currentPosition = position;
                            return position;
                        }, self.onErrorPosition);
                },
                watchPosition: function () {
                    var self = this;
                    watch = navigator.geolocation.watchPosition(function (position) {
                        self.currentPosition = position;
                        console.log(position);
                    }, self.onErrorPosition, self.watchOptions);
                },
                isLocationAvailable: function () {
                    var self = this;
                    return cordova.plugins.diagnostic.isLocationEnabled(function (enabled) {
                        if (enabled) {
                            return self.getCurrentPosition();
                        } else {
                            return false
                        }
                    }, function (error) {
                        $translate('AnErrorOccured').then($cordovaToast.showLongBottom);
                        console.error("The following error occurred: " + error);
                        return false
                    });
                },
                getLocationAuthorizationStatus: function () {
                    var self = this;
                    cordova.plugins.diagnostic.getLocationAuthorizationStatus(function (status) {
                        switch (status) {
                            case cordova.plugins.diagnostic.permissionStatus.NOT_REQUESTED:
                                console.log("Permission not requested");
                                self.requestLocationAuthorization();
                                break;
                            case cordova.plugins.diagnostic.permissionStatus.GRANTED:
                                console.log("Permission granted");
                                self.isLocationAvailable();
                                break;
                            case cordova.plugins.diagnostic.permissionStatus.DENIED:
                                self.requestLocationAuthorization();
                                console.log("Permission denied");
                                break;
                            case cordova.plugins.diagnostic.permissionStatus.DENIED_ALWAYS:
                                self.requestLocationAuthorization();
                                console.log("Permission permanently denied");
                                break;
                        }
                    }, function (error) {
                        $translate('ErrorOccurredDownloadingLocationAuthorizationStatus').then($cordovaToast.showLongBottom);
                        console.error("The following error occurred: " + error);
                    });
                },
                requestLocationAuthorization: function () {
                    cordova.plugins.diagnostic.requestLocationAuthorization(function (status) {
                        switch (status) {
                            case cordova.plugins.diagnostic.permissionStatus.NOT_REQUESTED:
                                console.log("Permission not requested");
                                break;
                            case cordova.plugins.diagnostic.permissionStatus.GRANTED:
                                $translate('PermissionsGranted').then($cordovaToast.showLongBottom);
                                console.log("Permission granted always");
                                self.isLocationAvailable();
                                break;
                            case cordova.plugins.diagnostic.permissionStatus.DENIED:
                                $translate('PermissionsHaveBeenDenied').then($cordovaToast.showLongBottom);
                                console.log("Permission denied");
                                break;
                            case cordova.plugins.diagnostic.permissionStatus.DENIED_ALWAYS:
                                console.log("Permission permanently denied");
                                break;
                        }
                    }, function (error) {
                        $translate('ErrorGrantingPermissions').then($cordovaToast.showLongBottom);
                        console.error(error);
                    });
                }
            }
        }]);