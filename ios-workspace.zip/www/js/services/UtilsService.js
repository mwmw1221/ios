angular.module('app.services')
    .factory('UtilsService', [
        "Session",
        function (
            Session
        ) {
            var fileTypes;

            return {
                /* Date Utils */

                // converts Date object to current timezone
                convertingDateTimezone: function (date) {
                    var newDate = new Date(date.substring(0, 10) + 'T' + date.substring(11, 16) + ':00Z');
                    newDate.setHours(newDate.getHours() + newDate.getTimezoneOffset() / 60);
                    return newDate;
                },
                addZero: function (i) {
                    if (i < 10) {
                        i = "0" + i;
                    }
                    return i;
                },
                convertDateToTime: function (dateTime) {
                    self = this;

                    var resultTime;
                    if (dateTime) {
                        var temp = new Date(dateTime);
                        resultTime = self.addZero(temp.getHours()) + ':' + self.addZero(temp.getMinutes());
                    }
                    return resultTime;
                },
                convertStringToDatetime: function (s) {
                    var bits = s.split(/\D/);
                    return new Date(bits[0], --bits[1], bits[2], bits[3], bits[4]);
                },
                /* returns true if selected date is earlier than current */
                compareDateTimeWithCurrent: function (date, time) {
                    currentDatetime = new Date(Date.now());
                    currentDatetime.setSeconds(0, 0);
                    selectedDateTime = this.convertStringToDatetime(date + ' ' + time);
                    return selectedDateTime < currentDatetime;
                },
                compareDate: function(date) {
                    current = new Date();
                    console.log('date: ' + date);
                    console.log('current: ' + current);
                    current.setHours(0,0,0,0);
                    console.log(date.getTime() + ' vs ' + current.getTime());
                    console.log(date.getTime() < current.getTime());

                },
                compareDateTime: function(time) {
                    current = new Date();
                    current.setSeconds(0,0);
                    return time.getTime() < current.getTime();
                },
                compareDateTimes: function(first, second) {
                    return first.getTime() < second.getTime();
                },
                getFileTypes: function () {
                    return Session.request("getFileTypes")
                        .then(function (result) {
                            return result.data.types;
                        });
                },
                getTimeZone: function() {
                    var offset = new Date().getTimezoneOffset(), o = Math.abs(offset);
                    return (offset < 0 ? "+" : "-") + ("00" + Math.floor(o / 60)).slice(-2) + ":" + ("00" + (o % 60)).slice(-2);
                },
                convertDateToString: function(d) {
                    return d.getFullYear()  + "-" + (d.getMonth()+1) + "-" + d.getDate();
                },
                convertTimeToString: function(d) {
                    return ("0" + d.getHours()).slice(-2) + ":" + ("0" + d.getMinutes()).slice(-2);
                }
            }
        }]);