angular.module('app.services')
    .factory('MessagesService', [
        "$http",
        "$state",
        "$q",
        "$cordovaToast",
        "ApiEndpoint",
        "Session",
        function (
            $http,
            $state,
            $q,
            $cordovaToast,
            ApiEndpoint,
            Session
        ) {
            return {
                // codes: 'A' - all, 'N' - new
                getUserNotifications: function (code, page) {
                    return Session.request("getUserNotifications", { code: code, pageNr: page })
                        .then(function (result) {
                            if (result != null) {
                                var json = result.data;
                                for (var d in json.data) {
                                    json.data[d].CREATE_DATE = new Date(json.data[d].CREATE_DATE.time - json.data[d].CREATE_DATE.timezoneOffset * 60 * 1000);
                                    json.data[d].CREATE_DATE = json.data[d].CREATE_DATE.toISOString();
                                }
                                return json;
                            }
                            return null
                        });
                },
                setNotificationRead: function (notifiId) {
                    return Session.request("setNotificationRead", { notifiId: notifiId })
                        .then(function (result) {
                            if (result != null)
                                return result;
                            return null
                        });
                },
                setNotificationDelete: function (notifiId) {
                    return Session.request("setNotificationDelete", { notifiId: notifiId })
                        .then(function (result) {
                            if (result != null)
                                return result;
                            return null
                        });
                },
                getNotyficationsCount: function () {
                    return Session.request("getNotyficationsCount")
                        .then(function (result) {
                            if (result != null)
                                return result.data;
                            return null
                        });
                },
                getAllMessagesCount: function () {
                    return Session.request("getNotyficationsCount")
                        .then(function (result) {
                            if (result != null)
                                return result.data.NotificationCount + result.data.MessagesCount;
                            return null
                        });
                },
                getUserMessage: function (messageId) {
                    return Session.request('getUserMessage', { messageId: messageId })
                        .then(function (result) {
                            return result.data;
                        })
                },
                getUserMessages: function (page) {
                    return Session.request('getUserMessages', { pageNr: page })
                        .then(function (result) {
                            if (result != null) {
                                var json = result.data;
                                for (var d in json.data) {
                                    json.data[d].sent = new Date(json.data[d].sent.time - json.data[d].sent.timezoneOffset * 60 * 1000);
                                    json.data[d].sent = json.data[d].sent.toISOString();
                                }
                                return json;
                            }
                            return null
                        })
                },
                deleteUserMessage: function (messageId) {
                    return Session.request("deleteUserMessage", { messageId: messageId })
                        .then(function (result) {
                            if (result != null)
                                return result;
                            return null
                        });
                }
            }
        }]);