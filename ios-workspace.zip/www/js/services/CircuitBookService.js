angular.module('app.services')
    .factory('CircuitBookService', [
        "$http",
        "$state",
        "$q",
        "$cordovaToast",
        "ApiEndpoint",
        "LocalStorage",
        "Session",
        function (
            $http,
            $state,
            $q,
            $cordovaToast,
            ApiEndpoint,
            LocalStorage,
            Session
        ) {
            return {
                getHuntingFromObw: function(cId, year, pageNr) {
                    return Session.request("getHuntingFromObw", { cId: cId, year: year, pageNr: pageNr})
                    .then(function(result) {
                        return result.data;
                    });
                }
            }
        }]);