angular.module('app.services')
	.factory('Session', [
		"$http",
		"$state",
		"$q",
		"$base64",
		"$cordovaToast",
		"ApiEndpoint",
		"LocalStorage",
		'$interval',
		'$rootScope',
		'$ionicPopup',
		function (
			$http,
			$state,
			$q,
			$base64,
			$cordovaToast,
			ApiEndpoint,
			LocalStorage,
			$interval,
			$rootScope,
			$ionicPopup
		) {
			var sessionData;
			var userRole;
			var regions;
			var currentRegion;
			var permits;
			var menuPrivileges;

			var loginRequest = function (user) {
				var data = user;
				data.deviceId = device.uuid;
				data.deviceName = device.model;
				data.appVersion = ApiEndpoint.version;
				data.lang = $rootScope.language;
				if (device.platform === 'iOS') {
					data.deviceType = 'i';
				} else if (device.platform === 'Android') {
					data.deviceType = 'A';
				}

				return $http({
					url: ApiEndpoint.url + "login",
					method: 'POST',
					data: data
				})
					.then(
						function (response) {
							if (response.data.error) return $q.reject(response.data);
							return response.data;
						},
						function (response) {
							return $q.reject(response.data);
						})
			};
			var reloginCount = 0;


			var relogin = function () {
				var self = this;
				var user = LocalStorage.getObject("user");
				// $state.go('login');
				if (reloginCount == 1) {
					$state.go('login');
					return;
				}
				return loginRequest(user).then(
					function (data) {
						self.setSession(data);
						self.setRegions(data.regions);
						reloginCount = 0;
					},
					function () {
						reloginCount = 1;
						console.log("problem z logowaniem");
						$state.go('login');
					}
				);
			}

			return {
				relogin: relogin,
				login: function (user) {
					var self = this;
					return loginRequest(user)
						.then(
							function (data) {
								LocalStorage.setObject("user", user);
								self.setSession(data);
								self.setRegions(data.regions);
								
								return ("Login success");
							},
							function (data) {
								return (data);
							});

				},
				applicationEnter: function () {
					var self = this;
					if (self.regions.length == 1) {
						self.setCurrentRegion(self.regions[0]).then(function () {
							self.permitsRequest().then(function (result) {
								self.setPermits(result);
								$state.go('menu.hunterOptions');
							});
						});
					}
					else {
						$state.go('choosingRegion');
					}
				},
				logout: function () {
					var self = this;
					return this.request("logout")
						.then(function (result) {
							if (result.data.action) {
								var session = {
									_SessionID: null,
									_SessionKey: null
								};
								self.setSession(session);
								self.setRegions(null);
								self.currentRegion = null;
								return true;
							}
							return false;
						})
				},
				permitsRequest: function () {
					return this.request("getAllPermits")
						.then(function (result) {
							return result.data.permits;
						});
				},
				setSession: function (session) {
					sessionData = {
						"_SessionID": session._SessionID,
						"_SessionKey": session._SessionKey
					}
				},
				getSession: function () {
					return sessionData;
				},
				setUserRole: function (userRole) {
					this.userRole = userRole;
				},
				getUserRole: function () {
					return this.userRole;
				},
				setRegions: function (regions) {
					this.regions = regions;
				},
				getRegions: function () {
					return this.regions;
				},
				setCurrentRegion: function (currentRegion) {
					var self = this;
					self.currentRegion = currentRegion;
					return this.request("selectRegion", { regionId: currentRegion[0] })
						.then(function (result) {
							self.setMenuPrivileges(result.data.menuPriv);
							return result.data;
						});
				},
				getCurrentRegion: function () {
					return this.currentRegion;
				},
				setPermits: function (permits) {
					this.permits = permits;
				},
				getPermits: function () {
					return this.permits;
				},
				checkSessionAction: function () {
					return $http({
						url: ApiEndpoint.url + "checkSession",
						method: 'POST',
						data: sessionData
					});
				},
				addSessionData: function (data) {
					return angular.extend(data, this.getSession());
				},
				request: function (requestHandler, data) {
					var self = this;
					data = data || {};
					return $http({
						url: ApiEndpoint.url + requestHandler,
						method: 'POST',
						data: self.addSessionData(data)
					})
						.then(function (response) {
							return self.checkResponsePromise(response);
						});
				},
				testRequest: function () {
					return $http({
						url: ApiEndpoint.url + 'main',
						method: 'POST'
					})
						.then(function (response) {
							return response;
						}, function (response) {
							return response;
						});
				},
				checkResponsePromise: function (response) {
					var self = this;
					if (response.data && response.data.error) {
						if ((response.data.error == "Cannot invoke method getCompanyId() on null object") || (response.data.error == "sessionError")) {
							relogin();
							return $q.reject(response);
						} else {
							this.displayError(response.data.error);
							return $q.reject(response);
						}
					} else {
						return response;
					}
				},
				displayError: function (message) {
					return $cordovaToast.showLongBottom(message);
				},
				getActualVersion: function () {
					return $http({
						url: ApiEndpoint.url + 'getActualVersion',
						method: 'GET'
					})
						.then(function (response) {
							return response.data.version;
						}, function (response) {
							return response;
						});
				},
				sendToken: function (token) {
					this.request("setGoogleToken", { token: token, deviceId: device.uuid })
						.then(function (response) {
						});
				},
				setMenuPrivileges: function (data) {
					menuPrivileges = data;
					$rootScope.menuPrivileges = menuPrivileges;
				},
				getMenuPrivileges: function () {
					return menuPrivileges;
				}
				/*runNotificationChecker: function (token) {
					if (intervals.length == 0) {
						intervals.push($interval(function (token) {
							$http({
								url: ApiEndpoint.NOTIFICATION_URL + 'checkInfo',
								method: 'POST',
								data: {
									token: token,
									deviceId: device.uuid
								}
							})
								.then(function (response) {
									if (response.data.notification) {
										var data = response.data;
										if ($rootScope.background) {
											angular.forEach(data.notificationList, function (notification) {
												cordova.plugins.notification.local.schedule({
													title: notification.TITLE,
													text: notification.CONTENT,
													background: true
												});
											});
										} else {
											angular.forEach(data.notificationList, function (notification) {
												var notificationPopup = $ionicPopup.alert({
													title: notification.TITLE,
													template: notification.CONTENT
												});
											});
										}
									}
								}, function (response) {
								});
						}, 40000, 0, false, token));
					}
				}*/
			}
		}]);