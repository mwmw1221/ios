angular.module('app.services')
    .factory('CircuitService', [
        "$http",
        "$state",
        "$q",
        "$cordovaToast",
        "ApiEndpoint",
        "LocalStorage",
        "Session",
        function (
            $http,
            $state,
            $q,
            $cordovaToast,
            ApiEndpoint,
            LocalStorage,
            Session
        ) {
            var currentCircuit;

            return {
                getList: function () {
                    return Session.request("getCircuits")
                        .then(function (result) {
                            return result.data.circuits;
                        });
                },
                // setCircuitList: function (circuitList) {
                //     this.circuitList = circuitList;
                // },
                // getCircuitsList: function () {
                //     return this.circuitsList;
                // },
                setCurrentCircuit: function (currentCircuit) {
                    this.currentCircuit = currentCircuit;
                },
                getCurrentCircuit: function () {
                    return this.currentCircuit;
                },
            }
        }]);