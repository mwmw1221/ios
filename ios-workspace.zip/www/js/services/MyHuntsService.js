angular.module('app.services')
    .factory('MyHuntsService', [
        "$http",
        "$state",
        "$q",
        "$cordovaToast",
        "ApiEndpoint",
        "Session",
        function (
            $http,
            $state,
            $q,
            $cordovaToast,
            ApiEndpoint,
            Session
        ) {
            return {
                getMyHuntsList: function (year) {
                    return Session.request("getMyHunting", { year: year })
                        .then(function (result) {
                            if (result != null)
                                return result.data.hunting;
                            return null
                        });
                },
                getYearList: function () {
                    return Session.request("getYearList", {})
                        .then(function (result) {
                            var years = result.data.year
                            var result = new Array();
                            for (var i in years) {
                                var year = parseInt(years[i]);
                                var nextYear = year + 1;
                                result.push({ label: year + '/' + nextYear, value: year });
                            }
                            return result;
                        });
                }
            }
        }]);