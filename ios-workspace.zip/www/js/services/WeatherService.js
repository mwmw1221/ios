angular.module('app.services')
    .factory('WeatherService', [
        "Session",
        "UtilsService",
        function (
            Session,
            UtilsService
        ) {
            var windDirection = {
                'N': '↑',
                'NW': '↖',
                'W': '←',
                'SW': '↙',
                'S': '↓',
                'SE': '↘',
                'E': '→',
                'NE': '↗'
            };

            var weatherIcons = {
                'sunrise': 'img/sunrise.png',
                'sunset': 'img/sunset.png',
                'moonset': 'img/moonset.png',
                'moonrise': 'img/moonrise.png'
            };

            var windIcon = {
                'icon': 'img/windArrow.png',
            }
            var moonPhases = [
                'img/newmoon.png',
                'img/firstq.png',
                'img/lastq.png',
                'img/fullmoon.png'
            ];

            return {
                getWeather: function (longitude, latitude) {
                    return Session.request("getWeather", { longitude: longitude, latitude: latitude })
                        .then(function (result) {
                            var data = result.data;
                            var timezone = new Date().getTimezoneOffset()
                            data.weather.VALUE.sys.sunrise = UtilsService.convertDateToTime(new Date(data.weather.VALUE.sys.sunrise*1000));
                            data.weather.VALUE.sys.sunset = UtilsService.convertDateToTime(new Date(data.weather.VALUE.sys.sunset*1000));
                            return data;
                        });
                },
                getWindDirection: function(key) {
                    return windDirection[key];
                },
                windDegreeToDirection: function(degree) {
                    var self = this;
                    if (degree > 337.5) return self.getWindDirection('N');
                    if (degree > 292.5) return self.getWindDirection('NW');
                    if (degree > 247.5) return self.getWindDirection('W');
                    if (degree > 202.5) return self.getWindDirection('SW');
                    if (degree > 157.5) return self.getWindDirection('S');
                    if (degree > 122.5) return self.getWindDirection('SE');
                    if (degree > 67.5) return self.getWindDirection('E');
                    if (degree > 22.5) return self.getWindDirection('NE');
                    return self.getWindDirection('N');
                },
                getWeatherIcon: function(name) {
                    return weatherIcons[name];
                },
                getWeatherIcons: function() {
                    return weatherIcons;
                },
                getMoonPhases: function() {
                    return moonPhases;
                },
                getWindIcon: function() {
                    return windIcon;
                }
            }
        }]);