angular.module('app.services')
    .factory('ActivityPlanService', [
        "Session",
        function (
            Session
        ) {
            return {
                getActivityPlan: function (year) {
                    return Session.request("getActivityPlan", { year: year })
                        .then(function (result) {
                            return result.data.plan;
                        });
                },
                setActivityPlanPresent: function (activityPlanId, setTo) {
                    return Session.request("setActivityPlanPresent", {
                        activityPlanId: activityPlanId,
                        setTo: setTo
                    })
                        .then(function (result) {
                            return result.data;
                        });
                }
            }
        }]);