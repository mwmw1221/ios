angular.module('app.services')
.factory('LocalStorage', ['$window', function($window) {
  return {
    set: function(key, value) {
      if (value === null || value === undefined) {
        try {
          $window.localStorage.removeItem(key);
        } catch (e) {
          console.error("Error removing item from localStorage:", e);
        }
      } else {
        $window.localStorage[key] = value;
      }
    },
    get: function(key, defaultValue) {
      var value = $window.localStorage[key];
      if (value === undefined || value === null || value === 'null' || value === 'undefined') {
        return defaultValue;
      }
      return value;
    },
    setObject: function(key, value) {
      $window.localStorage[key] = JSON.stringify(value);
    },
    getObject: function(key) {
      return JSON.parse($window.localStorage[key] || '{}');
    }
  }
}]);