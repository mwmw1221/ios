angular.module('app.services')
    .factory('OpenHuntService', [
        "$http",
        "$state",
        "$q",
        "$cordovaToast",
        "ApiEndpoint",
        "Session",
        function (
            $http,
            $state,
            $q,
            $cordovaToast,
            ApiEndpoint,
            Session
        ) {
            return {
                getOpenHuntList: function () {
                    return Session.request("getOpenHunting")
                        .then(function (result) {
                            return result.data.hunting;
                        });
                },
                getAllOpenHunting: function(circuitId) {
                    return Session.request("getAllOpenHunting", {cId: circuitId})
                        .then(function(result) {
                            return result.data.hunting;
                        });
                }
                // ,
                // endHunt: function(data) {
                //     return Session.request("endHunt", data)
                //         .then(function(result) {
                //             return result.data;
                //         })
                // }
            }
        }]);