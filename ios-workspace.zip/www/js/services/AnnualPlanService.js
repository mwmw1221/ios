angular.module('app.services')
    .factory('AnnualPlanService', [
        "$http",
        "$state",
        "$q",
        "$cordovaToast",
        "ApiEndpoint",
        "LocalStorage",
        "Session",
        function (
            $http,
            $state,
            $q,
            $cordovaToast,
            ApiEndpoint,
            LocalStorage,
            Session
        ) {
            return {
                getCircuits: function() {
                    return Session.request("getCircuits")
                    .then(function(result) {
                        return result.data.circuits;
                    });
                },
                getAnnualPlan: function (circuitId) {
                    console.log(circuitId);
                    return Session.request("getAnnualPlan", { obwId: circuitId })
                        .then(function (result) {
                            return result.data;
                        });
                }
            }
        }]);