angular.module('app.services')
    .factory('DDEPrintService', [
        "$q",
        "Session",
        function (
            $q,
            Session,
        ) {
            return {
                getDDE: function (huntingId, animalId) {
                    return Session.request("getDDE", {huntingId:huntingId, animalId: animalId})
                        .then(function (result) {
                            return result.data;
                        }, function (err) {
                            return err;
                        })
                },
                saveDDE: function(data) {
                    return Session.request("saveDDE", data)
                        .then(function(result) {
                            return result.data;
                        }, function(err) {
                            return err;
                        })
                }
            }
        }]);