angular.module('app.services')
    .factory('PinService', [
        "$http",
        "$q",
        "LocalStorage", // Dodano LocalStorage do zależności
        function (
            $http,
            $q,
            LocalStorage
        ) {
            // Klucz do przechowywania PIN-ów, użyjemy go jako prefixu w LocalStorage
            const PIN_PREFIX = 'userPin_'; 

            return {
                // Zapisuje PIN dla danego użytkownika
                setPin: function(login, pin) {
                    var deferred = $q.defer();
                    try {
                        if (!login || !pin || pin.length !== 4) {
                            deferred.reject("Nieprawidłowy login lub PIN");
                            return deferred.promise;
                        }
                        LocalStorage.set(PIN_PREFIX + login, pin);
                        deferred.resolve();
                    } catch (error) {
                        console.error("Error saving PIN:", error);
                        deferred.reject("Błąd podczas zapisywania PIN: " + error);
                    }
                    return deferred.promise;
                },

                // Pobiera PIN (synchronicznie, do użytku wewnętrznego)
                getPin: function (login) {
                    if (!login) return null;
                    var pin = LocalStorage.get(PIN_PREFIX + login);
                    return (pin && pin !== 'null' && pin !== 'undefined') ? pin : null;
                },

                // Sprawdza, czy podany PIN jest poprawny
                checkPin: function (login, inputPin) {
                    var deferred = $q.defer();
                    try {
                        if (!login || !inputPin) {
                            deferred.resolve(false);
                            return deferred.promise;
                        }
                        const savedPin = this.getPin(login);
                        if (savedPin && savedPin === inputPin) {
                            deferred.resolve(true);
                        } else {
                            deferred.resolve(false);
                        }
                    } catch (error) {
                        console.error("Error checking PIN:", error);
                        deferred.reject("Błąd podczas sprawdzania PIN: " + error);
                    }
                    return deferred.promise;
                },

                // Usuwa zapisany PIN dla danego użytkownika (używane przy resecie)
                removePin: function (login) {
                    var deferred = $q.defer();
                    try {
                        if (!login) {
                            deferred.reject("Nieprawidłowy login");
                            return deferred.promise;
                        }
                        LocalStorage.set(PIN_PREFIX + login, null);
                        deferred.resolve();
                    } catch (error) {
                        console.error("Error removing PIN:", error);
                        deferred.reject("Błąd podczas usuwania PIN: " + error);
                    }
                    return deferred.promise;
                }
            };
        }
    ]);