angular.module('app.services')
    .factory('ShiftCalendarService', [
        "Session",
        function (
            Session
        ) {
            return {
                getUserShifts: function (year) {
                    return Session.request("getUserShifts", { year: year })
                        .then(function (result) {
                            return result.data.data;
                        });
                }
            }
        }]);