angular.module('app.services')
    .factory('RegistersService', [
        "$q",
        "Session",
        "ApiEndpoint",
        "$base64",
        "$ionicLoading",
        function (
            $q,
            Session,
            ApiEndpoint,
            $base64,
            $ionicLoading
        ) {
            return {
                addRegister: function (data) {
                    return Session.request("addRegister", data)
                        .then(function (result) {
                            return result.data;
                        }, function (err) {
                            return err;
                        })
                },
                addRegister: function (data) { 
                    $ionicLoading.show();

                    var q = $q.defer();
                    var fd = new FormData();

                    var session = Session.getSession();

                    fd.append('_SessionID', session._SessionID);
                    fd.append('_SessionKey', session._SessionKey);

                    [].forEach.call(data.file, function (file) {
                        fd.append('file[]', file.imgBlob, file.file.name);
                    });
       
                    if(data.circuitId != null) fd.append('circuitId', data.circuitId);
                    if(data.name != null) fd.append('name', data.name);
                    if(data.typeId != null) fd.append('typeId', data.typeId);
                    if(data.districtId != null) fd.append('districtId', data.districtId);
                    if(data.longitude != null) fd.append('longitude', data.longitude);
                    if(data.latitude != null) fd.append('latitude', data.latitude);

                    var request = new XMLHttpRequest();
                    request.onprogress = function () {

                    }
                    request.onload = function () {
                        if (request.readyState == 4 && request.status == 200) {
                            var response = JSON.parse(request.responseText);
                            $ionicLoading.hide();
                            if (response["error"]) {
                                q.reject(response["error"]);
                            } else {
                                console.log('upload success');
                                var message = 'Zdjęcie zostało dodane';
                                q.resolve(message);
                            }
                        }
                    };
                    request.open('POST', ApiEndpoint.url + "addRegister");
                //    request.setRequestHeader('Authorization', 'Basic ' + $base64.encode('jpalio' + ':' + 'Torn'));

                    request.send(fd);
                    return q.promise;
                }
            }
        }]);