angular.module('app.services')
    .factory('PaymentsService', [
        "Session",
        function (
            Session
        ) {
            return {
                getUserPayments: function (year) {
                    return Session.request("getUserPayments", { year: year })
                        .then(function (result) {
                            return result.data;
                        });
                }
            }
        }]);