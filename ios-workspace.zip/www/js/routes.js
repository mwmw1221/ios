angular.module('app.routes', [])

  .config(function ($stateProvider, $urlRouterProvider) {

    // Ionic uses AngularUI Router which uses the concept of states
    // Learn more here: https://github.com/angular-ui/ui-router
    // Set up the various states which the app can be in.
    // Each state's controller can be found in controllers.js
    $stateProvider

      .state('login', {
        cache: false,
        url: '/loginPage',
        templateUrl: 'templates/login.html',
        controller: 'loginCtrl',
        resolve: {
          serverStatus: function (Session) {
            return Session.testRequest().then(function (response) {
              if (response.status == 200) {
                return 'img/serverOn.png';
              } else {
                return 'img/serverOff.png';
              }
            }, function(err) {
              return null;
            });
          }
          ,
          versionInfo: function (Session) {
            return Session.getActualVersion().then(function (response) {
              return response;
            }, function (err) {
              return null;
            });
          }
        }
      })

      .state('pinPage', {
        cache: false,
        url: '/pinPage/:accountName/:firstPin',
        templateUrl: 'templates/pinlockNew.html',
        controller: 'pinCtrl',
        resolve: {
          accountName: function ($stateParams) {
            if (!$stateParams.accountName) return null;
            return $stateParams.accountName;
          },
          firstPin: function ($stateParams) {
            if (!$stateParams.firstPin) return null;
            return $stateParams.firstPin;
          }
        }
      })

      .state('choosingRegion', {
        cache: false,
        url: '/choosingRegionPage',
        // views: {
        // 'side-menu': {
        templateUrl: 'templates/regions.html',
        controller: 'regionCtrl'
        //   }
        // }
      })

      .state('choosingCircuit', {
        cache: false,
        url: '/choosingCircuitPage',
        templateUrl: 'templates/circuits.html',
        controller: 'circuitCtrl',
        resolve: {
          circuitList: function ($stateParams, CircuitService) {
            // return CircuitService.getList();
            return CircuitService.getList().then(function (circuitList) {
              return circuitList;
            })
          }
          // var list = CircuitService.getList();
          // return list;
        }
      })

      .state('menu.hunterOptions', {
        cache: false,
        url: '/hunterOptions',
        views: {
          'side-menu': {
            templateUrl: 'templates/hunterOptions.html',
            controller: 'hunterOptionsCtrl'
          }
        },
        resolve: {
          messagesCount: function (MessagesService) {
            return MessagesService.getAllMessagesCount();
          }
        }
      })

      .state('menu.map', {
        cache: false,
        url: '/map',
        views: {
          'side-menu': {
            templateUrl: 'templates/circuitsMap.html',
            controller: 'circuitsMapCtrl'
          }
        },
        resolve: {
          registerTypes: function (CircuitsMapService) {
            return CircuitsMapService.getRegisterTypesList();
          }
        }
      })

      .state('menu.newHunt', {
        cache: false,
        url: '/newHunt',
        views: {
          'side-menu': {
            templateUrl: 'templates/newHunt.html',
            controller: 'newHuntCtrl'
          }
        },
        resolve: {
          permits: function (NewHuntService) {
            return NewHuntService.getAllPermits(osobyId = null, type = null);
          }
        }
      })
      .state('menu.openHunt', {
        cache: false,
        url: '/openHunt',
        views: {
          'side-menu': {
            templateUrl: 'templates/openHuntList.html',
            controller: 'openHuntCtrl'
          }
        },
        resolve: {
          circuitList: function (CircuitService) {
            return CircuitService.getList()
              .then(function (result) {
                return result;
              })
          }
        }
      })

      .state('menu.myOpenHunt', {
        cache: false,
        url: '/myOpenHunt',
        views: {
          'side-menu': {
            templateUrl: 'templates/myOpenHuntList.html',
            controller: 'myOpenHuntCtrl'
          }
        },
      })

      .state('menu.myHunts', {
        cache: false,
        url: '/myHunts',
        views: {
          'side-menu': {
            templateUrl: 'templates/myHunts.html',
            controller: 'myHuntsCtrl'
          }
        },
        resolve: {
          years: function (MyHuntsService) {
            return MyHuntsService.getYearList();
          }
        }

      })

      .state('menu.openedHunt', {
        cache: false,
        url: '/openedHunt/:openHuntingId',
        views: {
          'side-menu': {
            templateUrl: 'templates/openedHuntForm.html',
            controller: 'openedHuntCtrl',
          }
        },
        resolve: {
          hunt: function ($stateParams, OpenedHuntService) {
            if (!$stateParams.openHuntingId) return null;
            return OpenedHuntService.getHuntingInfo($stateParams.openHuntingId);
          }
        }
      })
      .state('menu.shootingForm', {
        cache: false,
        url: '/shootingForm/:openHuntingId/shooting/permits/:pptype/districts',
        params: { shooting: null, permits: null, districts: null },
        views: {
          'side-menu': {
            templateUrl: 'templates/shootingForm.html',
            controller: 'shootingCtrl',
          }
        },
        resolve: {
          districts: function ($stateParams) {
            if (!$stateParams.districts) return null;
            return $stateParams.districts;
          },
          permits: function ($stateParams) {
            if (!$stateParams.permits) return null;
            return $stateParams.permits;
          },
          shooting: function ($stateParams) {
            if (!$stateParams.shooting) return null;
            var shooting = $stateParams.shooting;
            shooting[0].shotDate = new Date(shooting[0].shotDate);
            return shooting[0];
          },
          huntingId: function ($stateParams) {
            if (!$stateParams.openHuntingId) return null;
            return $stateParams.openHuntingId;
          },
          pptype: function ($stateParams) {
            if (!$stateParams.pptype) return null;
            return $stateParams.pptype;
          }
        }
      })
      .state('menu.annualPlan', {
        cache: false,
        url: '/annualPlan',
        views: {
          'side-menu': {
            templateUrl: 'templates/annualPlan.html',
            controller: 'annualPlanCtrl',
          }
        },
        resolve: {
          circuitList: function (AnnualPlanService) {
            return AnnualPlanService.getCircuits()
              .then(function (result) {
                return result;
              })
          }
        }
      })
      .state('menu.endHuntForm', {
        cache: false,
        url: '/endHuntForm/:openHuntingId/:endDate/:shotCount',
        views: {
          'side-menu': {
            templateUrl: 'templates/endHuntForm.html',
            controller: 'endHuntCtrl'
          }
        }
      })
      .state('menu.myPermissions', {
        cache: true,
        url: '/myPermissions',
        views: {
          'side-menu': {
            templateUrl: 'templates/myPermissions.html',
            controller: 'myPermissionsCtrl',
          }
        },
        resolve: {
          myPermissionsList: function (MyPermissionsService) {
            return MyPermissionsService.getMyPermissionsList(null)
              .then(function (result) {
                return result;
              })
          },
          years: function (MyHuntsService) {
            return MyHuntsService.getYearList();
          }
        }
      })

      .state('menu.circuitBook', {
        cache: false,
        url: '/circuitBook',
        views: {
          'side-menu': {
            templateUrl: 'templates/circuitBook.html',
            controller: 'circuitBookCtrl'
          }
        },
        resolve: {
          circuits: function (CircuitService) {
            return CircuitService.getList();
          },
          years: function (MyHuntsService) {
            return MyHuntsService.getYearList();
          }
        }
      })

      .state('menu.animalsList', {
        cache: false,
        url: '/permission',
        params: { permission: null },
        views: {
          'side-menu': {
            templateUrl: 'templates/animalsList.html',
            controller: 'animalsListCtrl'
          }
        },
        resolve: {
          permission: function ($stateParams) {
            if (!$stateParams.permission) return null;
            return $stateParams.permission;
          },
          animalsList: function (MyPermissionsService, $stateParams) {
            var permissionId = $stateParams.permission.ID;
            if (!permissionId) return null;
            return MyPermissionsService.getMyPermissionAnimals(permissionId);
          }
        }
      })

      .state('menu', {
        url: '/side-menu',
        abstract: true,
        templateUrl: 'templates/menu.html',
        controller: 'menuCtrl'
      })

      .state('menu.collectivePlanList', {
        cache: false,
        url: '/collectivePlanList',
        views: {
          'side-menu': {
            templateUrl: 'templates/collectivePlanList.html',
            controller: 'collectivePlanListCtrl'
          }
        },
        resolve: {
          collectivePlanList: function (CollectivePlanService) {
            return CollectivePlanService.getCollectivePlanList();
          }
        }
      })
      .state('menu.collectivePlanDetails', {
        cache: false,
        url: '/collectivePlanDetails/:id',
        views: {
          'side-menu': {
            templateUrl: 'templates/collectivePlanDetails.html',
            controller: 'collectivePlanDetailsCtrl'
          }
        },
        resolve: {
          collectivePlan: function (CollectivePlanService, $stateParams) {
            return CollectivePlanService.getCollectivePlanDetails($stateParams.id);
          }
        }
      })
      .state('menu.messages', {
        cache: false,
        url: '/messsages/{userNotifications:json}/{userMessages:json}',
        params: { userNotifications: null, userMessages: null },
        views: {
          'side-menu': {
            templateUrl: 'templates/messages.html',
            controller: 'messagesCtrl'
          }
        },
        resolve: {
          userNotifications: function (MessagesService, $stateParams) {
            return MessagesService.getUserNotifications('N', 1);
          },
          userMessages: function (MessagesService, $stateParams) {
            return MessagesService.getUserMessages(1);
          },
        }
      })
      .state('menu.colleagueHelp', {
        cache: false,
        url: '/colleagueHelp',
        views: {
          'side-menu': {
            templateUrl: 'templates/colleagueHelp.html',
            controller: 'colleagueHelpCtrl'
          }
        },
        resolve: {
          persons: function (ColleagueHelpService, $stateParams) {
            return ColleagueHelpService.getColleagueHelp();
          }
        }
      })
      .state('menu.userSettings', {
        cache: false,
        url: '/userSettings',
        views: {
          'side-menu': {
            templateUrl: 'templates/userSettings.html',
            controller: 'userSettingsCtrl'
          }
        },
        resolve: {
          settings: function (UserSettingsService, $stateParams) {
            return UserSettingsService.getUserSettings();
          }
        }
      })


      .state('menu.shiftCalendar', {
        cache: false,
        url: '/shiftCalendar',
        views: {
          'side-menu': {
            templateUrl: 'templates/shiftCalendar.html',
            controller: 'shiftCalendarCtrl'
          }
        },
        resolve: {
          years: function (MyHuntsService) {
            return MyHuntsService.getYearList();
          }
        }
      })

      .state('menu.payments', {
        cache: false,
        url: '/payments',
        views: {
          'side-menu': {
            templateUrl: 'templates/payments.html',
            controller: 'paymentsCtrl'
          }
        },
        resolve: {
          years: function (MyHuntsService) {
            return MyHuntsService.getYearList();
          }
        }
      })

      .state('menu.activityPlan', {
        cache: false,
        url: '/activityPlan',
        views: {
          'side-menu': {
            templateUrl: 'templates/activityPlan.html',
            controller: 'activityPlanCtrl'
          }
        },
        resolve: {
          years: function (MyHuntsService) {
            return MyHuntsService.getYearList();
          }
        }
      })

      .state('menu.registers', {
        cache: false,
        url: '/registers',
        views: {
          'side-menu': {
            templateUrl: 'templates/registers.html',
            controller: 'registersCtrl'
          }
        },
        resolve: {
          circuitList: function (CircuitService) {
            return CircuitService.getList().then(function (circuitList) {
              return circuitList;
            })
          },
          registerTypes: function (CircuitsMapService) {
            return CircuitsMapService.getRegisterTypesList();
          }
        }
      })

      .state('menu.ohzDemand', {
        cache: false,
        url: '/ohzDemand',
        views: {
          'side-menu': {
            templateUrl: 'templates/ohzDemand.html',
            controller: 'ohzDemandCtrl'
          }
        },
        resolve: {
          demands: function (OhzDemandService) {
            return OhzDemandService.getDemandZG();
          }
        }
      })
      .state('menu.ohzDemandDetails', {
        cache: false,
        url: '/ohzDemandDetails/:id',
        views: {
          'side-menu': {
            templateUrl: 'templates/ohzDemandDetails.html',
            controller: 'ohzDemandDetailsCtrl'
          }
        },
        resolve: {
          demandDetails: function (OhzDemandService, $stateParams) {
            return OhzDemandService.getDemandZGInfo($stateParams.id);
          }
        }
      })

      .state('menu.huntDamage', {
        cache: false,
        url: '/huntDamage',
        views: {
          'side-menu': {
            templateUrl: 'templates/huntDamage.html',
            controller: 'huntDamageCtrl'
          }
        },
        resolve: {
          circuits: function (CircuitService) {
            return CircuitService.getList();
          },
          farmers: function (HuntDamageService) {
            return HuntDamageService.getHuntDamageFarmers();
          },
          protocolNumber: function (HuntDamageService) {
            return HuntDamageService.getHuntDamageNewNumber();
          }
        }
      })

      .state('menu.damagesList', {
        cache: false,
        url: '/damagesList',
        views: {
          'side-menu': {
            templateUrl: 'templates/damagesList.html',
            controller: 'damagesListCtrl'
          }
        },
        resolve: {
          circuits: function (CircuitService) {
            return CircuitService.getList();
          },
          years: function (MyHuntsService) {
            return MyHuntsService.getYearList();
          }
        }
      })

      .state('menu.huntDamageDetails', {
        cache: false,
        url: '/huntDamageDetails/:id',
        views: {
          'side-menu': {
            templateUrl: 'templates/huntDamageDetails.html',
            controller: 'huntDamageDetailsCtrl'
          }
        },
        resolve: {
          huntDamage: function (HuntDamageService, $stateParams) {
            return HuntDamageService.getHuntDamageInfo($stateParams.id);
          }
        }
      })

      .state('menu.ddePrintForm', {
        cache: false,
        url: '/huntingId/:huntingId/animalId/:animalId',
        views: {
          'side-menu': {
            templateUrl: 'templates/ddePrintForm.html',
            controller: 'ddePrintCtrl'
          }
        },
        resolve: {
          dde: function (DDEPrintService, $stateParams) {
            return DDEPrintService.getDDE($stateParams.huntingId, $stateParams.animalId);
          }
        }
      })

    $urlRouterProvider.otherwise('/loginPage')



  });
