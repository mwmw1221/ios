angular.module('app.controllers')
    .controller('huntDamageCtrl', function ($scope, LocalStorage, circuits, Session, $cordovaGeolocation, $ionicPopup, $ionicLoading, $translate, $cordovaToast, Camera, MapUtils, farmers, HuntDamageService, $state, protocolNumber) {

        $scope.farmers = farmers;
        LOCAL_SETTINGS = LocalStorage.getObject("localSettings");
        $scope.circuits = circuits;
        var currentRegion = Session.getCurrentRegion();
        var map;

        var damage = damage || {
            circuitId: 'region' in LOCAL_SETTINGS && LOCAL_SETTINGS.region[currentRegion[0]] != null ? LOCAL_SETTINGS.region[currentRegion[0]] : circuits[0][0],
            farmerName: null,
            farmerContact: null,
            farmerId: null,
            cropType: null,
            protNr: protocolNumber || null,
            longitude: null,
            latitude: null,
            coords: null,
            date: null,
            file: []
        }

        var farmer = {
            "selected": {
                "ID": null,
                "NAZWA": null,
                "KONTAKT": null
            }
        }

        $scope.farmer = farmer;
        $scope.damage = damage;

        $scope.changeFarmer = function () {
            if (farmer.selected) {
                damage.farmerId = farmer.selected.ID;
                damage.farmerName = farmer.selected.NAZWA;
                damage.farmerContact = farmer.selected.KONTAKT;
            } else {
                damage.farmerId = null;
                damage.farmerName = null;
                damage.farmerContact = null;
            }
        }

        $scope.addHuntDamage = function () {
            HuntDamageService.addHuntDamage($scope.damage)
                .then(function (response) {
                    $translate('Saved').then($cordovaToast.showLongBottom);
                    $state.go('menu.damagesList');
                }, function (err) {
                    $cordovaToast.showLongBottom(err);
                })
        }

        $scope.openPopup = function () {
            showLocationPopup();
        }

        function isLocationAvailable() {
            cordova.plugins.diagnostic.isLocationEnabled(function (enabled) {
                if (enabled) {
                    getCurrentPosition();
                } else {
                    setDefaultPosition();
                }
            }, function (error) {
                $translate('AnErrorOccured').then($cordovaToast.showLongBottom);
                console.error("The following error occurred: " + error);
            });
        }

        function getLocationAuthorizationStatus() {
            cordova.plugins.diagnostic.getLocationAuthorizationStatus(function (status) {
                switch (status) {
                    case cordova.plugins.diagnostic.permissionStatus.NOT_REQUESTED:
                        console.log("Permission not requested");
                        requestLocationAuthorization();
                        break;
                    case cordova.plugins.diagnostic.permissionStatus.GRANTED:
                        console.log("Permission granted");
                        isLocationAvailable();
                        break;
                    case cordova.plugins.diagnostic.permissionStatus.DENIED:
                        requestLocationAuthorization();
                        console.log("Permission denied");
                        break;
                    case cordova.plugins.diagnostic.permissionStatus.DENIED_ALWAYS:
                        requestLocationAuthorization();
                        console.log("Permission permanently denied");
                        break;
                }
            }, function (error) {
                $translate('ErrorOccurredDownloadingLocationAuthorizationStatus').then($cordovaToast.showLongBottom);
                console.error("The following error occurred: " + error);
            });
        }

        function requestLocationAuthorization() {
            cordova.plugins.diagnostic.requestLocationAuthorization(function (status) {
                switch (status) {
                    case cordova.plugins.diagnostic.permissionStatus.NOT_REQUESTED:
                        console.log("Permission not requested");
                        break;
                    case cordova.plugins.diagnostic.permissionStatus.GRANTED:
                        $translate('PermissionsGranted').then($cordovaToast.showLongBottom);
                        console.log("Permission granted always");
                        isLocationAvailable();
                        break;
                    case cordova.plugins.diagnostic.permissionStatus.DENIED:
                        $translate('PermissionsHaveBeenDenied').then($cordovaToast.showLongBottom);
                        console.log("Permission denied");
                        break;
                    case cordova.plugins.diagnostic.permissionStatus.DENIED_ALWAYS:
                        console.log("Permission permanently denied");
                        break;
                }
            }, function (error) {
                $translate('ErrorGrantingPermissions').then($cordovaToast.showLongBottom);
                console.error(error);
            });
        }

        function showLocationPopup() {
            locationPopup = $ionicPopup.show({
                templateUrl: 'templates/shootingLocation.html',
                title: $translate.instant('MarkLocationOfDamage'),
                scope: $scope,
                buttons: [
                    {
                        text: 'OK',
                        type: 'button-positive',
                        onTap: function (e) {
                            var position = currentPositionMarker.getLatLng();
                            damage.latitude = position.lat;
                            damage.longitude = position.lng;
                            $ionicLoading.hide();
                        }
                    },
                    {
                        text: $translate.instant('Cancel'),
                        onTap: function (e) {
                            $ionicLoading.hide();
                            return true;
                        }
                    }
                ]
            });
        }

        function addMapTypes() {
            var baseLayers = MapUtils.getBaseLayers();
            var overlays = MapUtils.getOverlays();
            baseLayers["OpenStreetMap"].addTo(map);
            L.control.layers(baseLayers, overlays).addTo(map);

            map.on('baselayerchange', function (e) {
                if (e.name == "ArcGis" || e.name == 'Orto') {
                    baseLayers["ArcGIS2"].addTo(map);
                } else {
                    baseLayers["ArcGIS2"].remove();
                }
            });
        }

        $scope.initMap = function () {
            initMap();
            getLocationAuthorizationStatus();
        }

        function initMap() {
            var elementId = document.getElementById("shootingMap");
            var element = document.getElementById(elementId);
            map = L.map(elementId).setView([52, 20], 12);
            addMapTypes();
        }

        var currentPositionMarker;

        var currentPositionOptions = {
            timeout: 20000,
            enableHighAccuracy: true,
            maximumAge: 0,
        };

        function getCurrentPosition() {
            $ionicLoading.show();
            $cordovaGeolocation.getCurrentPosition(currentPositionOptions)
                .then(onSuccessPosition, onErrorPosition);
        };

        function onSuccessPosition(position) {
            var lat = damage.latitude == null ? position.coords.latitude : damage.latitude;
            var long = damage.longitude == null ? position.coords.longitude : damage.longitude;
            currentPositionMarker = createMarker(lat, long);
            currentPositionMarker.addTo(map);
            map.panTo(currentPositionMarker.getLatLng());
            $ionicLoading.hide();
        }

        function setDefaultPosition() {
            var lat = 52.94;
            var long = 18.66;
            currentPositionMarker = createMarker(lat, long);
            currentPositionMarker.addTo(map);
            map.panTo(currentPositionMarker.getLatLng());
            $ionicLoading.hide();
        }

        function onErrorPosition(err) {
            $translate('RetrievingLocationError').then($cordovaToast.showLongBottom);
            console.log(err);
            $ionicLoading.hide();
        }

        function createMarker(lat, lng) {
            return L.marker([lat, lng], { draggable: true });
        }

        $scope.showPhotoFormPopup = function () {
            var myPopup = $ionicPopup.show({
                title: $translate.instant('AddingPhoto'),
                scope: $scope,
                buttons: [
                    {
                        text: '<i class="icon ion-camera"></i>',
                        type: 'button-positive',
                        onTap: function (e) {
                            $scope.addPhoto(1);
                            return null;
                        }
                    },
                    {
                        text: '<i class="icon ion-image"></i>',
                        type: 'button-positive',
                        onTap: function (e) {
                            $scope.addPhoto(0);
                            return null;
                        }
                    }
                ]
            });
        };

        $scope.addPhoto = function (source) {
            Camera.getPicture(source).then(function (response) {
                var name = response.split("/");
                var file = {
                    name: name[name.length - 1],
                    url: response
                }
                Camera.resolveFile(file.url).then(function (response) {
                    $scope.damage.file.push(response);
                    $translate('Saved').then($cordovaToast.showLongBottom);
                }, function (err) {
                    console.log(err);
                });
            }, function (err) {
                console.log(err);
                $cordovaToast.showLongBottom(err);
            });
        };

 
    });