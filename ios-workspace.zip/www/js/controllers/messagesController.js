angular.module('app.controllers')
    .controller('messagesCtrl', function ($rootScope, $scope, $state, MessagesService, userNotifications, userMessages, $ionicScrollDelegate, $translate, $ionicPopup, $base64, $http, $cordovaToast) {
        $scope.notificationsToDelete = [];
        $scope.notificationSelectingMode = false;

        $scope.messagesToDelete = [];
        $scope.messageSelectingMode = false;

        $scope.userNotifications = userNotifications;
        $scope.userMessages = userMessages;

        $scope.loadMoreNotificationsAvailable = $scope.userNotifications.count > 10 ? true : false;
        $scope.loadMoreMessagesAvailable = $scope.userMessages.count > 10 ? true : false;

        $scope.loadMoreAvailable = $scope.loadMoreNotificationsAvailable || $scope.loadMoreMessagesAvailable;

        $scope.userMessagesPage = 1;
        $scope.userNotificationsPage = 1;

        $scope.userNotificationsCode = 'N';

        $scope.filters = {
            showAll: false
        };

        $scope.sliderButtons = [
            { name: $translate.instant('Notifications'), active: true },
            { name: $translate.instant('Messages'), active: false }
        ];

        $scope.slide = function (to) {
            if (to === 0) {
                $scope.sliderButtons[to].active = true;
                $scope.sliderButtons[1].active = false;
            } else {
                $scope.sliderButtons[to].active = true;
                $scope.sliderButtons[0].active = false;
            }
        }

        $scope.$watch('filters.showAll', function (newValue, oldValue) {
            if (oldValue === newValue) return;

            if (newValue == true) {
                $scope.userNotificationsCode = 'A';
                $scope.userNotificationsPage = 1;
                loadUserNotifications('A', 1);

            } else {
                $scope.userNotificationsCode = 'N';
                $scope.userNotificationsPage = 1;
                loadUserNotifications('N', 1);
            }
        });

        function loadUserNotifications(code, page) {
            MessagesService.getUserNotifications(code, page)
                .then(function (response) {
                    $scope.userNotifications = response;
                    $scope.loadMoreNotificationsAvailable = $scope.userNotifications.count > 10 ? true : false;
                });
        }

        $scope.loadMore = function () {
            if ($scope.sliderButtons[0].active && $scope.loadMoreNotificationsAvailable) {
                $scope.userNotificationsPage++;
                MessagesService.getUserNotifications($scope.userNotificationsCode, $scope.userNotificationsPage).then(function (response) {
                    if (response.data.length > 0) {
                        $scope.userNotifications.data = $scope.userNotifications.data.concat(response.data);
                        if ($scope.userNotifications.count > $scope.userNotifications.data.length) {
                            $scope.loadMoreNotificationsAvailable = true;
                        } else {
                            $scope.loadMoreNotificationsAvailable = false;
                        }
                    } else {
                        $scope.loadMoreNotificationsAvailable = false;
                    }
                }).finally(function () {
                    $scope.$broadcast("scroll.infiniteScrollComplete");
                });
            } else if ($scope.sliderButtons[1].active && $scope.loadMoreMessagesAvailable) {
                $scope.userMessagesPage++;
                MessagesService.getUserMessages($scope.userMessagesPage).then(function (response) {
                    if (response.data.length > 0) {
                        $scope.userMessages.data = $scope.userMessages.data.concat(response.data);
                        if ($scope.userMessages.count > $scope.userMessages.data.length) {
                            $scope.loadMoreMessagesAvailable = true;
                        } else {
                            $scope.loadMoreMessagesAvailable = false;
                        }
                    } else {
                        $scope.loadMoreMessagesAvailable = false;
                    }
                }).finally(function () {
                    $scope.$broadcast("scroll.infiniteScrollComplete");
                });
            }
            $scope.$broadcast("scroll.infiniteScrollComplete");
        }

        $scope.toggleSection = function (i) {
            if (!$scope.messageSelectingMode) {
                $scope.userMessages.data[i].clicked = !$scope.userMessages.data[i].clicked;
                if ($scope.userMessages.data[i].clicked) {
                    if (!$scope.userMessages.data[i].message) {
                        MessagesService.getUserMessage($scope.userMessages.data[i].id).then(function (response) {
                            $scope.userMessages.data[i].message = response;
                            MessagesService.getAllMessagesCount().then(function (response) {
                                $rootScope.messagesCount = response;
                            })
                        })
                    }
                    $scope.userMessages.data[i].is_unread = 'N';
                }
            }
        }

        $scope.checkIfAvailable = function () {
            if (($scope.sliderButtons[0].active === true && $scope.loadMoreNotificationsAvailable)
                || ($scope.sliderButtons[1].active === true && $scope.loadMoreMessagesAvailable)) {
                return true;
            }
            return false;
        }

        $scope.showDeleteMessagePopup = function (index) {
            var pop = $ionicPopup.show({
                title: $translate.instant('DeletingMessage'),
                subTitle: $translate.instant('AreYouSureYouWantToDeleteTheMessage'),
                scope: $scope,
                buttons: [
                    {
                        text: $translate.instant('No'),
                        onTap: function (e) {
                            return null
                        }
                    }, {
                        text: $translate.instant('Yes'),
                        type: 'button-assertive',
                        onTap: function (e) {
                            $scope.deleteMessage($scope.userMessages.data[index].id);
                            $scope.userMessages.data.splice(index, 1);
                        }
                    }
                ]
            });
        }

        $scope.showDeleteMessagesPopup = function () {
            var pop = $ionicPopup.show({
                title: $translate.instant('DeletingMessage'),
                subTitle: $translate.instant('AreYouSureYouWantToDeleteTheMessage'),
                scope: $scope,
                buttons: [
                    {
                        text: $translate.instant('No'),
                        onTap: function (e) {
                            return null
                        }
                    }, {
                        text: $translate.instant('Yes'),
                        type: 'button-assertive',
                        onTap: function (e) {
                            $scope.deleteMessages($scope.messagesToDelete);
                        }
                    }
                ]
            });
        }

        $scope.deleteMessage = function (messageId) {
            MessagesService.deleteUserMessage(messageId).then(function (response) {
                MessagesService.getAllMessagesCount().then(function (response) {
                    $rootScope.messagesCount = response;
                })
            })
        }
        $scope.deleteMessages = function (ids) {
            MessagesService.deleteUserMessage(ids).then(function (response) {
                MessagesService.getAllMessagesCount().then(function (response) {
                    $rootScope.messagesCount = response;
                    $state.reload();
                })
            })
        }

        $scope.showDeleteNotificationPopup = function (index) {
            var pop = $ionicPopup.show({
                title: $translate.instant('DeletingMessage'),
                subTitle: $translate.instant('AreYouSureYouWantToDeleteTheMessage'),
                scope: $scope,
                buttons: [
                    {
                        text: $translate.instant('No'),
                        onTap: function (e) {
                            return null
                        }
                    }, {
                        text: $translate.instant('Yes'),
                        type: 'button-assertive',
                        onTap: function (e) {
                            $scope.deleteNotification($scope.userNotifications.data[index].ID);
                            $scope.userNotifications.data.splice(index, 1);
                        }
                    }
                ]
            });
        }

        $scope.showDeleteNotificationsPopup = function () {
            var pop = $ionicPopup.show({
                title: $translate.instant('DeletingMessage'),
                subTitle: $translate.instant('AreYouSureYouWantToDeleteTheMessage'),
                scope: $scope,
                buttons: [
                    {
                        text: $translate.instant('No'),
                        onTap: function (e) {
                            return null
                        }
                    }, {
                        text: $translate.instant('Yes'),
                        type: 'button-assertive',
                        onTap: function (e) {
                            $scope.deleteNotifications($scope.notificationsToDelete);
                        }
                    }
                ]
            });
        }

        $scope.deleteNotifications = function (ids) {
            MessagesService.setNotificationDelete(ids).then(function (response) {
                MessagesService.getAllMessagesCount().then(function (response) {
                    $rootScope.messagesCount = response;
                    $state.reload();
                })
            })
        }

        $scope.deleteNotification = function (notifiId) {
            MessagesService.setNotificationDelete(notifiId).then(function (response) {
                MessagesService.getAllMessagesCount().then(function (response) {
                    $rootScope.messagesCount = response;
                })
            })
        }

        $scope.setNotificationRead = function (index) {
            if ($scope.userNotifications.data[index].IS_READ == 'N') {
                MessagesService.setNotificationRead($scope.userNotifications.data[index].ID).then(function (response) {
                    $scope.userNotifications.data[index].IS_READ = 'Y';
                    MessagesService.getAllMessagesCount().then(function (response) {
                        $rootScope.messagesCount = response;
                    })
                })
            }
        }

        var getAttachment = function (url) {
            return $http({
                method: 'GET',
                url: url,
                responseType: 'arraybuffer',
                /* depends on environment */
                // headers: {
                //     'Authorization': 'Basic ' + $base64.encode('jpalio' + ':' + 'Torn')
                // }
            }).then(function (response) {
                var str = _arrayBufferToBase64(response.data);
                return str;
            }, function (response) {
                console.error('error in getting static img.');
            });
        };

        function _arrayBufferToBase64(buffer) {
            var binary = '';
            var bytes = new Uint8Array(buffer);
            var len = bytes.byteLength;
            for (var i = 0; i < len; i++) {
                binary += String.fromCharCode(bytes[i]);
            }
            return window.btoa(binary);
        }

        $scope.openAttachment = function (url, filename, contentType) {
            window.open(url, '_system', 'location=no');
        }

        function b64toBlob(b64Data, contentType, sliceSize) {
            contentType = contentType || '';
            sliceSize = sliceSize || 512;
            var byteCharacters = atob(b64Data);
            var byteArrays = [];

            for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
                var slice = byteCharacters.slice(offset, offset + sliceSize);
                var byteNumbers = new Array(slice.length);
                for (var i = 0; i < slice.length; i++) {
                    byteNumbers[i] = slice.charCodeAt(i);
                }
                var byteArray = new Uint8Array(byteNumbers);
                byteArrays.push(byteArray);
            }

            var blob = new Blob(byteArrays, { type: contentType });
            return blob;
        }

        /**
         * Create a PDF file according to its database64 content only.
         * 
         * @param filename {String} The name of the file that will be created
         * @param content {Base64 String} Important : The content can't contain the following string (data:application/pdf;base64). Only the base64 string is expected.
         * @param contentType mime type of file
         */
        function saveBase64AsPDF(filename, content, contentType) {
            var folderpath;
            switch (device.platform) {
                case "Android":
                    folderpath = 'file:///storage/emulated/0/Download/';
                    break;
                case "iOS":
                    folderpath = cordova.file.documentsDirectory;
                    break;
            }
            var DataBlob = b64toBlob(content, contentType);
            window.resolveLocalFileSystemURL(folderpath, function (dir) {
                dir.getFile(filename, { create: true }, function (file) {
                    file.createWriter(function (fileWriter) {
                        $translate('FileDownloaded').then($cordovaToast.showLongBottom);
                        fileWriter.write(DataBlob);
                    }, function () {
                        $translate('ProblemWithSavingFile').then($cordovaToast.showLongBottom);
                    });
                });
            });
        }


        $scope.addSelectedNotification = function (notification) {
            if (notification.selected) {
                notification.selected = false;
                $scope.notificationsToDelete.splice($scope.notificationsToDelete.indexOf(notification.ID), 1);
            } else {
                notification.selected = true;
                $scope.notificationsToDelete.push(notification.ID);
            }
            if ($scope.notificationsToDelete.length > 0) {
                $scope.notificationSelectingMode = true;
            } else {
                $scope.notificationSelectingMode = false;
            }
        }

        $scope.addSelectedMessage = function (message) {
            if (message.selected) {
                message.selected = false;
                $scope.messagesToDelete.splice($scope.notificationsToDelete.indexOf(message.id), 1);
            } else {
                message.selected = true;
                $scope.messagesToDelete.push(message.id);
            }
            if ($scope.messagesToDelete.length > 0) {
                $scope.messageSelectingMode = true;
            } else {
                $scope.messageSelectingMode = false;
            }
        }

        $scope.selectAll = function () {
            if ($scope.filters.selectAll) {
                if ($scope.sliderButtons[0].active) {
                    for (var n in $scope.userNotifications.data) {
                        $scope.notificationsToDelete.push($scope.userNotifications.data[n].ID);
                        $scope.userNotifications.data[n].selected = true;
                    }
                } else if ($scope.sliderButtons[1].active) {
                    for (var n in $scope.userMessages.data) {
                        $scope.messagesToDelete.push($scope.userMessages.data[n].ID);
                        $scope.userMessages.data[n].selected = true;
                    }
                }
            } else if (!$scope.filters.selectAll) {
                if ($scope.notificationsToDelete.length > 0 && $scope.sliderButtons[0].active) {
                    $scope.notificationsToDelete = [];
                    for (var n in $scope.userNotifications.data) {
                        $scope.userNotifications.data[n].selected = false;
                    }
                    $scope.notificationSelectingMode = false;
                } else if ($scope.messagesToDelete.length > 0 && $scope.sliderButtons[1].active) {
                    $scope.messagesToDelete = [];
                    for (var n in $scope.userMessages.data) {
                        $scope.userMessages.data[n].selected = false;
                    }
                    $scope.messageSelectingMode = true;
                }
            }
        }
    })
    .directive('slideable', function () {
        return {
            restrict: 'C',
            compile: function (element, attr) {
                // wrap tag
                var contents = element.html();
                element.html('<div class="slideable_content" style="margin:0 !important; padding:0 !important" >' + contents + '</div>');

                return function postLink(scope, element, attrs) {
                    // default properties
                    attrs.duration = (!attrs.duration) ? '1s' : attrs.duration;
                    attrs.easing = (!attrs.easing) ? 'ease-in-out' : attrs.easing;
                    element.css({
                        'overflow': 'hidden',
                        'height': '0px',
                        'transitionProperty': 'height',
                        'transitionDuration': attrs.duration,
                        'transitionTimingFunction': attrs.easing
                    });
                };
            }
        };
    })
    .directive('slideToggle', function () {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                var target = document.querySelector(attrs.slideToggle);
                attrs.expanded = false;
                element.bind('click', function () {
                    var content = target.querySelector('.slideable_content');
                    if (!attrs.expanded) {
                        content.style.border = '1px solid rgba(0,0,0,0)';
                        var y = content.clientHeight;
                        content.style.border = 0;
                        target.style.height = y + 'px';
                    } else {
                        target.style.height = '0px';
                    }
                    attrs.expanded = !attrs.expanded;
                });
            }
        }
    })
    .directive('clickForOptionsWrapper', [function () {
        return {
            restrict: 'A',
            controller: function ($scope) {
                this.closeOptions = function () {
                    $scope.$broadcast('closeOptions');
                }
            }
        };
    }])

    .directive('clickForOptions', ['$ionicGesture', function ($ionicGesture) {
        return {
            restrict: 'A',
            scope: false,
            require: '^clickForOptionsWrapper',
            link: function (scope, element, attrs, parentController) {
                // A basic variable that determines wether the element was currently clicked
                var clicked;

                // Set an initial attribute for the show state
                attrs.$set('optionButtons', 'hidden');

                // Grab the content
                var content = element[0].querySelector('.item-content');
                // Grab the buttons and their width
                var buttons = element[0].querySelector('.item-options');

                var closeAll = function () {
                    element.parent()[0].$set('optionButtons', 'show');
                };

                // Add a listener for the broadcast event from the parent directive to close
                var previouslyOpenedElement;
                scope.$on('closeOptions', function () {
                    if (!clicked) {
                        attrs.$set('optionButtons', 'hidden');
                    }
                });

                // Function to show the options
                var showOptions = function () {
                    if (!scope.notificationSelectingMode) {
                        // close all potentially opened items first
                        parentController.closeOptions();

                        var buttonsWidth = buttons.offsetWidth;
                        ionic.requestAnimationFrame(function () {
                            // Add the transition settings to the content
                            content.style[ionic.CSS.TRANSITION] = 'all ease-out .25s';

                            // Make the buttons visible and animate the content to the left
                            buttons.classList.remove('invisible');
                            content.style[ionic.CSS.TRANSFORM] = 'translate3d(-' + buttonsWidth + 'px, 0, 0)';

                            // Remove the transition settings from the content
                            // And set the "clicked" variable to false
                            setTimeout(function () {
                                content.style[ionic.CSS.TRANSITION] = '';
                                clicked = false;
                            }, 250);
                        });
                    }
                };

                // Function to hide the options
                var hideOptions = function () {
                    var buttonsWidth = buttons.offsetWidth;
                    ionic.requestAnimationFrame(function () {
                        // Add the transition settings to the content
                        content.style[ionic.CSS.TRANSITION] = 'all ease-out .25s';

                        // Move the content back to the original position
                        content.style[ionic.CSS.TRANSFORM] = '';

                        // Make the buttons invisible again
                        // And remove the transition settings from the content
                        setTimeout(function () {
                            buttons.classList.add('invisible');
                            content.style[ionic.CSS.TRANSITION] = '';
                        }, 250);
                    });
                };

                // Watch the open attribute for changes and call the corresponding function
                attrs.$observe('optionButtons', function (value) {
                    if (value == 'show') {
                        showOptions();
                    } else {
                        hideOptions();
                    }
                });

                // Change the open attribute on tap
                $ionicGesture.on('tap', function (e) {
                    clicked = true;
                    if (attrs.optionButtons == 'show') {
                        attrs.$set('optionButtons', 'hidden');
                    } else {
                        attrs.$set('optionButtons', 'show');
                    }
                }, element);
            }
        };

    }]);
