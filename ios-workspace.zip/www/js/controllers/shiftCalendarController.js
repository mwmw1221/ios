angular.module('app.controllers')
    .controller('shiftCalendarCtrl', function ($scope, $http, $state, years, ShiftCalendarService) {
        $scope.years = years;
        $scope.data = {
            year: $scope.years[0].value
        }

        $scope.loadShifts = function (year) {
            ShiftCalendarService.getUserShifts(year)
                .then(function (response) {
                    $scope.shifts = response;
                });
        }

        $scope.loadShifts($scope.data.year);
    });