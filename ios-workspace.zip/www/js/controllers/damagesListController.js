angular.module('app.controllers')
    .controller('damagesListCtrl', function ($scope, circuits, years, LocalStorage, Session, HuntDamageService, $state) {
        LOCAL_SETTINGS = LocalStorage.getObject("localSettings");
        var currentRegion = Session.getCurrentRegion();

        var data = {
            cId: 'region' in LOCAL_SETTINGS && LOCAL_SETTINGS.region[currentRegion[0]] != null ? LOCAL_SETTINGS.region[currentRegion[0]] : null,
            year: years[0].value,
        };

        $scope.data = data;

        $scope.circuits = circuits;
        $scope.years = years;
        $scope.damages = null;

        function loadDamages(cId, year) {
            HuntDamageService.getHuntDamages(cId, year)
                .then(function (response) {
                    $scope.damages = response;
                }, function (err) {

                });
        }

        if ($scope.data.cId != null) {
            loadDamages(data.cId, data.year);
        }

        $scope.loadDamages = function (cId, year) {
            if (cId != null && year != null)
                loadDamages(cId, year);
        }

        $scope.addDamage = function () {
            $state.go('menu.huntDamage');
        }

        $scope.viewDamage = function (id) {
            HuntDamageService.getHuntDamageInfo(id)
                .then(function (response) {
                    console.log(response);
                }, function (err) {
                    console.log(err);
                });
        }
    });