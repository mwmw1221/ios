angular.module('app.controllers')
    .controller('circuitCtrl', function ($scope, $http, $state, ApiEndpoint, CircuitService, LocalStorage, circuitList) {
        $scope.circuitList = circuitList;

        $scope.chooseCircuit = function () {
            CircuitService.setCurrentCircuit($scope.data.circuit);
            $state.go('hunterOptions');
        }

        $scope.data = {};

        // CircuitService.getList().then(function (circuitList) {
        //     $scope.circuitList = circuitList;
        // })
    });