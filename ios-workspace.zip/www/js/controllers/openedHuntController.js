angular.module('app.controllers')
    .controller('openedHuntCtrl', function ($scope, $ionicPopup, $ionicHistory, $http, $state, $stateParams, $cordovaToast, ApiEndpoint, OpenedHuntService, ionicTimePicker, hunt, Camera, Session, $rootScope, $ionicModal, UtilsService, $translate) {

        $rootScope.cameraOn = false;

        hunt = hunt || {
            'NRPOLOW': null,
            'DATAOD': null,
            'DATADO': null,
            'DATAPRZEDL': null,
            'DATAROZP': null,
            'DATAZAKON': null,
            'REWIR': null,
            'REJON': null,
            'POZWOLENIEID': null,
            'animals': null,
            'permits': null,
            'districts': null,
            'possibleToDelete': false,
            'PPTYPE': null,
            'UWAGIMYSLIWY': null
        };
        $scope.pictures = [];
        $scope.permitsString = '';
        $scope.hunt = hunt;
        $scope.fileList;
        $scope.fileType;

        $scope.huntingId = $stateParams.openHuntingId;
        $scope.plannedDateEdit = false;
        $scope.editPlannedDate = function () {
            $scope.plannedDateEdit = true;
        }

        $scope.cancel = function () {
            $scope.plannedDateEdit = false;
        }

        $scope.dateChange = {
            huntingId: $scope.huntingId
        };

        if (hunt.permits) {
            for (var i = 0; i < hunt.permits.length; i++) {
                $scope.permitsString += hunt.permits[i][1] + ' \n';
            }
        }
        if (hunt.POZWOLENIEID) {
            if (hunt.POZWOLENIEID) {
                OpenedHuntService.getAnimalsRequest(hunt.POZWOLENIEID).then(function (result) {
                    OpenedHuntService.setAnimals(result);
                })
            }
        }

        $scope.changePlannedEndDate = function (huntingId) {
            $scope.dateChange.huntingId = huntingId;
            $scope.dateChange.endDate.setHours(0, -$scope.dateChange.endDate.getTimezoneOffset(), 0, 0);
            $scope.dateChange.endDate = $scope.dateChange.endDate.toISOString().substring(0, 10);
            $scope.dateChange.endTime = UtilsService.convertDateToTime($scope.dateChange.endTime);

            OpenedHuntService.changePlannedEndDate($scope.dateChange).then(function (result) {
                if (result.action) {
                    $translate('DateHasBeenChanged').then($cordovaToast.showLongBottom);
                    $scope.plannedDateEdit = false;
                    $state.reload();
                }
            })
        }

        function deleteHunting(huntingId) {
            OpenedHuntService.deleteHunting(huntingId).then(function (response) {
                $translate('HuntingRemoved').then($cordovaToast.showLongBottom);
                $ionicHistory.goBack();
            })
        }

        $scope.showDeleteHuntingPopup = function (huntingId) {
            // Custom popup
            var myPopup = $ionicPopup.show({
                title: $translate.instant('RemoveHunting'),
                subTitle: $translate.instant('AreYouSureYouWantToRemoveTheHunt'),
                buttons: [
                    { text: $translate.instant('Cancel') }, {
                        text: '<b>' + $translate.instant('Yes') + '</b>',
                        type: 'button-positive',
                        onTap: function (e) {
                            deleteHunting(huntingId);
                        }
                    }
                ]
            });
        };

        $scope.showDeletePopup = function (huntingId, animalId) {
            // Custom popup
            var myPopup = $ionicPopup.show({
                title: $translate.instant('RemoveGame'),
                subTitle: $translate.instant("AreYouSureYouWantDeleteGame"),
                buttons: [
                    { text: $translate.instant('Cancel') }, {
                        text: '<b>' + $translate.instant('Yes') + '</b>',
                        type: 'button-positive',
                        onTap: function (e) {
                            OpenedHuntService.dropAnimal(huntingId, animalId).then(function (result) {
                                $translate('Removed').then($cordovaToast.showLongBottom);
                                $state.reload();
                            })
                        }
                    }
                ]
            });
        };

        /* Camera module */
        $scope.uploadPhoto = function (huntingId, fileTypeId, source) {
            var self = this;
            $rootScope.cameraOn = true;
            Camera.getPicture(source).then(function (response) {
                Camera.uploadPhoto(response, self.huntingId, null, self.fileTypeId).then(function (result) {
                    console.log(result);
                    $cordovaToast.showLongBottom(result);
                    refreshFileList(huntingId);
                }, function (err) {
                    $cordovaToast.showLongBottom(err);
                })
            }, function (err) {
                console.log(err);
                $cordovaToast.showLongBottom(err);
            });
        };

        function getFileList(huntingId) {
            OpenedHuntService.getFileList(huntingId).then(function (response) {
                $scope.fileList = response;
            }, function (err) {
                console.log(err);
            })
        }

        function refreshFileList(huntingId) {
            $scope.fileList = null;
            getFileList(huntingId);
        }

        $scope.showImageModal = function (photoUrl) {
            getImg(photoUrl).then(function (response) {
                $scope.photoUrl = response;
                $ionicModal.fromTemplateUrl('templates/imagePopover.html', {
                    scope: $scope,
                    animation: 'slide-in-up'
                }).then(function (modal) {
                    $scope.modal = modal;
                    $scope.modal.show();
                });
            })
        }

        // Close the modal
        $scope.closeModal = function () {
            $scope.modal.hide();
            $scope.modal.remove()
        };

        var getImg = function (url) {
            // Angular $http() and then() both return promises themselves 
            return $http({
                method: 'GET',
                url: ApiEndpoint.HOST + url,
                responseType: 'arraybuffer'
            }).then(function (response) {
                var str = _arrayBufferToBase64(response.data);
                console.log(str);
                return str;
            }, function (response) {
                console.error('error in getting static img.');
            });
        };

        function _arrayBufferToBase64(buffer) {
            var binary = '';
            var bytes = new Uint8Array(buffer);
            var len = bytes.byteLength;
            for (var i = 0; i < len; i++) {
                binary += String.fromCharCode(bytes[i]);
            }
            return window.btoa(binary);
        }

        getFileList($scope.huntingId);

        $scope.enabledChangeDescription = false;

        var temporaryDescription = '';

        $scope.enableChangeDescription = function (enabled) {
            temporaryDescription = $scope.hunt.UWAGIMYSLIWY;
            $scope.enabledChangeDescription = enabled;
        };

        $scope.cancelChangeDescription = function () {
            $scope.hunt.UWAGIMYSLIWY = temporaryDescription;
            $scope.enabledChangeDescription = false;
        };

        $scope.changeHuntingDescription = function () {
            OpenedHuntService.changeHuntingDescription($scope.huntingId, $scope.hunt.UWAGIMYSLIWY).then(
                function (response) {
                    $scope.enableChangeDescription(false);
                }, function (err) {
                    $scope.enableChangeDescription(false);
                })
        };

        $scope.showPhotoFormPopup = function () {
            $scope.fileTypes = UtilsService.getFileTypes().then(
                function (response) {
                    $scope.fileTypes = response;
                })

            var myPopup = $ionicPopup.show({
                templateUrl: 'templates/photoFormPopup.html',
                title: $translate.instant('AddingPhoto'),
                scope: $scope,
                buttons: [
                    {
                        text: '<i class="icon ion-camera"></i>',
                        type: 'button-positive',
                        onTap: function (e) {
                            $scope.uploadPhoto($scope.huntingId, $scope.fileType, 1);
                        }
                    },
                    {
                        text: '<i class="icon ion-image"></i>',
                        type: 'button-positive',
                        onTap: function (e) {
                            $scope.uploadPhoto($scope.huntingId, $scope.fileType, 0);
                        }
                    }
                ]
            });
        };

        $scope.updateShotCount = function () {
            OpenedHuntService.updateShotCount($scope.huntingId, $scope.hunt.LICZBA_STRZALOW)
                .then(function (response) {
                    if (response.action) {
                        $translate('Saved').then($cordovaToast.showLongBottom);
                    }
                })
        }
    })
    .directive('textarea', function () {
        return {
            restrict: 'E',
            link: function (scope, element, attr) {
                var update = function () {
                    element.css("height", "auto");
                    var height = element[0].scrollHeight;
                    element.css("height", element[0].scrollHeight + "px");
                };
                scope.$watch(attr.ngModel, function () {
                    update();
                });
            }
        };
    });