angular.module('app.controllers')
    .controller('userSettingsCtrl', function ($scope, $rootScope, settings, UserSettingsService, $translate, $cordovaToast, LocalStorage, $state, CircuitService, Session, BiometricsService) {
        $scope.form = {};
        $scope.settings = settings;

        var currentRegion = Session.getCurrentRegion();
        $scope.currentRegion = currentRegion;

        CircuitService.getList().then(function (result) {
            $scope.circuits = result;
        });

        $scope.languages = [
            {
                key: "pl",
                value: $translate.instant('Polish')
            }, {
                key: "en",
                value: $translate.instant('English')
            },
            {
                key: "de",
                value: $translate.instant('German')
            }];

        $scope.inactivityTimes = [
            {
                key: "1",
                value: 1
            }, {
                key: "30",
                value: 30
            }
        ]
       
        $scope.localSettings = LocalStorage.getObject("localSettings");

        // Biometric related local options
        var currentUser = LocalStorage.getObject("user") || {};
        $scope.currentUserLogin = currentUser.login || currentUser.username || null;
        $scope.userBiometricsEnabled = false;
        $scope.localSettings.autoBiometrics = $scope.localSettings.autoBiometrics || false;

        if ($scope.currentUserLogin) {
            $scope.userBiometricsEnabled = BiometricsService.isBiometricsEnabled($scope.currentUserLogin);
            // keep autologin consistent with service storage
            $scope.localSettings.autoBiometrics = BiometricsService.isAutologinEnabled($scope.currentUserLogin) || $scope.localSettings.autoBiometrics;
        }

        if (!$scope.localSettings.language) {
            $scope.localSettings.language = $rootScope.language;
        }

        function changeLanguage() {
            $translate.use(($scope.localSettings.language).split("-")[0]).then(function (data) {
                $rootScope.language = data;
                UserSettingsService.setLanguage(data)
                    .then(function (response) {
                        $translate('Saved').then($cordovaToast.showLongBottom);
                        $state.reload();
                    })
            }, function (error) {
            });
        }

        $scope.saveSettings = function () {
            if ($scope.form.settings.$dirty) {
                UserSettingsService.saveUserSettings($scope.settings)
                    .then(function (response) {
                        if (response.succes) {
                            $scope.form.settings.$setPristine();
                        }
                    });
            }
            if ($scope.form.localSettings.$dirty) {
                LocalStorage.setObject("localSettings", $scope.localSettings);
                if ($scope.form.localSettings.language.$dirty) {
                    changeLanguage();
                }
                $scope.form.localSettings.$setPristine();
            }
            // Always persist autologin biometric preference for current user if available
            // (biometric toggle changes are tracked independently of form dirty state)
            if ($scope.currentUserLogin) {
                BiometricsService.setAutologin($scope.currentUserLogin, !!$scope.localSettings.autoBiometrics);
            }
            $translate('Saved').then($cordovaToast.showLongBottom);
        }

        $scope.toggleUserBiometrics = function() {
            if (!$scope.currentUserLogin) return;
            if ($scope.userBiometricsEnabled) {
                BiometricsService.disableBiometrics($scope.currentUserLogin);
                $scope.userBiometricsEnabled = false;
                $cordovaToast.showShortBottom($translate.instant('BiometricsDisabled') || 'Biometria wyłączona');
            } else {
                BiometricsService.enableBiometrics($scope.currentUserLogin);
                $scope.userBiometricsEnabled = true;
                $cordovaToast.showShortBottom($translate.instant('BiometricsEnabled') || 'Biometria włączona');
            }
        }

        // Watch for autoBiometrics changes to mark form as dirty (enables Save button)
        $scope.$watch('localSettings.autoBiometrics', function(newVal, oldVal) {
            if (newVal !== oldVal && newVal !== undefined && oldVal !== undefined) {
                if ($scope.form.localSettings) {
                    $scope.form.localSettings.$setDirty();
                }
            }
        });
    });