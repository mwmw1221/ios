angular.module('app.controllers')
    .controller('userSettingsCtrl', function ($scope, $rootScope, settings, UserSettingsService, $translate, $cordovaToast, LocalStorage, $state, CircuitService, Session) {
        $scope.form = {};
        $scope.settings = settings;

        var currentRegion = Session.getCurrentRegion();
        $scope.currentRegion = currentRegion;

        CircuitService.getList().then(function (result) {
            $scope.circuits = result;
        });

        $scope.languages = [
            {
                key: "pl",
                value: $translate.instant('Polish')
            }, {
                key: "en",
                value: $translate.instant('English')
            },
            {
                key: "de",
                value: $translate.instant('German')
            }];

        $scope.inactivityTimes = [
            {
                key: "1",
                value: 1
            }, {
                key: "30",
                value: 30
            }
        ]
       
        $scope.localSettings = LocalStorage.getObject("localSettings");

        if (!$scope.localSettings.language) {
            $scope.localSettings.language = $rootScope.language;
        }

        function changeLanguage() {
            $translate.use(($scope.localSettings.language).split("-")[0]).then(function (data) {
                $rootScope.language = data;
                UserSettingsService.setLanguage(data)
                    .then(function (response) {
                        $translate('Saved').then($cordovaToast.showLongBottom);
                        $state.reload();
                    })
            }, function (error) {
            });
        }

        $scope.saveSettings = function () {
            if ($scope.form.settings.$dirty) {
                UserSettingsService.saveUserSettings($scope.settings)
                    .then(function (response) {
                        if (response.succes) {
                            $scope.form.settings.$setPristine();
                        }
                    });
            }
            if ($scope.form.localSettings.$dirty) {
                LocalStorage.setObject("localSettings", $scope.localSettings);
                if ($scope.form.localSettings.language.$dirty) {
                    changeLanguage();
                }
                $scope.form.localSettings.$setPristine();
            }
            $translate('Saved').then($cordovaToast.showLongBottom);
        }
    });