angular.module('app.controllers')
    .controller('collectivePlanListCtrl', function ($scope, $rootScope,$ionicHistory, $http, $state, ApiEndpoint, CollectivePlanService, collectivePlanList) {
        
        $scope.collectivePlanList = collectivePlanList; 
        
    });