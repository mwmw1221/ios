angular.module('app.controllers')
    .controller('colleagueHelpCtrl', function ($scope, ColleagueHelpService, persons) {
        
        $scope.persons = persons;
    });