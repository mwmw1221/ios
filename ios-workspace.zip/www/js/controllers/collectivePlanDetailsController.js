angular.module('app.controllers')
    .controller('collectivePlanDetailsCtrl', function ($scope, $rootScope, $ionicHistory, $http, $state, ApiEndpoint, CollectivePlanService, collectivePlan, $cordovaToast, $translate) {

        $scope.cPlan = collectivePlan;

        $scope.collectiveSignIn = function (id) {
            CollectivePlanService.collectiveSignIn(id)
                .then(function (response) {
                    $translate('SignedUpForHunting').then($cordovaToast.showLongBottom);
                    $state.go("menu.collectivePlanList");
                }, function (err) {
                    console.log(err);
                });
        };

        $scope.collectiveSignOut = function (id) {
            CollectivePlanService.collectiveSignOut(id)
                .then(function (response) {
                    $translate('UnsubscribedFromHunting').then($cordovaToast.showLongBottom);
                    $state.go("menu.collectivePlanList");
                }, function (err) {
                    console.log(err);
                });
        };
    });