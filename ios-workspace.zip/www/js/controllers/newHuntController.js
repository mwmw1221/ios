angular.module('app.controllers')
    .controller('newHuntCtrl', function ($scope, $state, $ionicHistory, $cordovaToast, ionicTimePicker, Session, NewHuntService, permits, CircuitService, UtilsService, $ionicPopup, $translate) {
        $scope.permits = permits;
        $scope.districts;
        $scope.temporaryDate = {
            startDate: new Date(Date.now())
        };
        $scope.equipments;
        $scope.model = {
            permit: [],
            checkboxAnotherHunter: false,
            checkboxDewizowiec: false,
            hunterId: null,
            type: null
        };
        $scope.huntersList;
        $scope.data = {
            districtId: [],
            equId: null
        };

        $scope.str = '#zajęty#';
        $scope.busyDistrict = false;

        // stores the data for equipments from database
        var equipments = [];

        $scope.hunters;

        var allHunters;

        $scope.checkboxAnotherHunterChange = function () {
            if ($scope.model.checkboxAnotherHunter) {
                if (allHunters) {
                    loadHuntersToList();
                } else {
                    NewHuntService.getAnotherHuntersForSelect()
                        .then(function (result) {
                            allHunters = result.hunters;
                            loadHuntersToList();
                            $scope.model.hunterId = $scope.hunters[0][0];
                            $scope.loadHunterPermissions();
                        });
                }
            }
            else {
                $scope.model.hunterId = null;
                $scope.loadHunterPermissions();
            }
        }

        $scope.checkboxDewizowiecChange = function () {
            if ($scope.model.checkboxDewizowiec) {
                loadDewizowcyToList();
                $scope.model.hunterId = $scope.hunters[0][1];
                $scope.model.type = 'D';
                $scope.loadHunterPermissions();
            }
            else {
                loadHuntersToList();
                $scope.model.type = null;
                $scope.model.hunterId = $scope.hunters[0][0];
                $scope.loadHunterPermissions();
            }
        }

        loadHuntersToList = function () {
            $scope.hunters = [];
            for (var i = 0; i < allHunters.length; i++) {
                if (allHunters[i][0] != null) {
                    $scope.hunters.push(allHunters[i]);
                }
            }
        }

        loadDewizowcyToList = function () {
            $scope.hunters = [];
            for (var i = 0; i < allHunters.length; i++) {
                if (allHunters[i][1] != null) {
                    $scope.hunters.push(allHunters[i]);
                }
            }
        }

        $scope.$watch('data.districtId', function () {
            $scope.busyDistrict = false;
            for (var j = 0; j < $scope.data.districtId.length; j++) {
                for (var i = 0; i < $scope.districts.length; i++) {
                    if ($scope.districts[i][0] == $scope.data.districtId[j] && $scope.districts[i][1].includes($scope.str)) {
                        $scope.busyDistrict = true;
                    }
                }
            }
            if ($scope.model.permit[0][6] && $scope.model.permit[0][6] == 'T' && $scope.data.districtId != null) {
                var another = [-1, 'Inne'];
                $scope.equipments.push(another);
            }
        })

        getHuntersList = function () {
            if ($scope.model.permit.length > 0) {
                NewHuntService.getAnotherHunters($scope.model.permit[0][5]).then(function (result) {
                    $scope.huntersList = result;
                });
            }
        }

        $scope.districtChange = function (districtName) {
            var tempEq = [];
            for (var i = 0; i < equipments.length; i++) {
                if ((equipments[i][2] == $scope.data.districtId) || equipments[i][0] == -1) {
                    tempEq.push(equipments[i]);
                }
            }
            $scope.equipments = tempEq;
        }

        $scope.loadDistricAndEquData = function () {
            if ($scope.model.permit.length > 0) {
                NewHuntService.getDistrictsList($scope.model.permit[0][5]).then(function (result) {
                    $scope.districts = result;
                });
                NewHuntService.getEquipmentList($scope.model.permit[0][5]).then(function (result) {
                    equipments = result;
                    $scope.equipments = equipments;
                });
            } else {
                $scope.districts = null;
                equipments = null;
                $scope.equipments = equipments;
            }

        }

        $scope.loadHunterPermissions = function () {
            NewHuntService.getAllPermits($scope.model.hunterId, $scope.model.type).then(function (result) {
                $scope.permits = result;
                $scope.model.permit = [];
            });
        }

        $scope.addHunt = function () {
            if ($scope.busyDistrict) {
                var startDate = new Date($scope.temporaryDate.startDate);
                startDate = startDate.toISOString().substring(0, 10);

                var tempStartTime = new Date($scope.data.startTime);
                startTime = UtilsService.convertDateToTime(tempStartTime);

                var tempEndtime = new Date($scope.data.endTime);
                endTime = UtilsService.convertDateToTime(tempEndtime);

                var endDate;
                if ($scope.temporaryDate.endDate != null) {
                    endDate = new Date($scope.temporaryDate.endDate);
                    endDate = endDate.toISOString().substring(0, 10);
                }

                var data = {
                    startDate: startDate,
                    startTime: startTime,
                    endDate: endDate,
                    endTime: endTime,
                    districtId: $scope.data.districtId,
                    equId: null
                };

                NewHuntService.checkDistrictOccupied(data)
                    .then(function (result) {
                        if (result.confirm) {
                            busyDistrictPopup(result.confirm);
                        }
                        else {
                            validateHunt();
                        }
                    })
            } else {
                validateHunt();
            }
        }

        function validateHunt() {
            //validate
            var startDate = new Date($scope.temporaryDate.startDate);
            var startTime = new Date($scope.data.startTime);
            var date = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate(), startTime.getHours(), startTime.getMinutes());

            var tempEndtime = new Date($scope.data.endTime);
            endTime = UtilsService.convertDateToTime(tempEndtime);

            if (UtilsService.compareDateTime(date)) {
                tooEarlyTimePopup();
                return null;
            } else {
                var huntData = angular.copy($scope.data);
                huntData.startDate = UtilsService.convertDateToString(date);
                huntData.startTime = UtilsService.convertTimeToString(date);
                huntData.endTime = endTime;

                var temporaryEndDate;
                if ($scope.temporaryDate.endDate != null) {
                    temporaryEndDate = new Date($scope.temporaryDate.endDate);
                    temporaryEndDate.setHours(0, -temporaryEndDate.getTimezoneOffset(), 0, 0);
                    temporaryEndDate = temporaryEndDate.toISOString().substring(0, 10);
                    huntData.endDate = temporaryEndDate;
                }

                huntData.permitId = new Array();
                for (var i = 0; i < $scope.model.permit.length; i++) {
                    huntData.permitId.push($scope.model.permit[i][0]);
                }
                addHunt(huntData);
            }
        }

        function addHunt(huntData) {
            NewHuntService.addHunt(huntData).then(function (result) {
                if (result.action) {
                    $translate('EntryInEKEPAdded').then($cordovaToast.showLongBottom);
                    $state.go("menu.hunterOptions");
                }
            }, function (err) {
                if (err.error == "Zbyt wcześna data rozpoczęcia polowania") {
                    // Data rozpoczecia polowania zbyt wczesna - ustawic na aktualna?
                }
            })
        }

        function tooEarlyTimePopup() {
            var pop = $ionicPopup.show({
                title: $translate.instant('StartDateOrTimeIsIncorrect'),
                subTitle: $translate.instant('DoYouWantToSetStartDateAndTimeToCurrent'),
                scope: $scope,
                buttons: [
                    {
                        text: $translate.instant('No'),
                        onTap: function (e) {
                            return null;
                        }
                    }, {
                        text: '<b>' + $translate.instant('Yes') + '</b>',
                        type: 'button-positive',
                        onTap: function (e) {
                            $scope.temporaryDate.startDate = new Date(Date.now());
                            var temp = new Date();
                            temp.setSeconds(0, 0);
                            $scope.data.startTime = temp;
                            validateHunt();
                            return null;
                        }
                    }
                ]
            });
        };

        function busyDistrictPopup(hunters) {
            console.log(hunters);
            var pop = $ionicPopup.show({
                title: $translate.instant('BusyDistrict'),
                subTitle: $translate.instant('HaveYouConsultedWithCurrentlyHuntingHunters') + '<br><br>' + hunters,
                scope: $scope,
                buttons: [
                    {
                        text: $translate.instant('No'),
                        type: 'button-assertive',
                        onTap: function (e) {
                            return null;
                        }
                    }, {
                        text: $translate.instant('Yes'),
                        type: 'button-positive',
                        onTap: function (e) {
                            validateHunt();
                            return null;
                        }
                    }
                ]
            });
        };


        function setToCurrentDateTime() {
            $scope.temporaryDate.startDate = new Date(Date.now());
            $scope.data.startTime = new Date($scope.temporaryDate.startDate);
            console.log('# setToCurrentDateTime $scope.data.startTime ' + $scope.data.startTime);
        }

        $scope.goBack = function () {
            $ionicHistory.goBack();
        };

        $scope.pushPermitToModel = function (permit) {
            if (permit.checked) {
                $scope.model.permit.push(permit);
                for (var i = 0; i < $scope.permits.length; i++) {
                    if ($scope.permits[i][5] != permit[5]) {
                        $scope.permits[i].disabled = true;
                    }
                }
            } else {
                var index = $scope.model.permit.indexOf(permit);
                $scope.model.permit.splice(index, 1);
                if ($scope.model.permit.length == 0) {
                    for (var i = 0; i < $scope.permits.length; i++) {
                        if ($scope.permits[i].disabled) {
                            $scope.permits[i].disabled = false;
                        }
                    }
                }
            }
            getHuntersList();
            $scope.loadDistricAndEquData();
        };
    });