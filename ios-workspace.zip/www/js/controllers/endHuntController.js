angular.module('app.controllers')
    .controller('endHuntCtrl', function ($scope, $http, $state, $stateParams, $cordovaToast, ApiEndpoint, ionicTimePicker, OpenedHuntService, $ionicPopup, $ionicHistory, UtilsService, $translate) {
        $scope.data = {
            huntingId: $stateParams.openHuntingId,
            shotCount: parseInt($stateParams.shotCount)
        };
        if ($stateParams.endDate) {
            $scope.data.endDate = new Date($stateParams.endDate.substring(0, 10));
            $scope.data.endTime = new Date($stateParams.endDate.substring(0, 10) + 'T' + $stateParams.endDate.substring(11, 16) + ':00' + UtilsService.getTimeZone());
        } else {
            var currentTime = new Date(Date.now());
            $scope.data.endDate = currentTime;
            $scope.data.endTime = new Date(currentTime);
        }

        function endTheHunt(data) {
            var endData = angular.copy(data);
            endData.endDate = UtilsService.convertDateToString(endData.endDate);
            endData.endTime = UtilsService.convertTimeToString(endData.endTime);

            OpenedHuntService.endHunt(endData).then(function (result) {
                if (result.action) {
                    $translate('HuntingEnded').then($cordovaToast.showLongBottom);
                    $state.go("menu.hunterOptions");
                }
            }, function (result) {
                console.log(result);
            })
        }

        $scope.endHunt = function () {
            var currentDate = new Date();
            currentDate.setSeconds(0, 0);
            var d = $scope.data.endDate;
            var t = $scope.data.endTime;
            var endDate = new Date(d.getFullYear(), d.getMonth(), d.getDate(), t.getHours(), t.getMinutes());

            if (UtilsService.compareDateTimes(currentDate, endDate)) {
                showEndingPopup(currentDate);
            } else {
                endTheHunt($scope.data);
            }
        }

        function showEndingPopup(currentDate) {
            var pop = $ionicPopup.show({
                title: $translate.instant('HuntHasNotEndedYet'),
                subTitle: $translate.instant('SetCurrentTimeAsTheEndOfHunt'),
                scope: $scope,
                buttons: [
                    {
                        text: $translate.instant('No'),
                        onTap: function (e) {
                            $ionicHistory.goBack();
                        }
                    }, {
                        text: '<b>' + $translate.instant('Yes') + '</b>',
                        type: 'button-positive',
                        onTap: function (e) {
                            var data = {
                                huntingId: $scope.data.huntingId,
                                endDate: currentDate,
                                endTime: currentDate,
                                shotCount: $scope.data.shotCount,
                                description: $scope.data.description
                            };
                            endTheHunt(data);
                        }
                    }
                ]
            });
        };

    });