angular.module('app.controllers')
    .controller('activityPlanCtrl', function ($scope, $http, $state, years, ActivityPlanService, $ionicPopup, $translate, $cordovaToast) {
        $scope.years = years;
        $scope.data = {
            year: $scope.years[0].value
        }

        $scope.loadActivityPlan = function (year) {
            ActivityPlanService.getActivityPlan(year)
                .then(function (response) {
                    $scope.activityPlan = response;
                });
        }

        $scope.loadActivityPlan($scope.data.year);

        $scope.setActivityPlanPresent = function (activityPlanId, setTo) {
            var self = this
            ActivityPlanService.setActivityPlanPresent(activityPlanId, setTo)
                .then(function (response) {
                    if(response.succes) {
                        $translate('Saved').then($cordovaToast.showLongBottom);
                        $state.reload();
                    }
                });
        }

        $scope.signInPopup = function (activityPlanId) {
            var myPopup = $ionicPopup.show({
                title: $translate.instant('DoYouWantToSignIn'),
                scope: $scope,
                buttons: [
                    {
                        text: $translate.instant('Yes'),
                        type: 'button-positive',
                        onTap: function() {
                            $scope.setActivityPlanPresent(activityPlanId, 'T');
                          }
                    },{
                        text: $translate.instant('No'),
                        type: 'button-assertive'
                    }
                ]
            });
        };

        $scope.signOffPopup = function (activityPlanId) {
            var myPopup = $ionicPopup.show({
                title: $translate.instant('DoYouWantToSignOff'),
                scope: $scope,
                buttons: [
                    {
                        text: $translate.instant('Yes'),
                        type: 'button-positive',
                        onTap: function() {
                            $scope.setActivityPlanPresent(activityPlanId, 'N');
                          }
                    },{
                        text: $translate.instant('No'),
                        type: 'button-assertive'
                    }
                ]
            });
        };
    });