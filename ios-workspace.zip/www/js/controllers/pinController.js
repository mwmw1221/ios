angular.module('app.controllers')
    .controller('pinCtrl', function ($scope, $state, $rootScope, $stateParams, $cordovaToast, Session, PinService, BiometricsService, LocalStorage, $ionicPopup, $translate, $ionicHistory, $q, $timeout) {
        
        // --- KONFIGURACJA ---
        const USER_LOGIN_KEY = 'lastLoggedInUser';
        const accountName = $stateParams.accountName;
        
        // Sprawdzamy czy PIN istnieje dla tego konta
        const savedPin = PinService.getPin(accountName);
        const isPinSet = savedPin !== null && savedPin !== '';
        
        // Inicjalizacja zmiennych
        $scope.passcode = "";
        $scope.isPinSet = isPinSet;
        $scope.pageTitleKey = isPinSet ? 'EnterPin' : 'SetNewPin';
        $scope.biometricsEnabled = false;
        $scope.biometricsAvailable = false;
        $scope.showBiometricsPrompt = false;
        $scope.biometricsAttempts = 0;
        $scope.maxBiometricsAttempts = 3;
        
        // Sprawdzaj dostępność biometrii i jej stan
        $scope.biometricVerified = false;
        BiometricsService.isBiometricsAvailable().then(function(available) {
            $scope.biometricsAvailable = available;
            if (available) {
                $scope.biometricsEnabled = BiometricsService.isBiometricsEnabled(accountName);
                $scope.biometricsAutologin = BiometricsService.isAutologinEnabled(accountName);
                console.log("Biometria dostępna, włączona dla użytkownika:", $scope.biometricsEnabled, "autologin:", $scope.biometricsAutologin);
                
                // Jeśli autologin jest włączony i PIN już ustawiony - automatycznie wywołaj biometrię
                if (isPinSet && $scope.biometricsEnabled && $scope.biometricsAutologin) {
                    $timeout(function() {
                        $scope.attemptBiometrics();
                    }, 300);
                }
            } else {
                console.log("Biometria nie dostępna na tym urządzeniu");
            }
        }).catch(function(error) {
            console.error("Błąd podczas sprawdzania biometrii:", error);
        });
        
        // FUNKCJE BIOMETRII
        
        // Dialog pytający czy włączyć biometrię (po pierwszym ustawieniu PIN-u)
        $scope.showBiometricsDialog = function() {
            var confirmPopup = $ionicPopup.confirm({
                title: $translate.instant('EnableBiometrics') || 'Włączyć biometrię?',
                template: $translate.instant('BiometricsDescription') || 'Czy chcesz logować się za pomocą biometrii zamiast PIN-u?',
                okText: $translate.instant('Yes') || 'Tak',
                cancelText: $translate.instant('No') || 'Nie'
            });
            
            return confirmPopup.then(function(res) {
                if (res) {
                    BiometricsService.enableBiometrics(accountName);
                    $scope.biometricsEnabled = true;
                    $cordovaToast.showShortBottom($translate.instant('BiometricsEnabled') || 'Biometria włączona');
                } else {
                    BiometricsService.disableBiometrics(accountName);
                    $scope.biometricsEnabled = false;
                    $cordovaToast.showShortBottom($translate.instant('BiometricsDisabled') || 'Biometria wyłączona');
                }
                return res;
            });
        };
        
        // Próba uwierzytelnienia biometrią
        $scope.attemptBiometrics = function() {
            if (!$scope.biometricsAvailable || !$scope.biometricsEnabled) {
                console.log("Biometria niedostępna lub wyłączona");
                return;
            }
            
            console.log("Próba biometrii, attempt:", $scope.biometricsAttempts);
            $scope.biometricsAttempts++;
            
                BiometricsService.authenticate($translate.instant('AuthenticateWithBiometrics') || 'Uwierzytelnij się biometrią')
                .then(function(result) {
                    console.log("Biometria potwierdzona");
                    $scope.biometricsAttempts = 0;
                    $scope.biometricVerified = true;
                    Session.relogin().then(function() {
                                $state.go('choosingRegion');
                    });
                })
                .catch(function(error) {
                    console.error("Błąd biometrii:", error);
                    if (error === "Anulowano") {
                        console.log("Użytkownik anulował biometrię");
                        // Pozwól mu wpisać PIN bezpośrednio
                    } else if ($scope.biometricsAttempts >= $scope.maxBiometricsAttempts) {
                        console.log("Przekroczono maksymalną liczbę prób biometrii");
                        $cordovaToast.showLongBottom($translate.instant('BiometricsMaxAttemptsExceeded') || 'Przekroczono maksymalną liczbę prób');
                        // Przejdź do wpisywania PIN-u
                        $scope.showPinPrompt();
                    } else {
                        $cordovaToast.showShortBottom(error || ($translate.instant('BiometricsFailed') || 'Biometria nie powiodła się'));
                    }
                });
        };
        
        // Pokazuj prompt do biometrii na starcie jeśli jest włączona
        $scope.showPinPrompt = function() {
            // Skoncentruj się na polu PIN
            $timeout(function() {
                var inputElement = document.querySelector('.pin-input');
                if (inputElement) {
                    inputElement.focus();
                }
            }, 100);
        };

        // KONIEC FUNKCJI BIOMETRII
        
        $scope.$watch('passcode', function(newVal, oldVal) {
            if (newVal !== oldVal && newVal !== undefined && newVal !== null) {
                console.log("Watcher - passcode zmieniony z", oldVal, "na", newVal);
                $timeout(function() {
                    $scope.onPinInput();
                }, 10);
            }
        }, true);
        
        // Bezpośrednia obsługa zdarzenia input dla kompatybilności
        $timeout(function() {
            var inputElement = document.querySelector('.pin-input');
            if (inputElement) {
                console.log("Dodawanie bezpośredniego nasłuchiwania na input");
                inputElement.addEventListener('input', function(event) {
                    console.log("Input event - wartość:", event.target.value);
                    $scope.$apply(function() {
                        $scope.passcode = event.target.value;
                    });
                });
                inputElement.addEventListener('keyup', function(event) {
                    console.log("Keyup event - wartość:", event.target.value);
                    $scope.$apply(function() {
                        $scope.passcode = event.target.value;
                    });
                });
            } else {
                console.error("Nie znaleziono input elementu!");
            }
        }, 500);
        
        // Funkcja resetuje PIN, usuwa zapisane konto z LocalStorage i wraca do logowania
        $scope.resetPin = function () {
            var pop = $ionicPopup.show({
                title: $translate.instant('ResettingThePinCode'),
                subTitle: $translate.instant('AreYouSureYouWantToResetPin'),
                scope: $scope,
                buttons: [
                    {
                        text: $translate.instant('No'),
                        type: 'button-positive',
                    }, 
                    {
                        text: '<b>' + $translate.instant('Yes') + '</b>',
                        type: 'button-assertive',
                        onTap: function (e) {
                            PinService.removePin(accountName)
                                .then(function() {
                                    LocalStorage.set(USER_LOGIN_KEY, null);
                                    $ionicHistory.clearHistory();
                                    $ionicHistory.clearCache();
                                    $state.go("login");
                                })
                                .catch(function(error) {
                                    console.error("Błąd podczas usuwania PIN:", error);
                                    $cordovaToast.showLongBottom($translate.instant('ErrorResettingPin') || 'Błąd podczas resetowania PIN');
                                });
                        }
                    }
                ]
            });
        };

        // Flaga zapobiegająca wielokrotnemu wywołaniu
        var isProcessing = false;

        // Główna funkcja weryfikująca/ustawiająca PIN
        var enterPin = function () {
            // Zapobiegaj wielokrotnemu wywołaniu
            if (isProcessing) {
                console.log("enterPin już w trakcie przetwarzania");
                return;
            }

            // Upewnij się, że passcode jest stringiem
            var pinCode = String($scope.passcode || '').replace(/[^0-9]/g, '');
            
            console.log("enterPin wywołany, passcode:", $scope.passcode, "pinCode (oczyszczony):", pinCode, "długość:", pinCode.length);
            
            if (!pinCode || pinCode.length !== 4) {
                console.log("PIN nie ma 4 cyfr. passcode:", $scope.passcode, "pinCode:", pinCode, "długość:", pinCode ? pinCode.length : 0);
                $cordovaToast.showShortBottom($translate.instant('PinMustBe4Digits') || 'PIN musi składać się z 4 cyfr');
                return;
            }

            // Zaktualizuj model jeśli jest różnica
            if ($scope.passcode !== pinCode) {
                $scope.passcode = pinCode;
            }

            isProcessing = true;
            console.log("Ustawianie/weryfikacja PIN:", accountName, "PIN:", pinCode, "isPinSet:", isPinSet);

            if (!isPinSet) {
                // USTAWIENIE NOWEGO PIN-U
                console.log("Ustawianie nowego PIN-u:", pinCode);
                PinService.setPin(accountName, pinCode)
                    .then(function() {
                        console.log("PIN ustawiony pomyślnie");
                        LocalStorage.set(USER_LOGIN_KEY, accountName); 
                        $rootScope.first = $rootScope.first || {};
                        $rootScope.first.pin = false;
                        isProcessing = false;
                        // Po ustawieniu PIN-u pytamy czy włączyć biometrię, potem przechodzimy dalej
                        $scope.showBiometricsDialog().then(function() {
                            $state.go('choosingRegion');
                        }, function() {
                            // nawet jeśli użytkownik odrzuci dialog, kontynuujemy
                            $state.go('choosingRegion');
                        });
                    })
                    .catch(function(error) {
                        console.error("Błąd podczas ustawiania PIN:", error);
                        isProcessing = false;
                        $cordovaToast.showLongBottom($translate.instant('ErrorSettingPin') || 'Błąd podczas ustawiania PIN');
                        $scope.passcode = "";
                    });
            } else {
                // WERYFIKACJA PIN-U
                console.log("Weryfikacja PIN-u:", pinCode);
                PinService.checkPin(accountName, pinCode)
                    .then(function(isCorrect) {
                        console.log("Wynik weryfikacji PIN:", isCorrect);
                        if (isCorrect) {
                            // PIN POPRAWNY - sesja jest już ustawiona po logowaniu, przechodzimy dalej
                            isProcessing = false;
                            Session.relogin().then(function() {
                                $state.go('choosingRegion');
                            });
                        } else {
                            // PIN NIEPOPRAWNY
                            isProcessing = false;
                            $cordovaToast.showLongBottom($translate.instant('IncorrectPin') || 'Niepoprawny PIN');
                            $scope.passcode = ""; 
                        }
                    })
                    .catch(function(error) {
                        console.error("Błąd podczas sprawdzania PIN:", error);
                        isProcessing = false;
                        $cordovaToast.showLongBottom($translate.instant('ErrorCheckingPin') || 'Błąd podczas sprawdzania PIN');
                        $scope.passcode = "";
                    });
            }
        };

        // Funkcja obsługująca wprowadzanie PIN-u (używana z natywnej klawiatury)
        $scope.onPinInput = function() {
            if (isProcessing) {
                console.log("onPinInput - przetwarzanie już w toku");
                return;
            }
            
            // Pobierz wartość bezpośrednio z inputa jako backup
            var inputElement = document.querySelector('.pin-input');
            var directValue = inputElement ? inputElement.value : '';
            
            // Upewnij się, że passcode jest stringiem
            var currentPin = String($scope.passcode || directValue || '');
            
            // Filtrowanie tylko cyfr
            var filteredPin = currentPin.replace(/[^0-9]/g, '');
            // Ograniczenie do 4 cyfr
            if (filteredPin.length > 4) {
                filteredPin = filteredPin.substring(0, 4);
            }
            
            console.log("onPinInput - $scope.passcode:", $scope.passcode, "directValue:", directValue, "currentPin:", currentPin, "filteredPin:", filteredPin, "długość:", filteredPin.length);
            
            // Aktualizuj model zawsze, aby zapewnić synchronizację
            if ($scope.passcode !== filteredPin) {
                $scope.passcode = filteredPin;
                // Zaktualizuj również wartość inputa
                if (inputElement && inputElement.value !== filteredPin) {
                    inputElement.value = filteredPin;
                }
            }
            
            // Automatyczne wywołanie weryfikacji po wprowadzeniu 4 cyfr
            if (filteredPin.length === 4) {
                console.log("PIN ma 4 cyfry, wywołuję enterPin za 200ms");
                // Krótkie opóźnienie, aby użytkownik zobaczył ostatnią cyfrę i uniknąć wielokrotnego wywołania
                $timeout(function() {
                    var finalPin = String($scope.passcode || '').replace(/[^0-9]/g, '');
                    // Backup - sprawdź bezpośrednio w inputie
                    if (finalPin.length !== 4 && inputElement) {
                        finalPin = String(inputElement.value || '').replace(/[^0-9]/g, '').substring(0, 4);
                    }
                    console.log("Timeout - finalPin:", finalPin, "długość:", finalPin.length);
                    if (finalPin.length === 4) {
                        $scope.passcode = finalPin;
                        enterPin();
                    } else {
                        console.log("PIN nie ma 4 cyfr w timeout, pomijam");
                    }
                }, 200);
            }
        };

        // Obsługa klawisza Enter
        $scope.onKeyDown = function(event) {
            // Obsługa klawisza Enter (kod 13)
            if (event.keyCode === 13 || event.which === 13 || event.key === 'Enter') {
                event.preventDefault();
                if ($scope.passcode && $scope.passcode.length === 4) {
                    enterPin();
                }
            }
        };

        // Obsługa zwolnienia klawisza (dla kompatybilności)
        $scope.onKeyUp = function(event) {
            // Obsługa klawisza Enter (kod 13)
            if (event.keyCode === 13 || event.which === 13 || event.key === 'Enter') {
                event.preventDefault();
                var pinCode = String($scope.passcode || '').replace(/[^0-9]/g, '');
                console.log("Enter naciśnięty - pinCode:", pinCode, "długość:", pinCode.length);
                if (pinCode && pinCode.length === 4 && !isProcessing) {
                    if ($scope.passcode !== pinCode) {
                        $scope.passcode = pinCode;
                    }
                    enterPin();
                } else {
                    $cordovaToast.showShortBottom($translate.instant('PinMustBe4Digits') || 'PIN musi składać się z 4 cyfr');
                }
            } else {
                // Dla innych klawiszy wywołujemy obsługę inputu (jako backup, jeśli ng-change nie zadziała)
                $timeout(function() {
                    $scope.onPinInput();
                }, 50);
            }
        };

        // Zachowana kompatybilność z przyciskami (jeśli jeszcze są w szablonie)
        $scope.add = function (value) {
            if ($scope.passcode.length < 4) {
                $scope.passcode = $scope.passcode + value;
                if ($scope.passcode.length === 4) {
                    enterPin();
                }
            }
        }

        $scope.delete = function () {
            if ($scope.passcode.length > 0) {
                $scope.passcode = $scope.passcode.substring(0, $scope.passcode.length - 1);
            }
        }

        // Funkcja wywoływana przez przycisk OK
        $scope.usePin = function () {
            if (isProcessing) {
                console.log("Przetwarzanie już w toku, pomijam użycie PIN-u");
                return;
            }
            // Normalizuj PIN przed sprawdzeniem
            var pinCode = String($scope.passcode || '').replace(/[^0-9]/g, '');
            console.log("usePin - passcode:", $scope.passcode, "pinCode:", pinCode, "długość:", pinCode.length);
            if (pinCode && pinCode.length === 4) {
                // Zaktualizuj model jeśli trzeba
                if ($scope.passcode !== pinCode) {
                    $scope.passcode = pinCode;
                }
                console.log("Wywołanie enterPin z przycisku OK");
                enterPin();
            } else {
                console.log("PIN nie ma 4 cyfr w usePin");
                $cordovaToast.showShortBottom($translate.instant('PinMustBe4Digits') || 'PIN musi składać się z 4 cyfr');
            }
        }
    });
