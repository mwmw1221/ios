angular.module('app.controllers')
    .controller('openHuntCtrl', function ($scope, $state, ionicTimePicker, OpenHuntService, circuitList, $ionicModal, HuntsListOptionsService, LocalStorage, Session) {
        var currentRegion = Session.getCurrentRegion();
        LOCAL_SETTINGS = LocalStorage.getObject("localSettings");

        $scope.openHuntList = [];

        $scope.circuitList = circuitList;
        $scope.data = { circuitId: 'region' in LOCAL_SETTINGS && LOCAL_SETTINGS.region[currentRegion[0]] != null ? LOCAL_SETTINGS.region[currentRegion[0]] : circuitList[0][0] };

        $scope.loadAllOpenHunting = function () {
            OpenHuntService.getAllOpenHunting($scope.data.circuitId).then(function(result) {
                $scope.openHuntList = result;
            });
        }

        $scope.loadAllOpenHunting();

        $scope.show = HuntsListOptionsService.getSettings();
        $scope.sizes = HuntsListOptionsService.getSizes();
        $scope.form = {};

        $scope.saveOptions = function () {
            HuntsListOptionsService.saveSettings($scope.show);
            $scope.form.settings.$setPristine();
        }

        /* Modal for Options */

        $ionicModal.fromTemplateUrl('templates/huntsListOptions.html', {
            scope: $scope,
            animation: 'slide-in-up',
        }).then(function (modal) {
            $scope.modal = modal;
        });

        $scope.openModal = function () {
            $scope.modal.show();
        };

        $scope.closeModal = function () {
            $scope.modal.hide();
        };

        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.modal.remove();
        });

        // Execute action on hide modal
        $scope.$on('modal.hidden', function () {
            // Execute action
        });

        // Execute action on remove modal
        $scope.$on('modal.removed', function () {
            // Execute action
        });
    });