angular.module('app.controllers')
    .controller('paymentsCtrl', function ($scope, $http, $state, years, PaymentsService) {
        $scope.years = years;
        $scope.data = {
            year: $scope.years[0].value
        }

        $scope.loadPayments = function (year) {
            PaymentsService.getUserPayments(year)
                .then(function (response) {
                    $scope.payments = response;
                });
        }

        $scope.loadPayments($scope.data.year);
    });