angular.module('app.controllers')
	.controller('menuCtrl', function ($rootScope, $scope, $ionicHistory, $ionicSideMenuDelegate, Session, $state) {
		$scope.myHunts = function () {

		};
		$scope.goToAnnualPlan = function () {
			$state.go("menu.annualPlan");
		};
		$scope.logout = function () {
			Session.logout().then(function (response) {
				if (response) {
					$state.go("login");
					$ionicHistory.nextViewOptions({
						disableBack: true
					});
					$ionicHistory.clearCache();
					$ionicHistory.clearHistory();
				}
			})
		};
		$scope.exit = function () {
			$ionicHistory.clearCache();
			$ionicHistory.clearHistory();
			Session.logout();
			navigator.app.exitApp();
		};
		$scope.goToMessages = function () {
			$state.go("menu.messages");
		};

	});