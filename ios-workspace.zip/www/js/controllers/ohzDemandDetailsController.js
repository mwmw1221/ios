angular.module('app.controllers')
    .controller('ohzDemandDetailsCtrl', function ($scope, demandDetails, OhzDemandService, $state) {
        $scope.demandDetails = demandDetails;

        $scope.accept = function () {
            OhzDemandService.setDemandZGDecision(demandDetails.demand.ID, 'Y')
                .then(function (response) {
                    $state.go("menu.ohzDemand");
                });
        }

        $scope.reject = function () {
            OhzDemandService.setDemandZGDecision(demandDetails.demand.ID, 'N')
                .then(function (response) {
                    $state.go("menu.ohzDemand");
                });
        }
    });