angular.module('app.controllers')
    .controller('hunterOptionsCtrl', function ($scope, $rootScope, $ionicHistory, $http, $state, ApiEndpoint, CircuitService, LocalStorage, messagesCount, WeatherService, PositionService, $translate, $cordovaToast) {
        $rootScope.messagesCount = messagesCount;
        $scope.weather;
        $scope.weatherIcons = WeatherService.getWeatherIcons();
        $scope.moonPhases = WeatherService.getMoonPhases();
        $scope.windIcon = WeatherService.getWindIcon();
        $scope.newHunt = function () {
            $state.go('menu.newHunt');
        }
        $scope.openHunt = function () {
            $state.go("menu.openHunt");
        }

        $rootScope.BACK_BUTTON = function () {
            var state = $state.current.name;
            if (state == "menu.myHunts"
                || state == "menu.map"
                || state == "menu.openHunt"
                || state == "menu.annualPlan"
                || state == "menu.collectivePlanList"
            ) {
                $ionicHistory.nextViewOptions({
                    disableAnimate: false,
                    disableBack: true
                });
                $state.go("menu.hunterOptions");
                $ionicHistory.clearHistory();
            } else {
                $ionicHistory.goBack();
            }
        };

        $scope.goToMessages = function () {
            $state.go("messages");
        }

        function getWeather() {
            var position = PositionService.getPosition();
            if (position != null) {
                WeatherService.getWeather(position.coords.longitude, position.coords.latitude)
                    .then(function (response) {
                        $scope.weather = response.weather;
                        $scope.weatherIcon = "https://openweathermap.org/img/w/" + $scope.weather.VALUE.weather[0].icon + ".png";
                        // $scope.weather.VALUE.wind.direction = WeatherService.windDegreeToDirection(response.weather.VALUE.wind.deg);
                    }, function (err) {
                        console.log(err);
                    })
            }
        }
        getWeather();

        $scope.getWeatherOnDemand = function () {
            cordova.plugins.diagnostic.isLocationEnabled(function (enabled) {
                if (enabled) {
                    PositionService.getCurrentPosition()
                        .then(function () {
                            getWeather();
                        })
                } else {
                    $translate('AlertAboutGPS2').then($cordovaToast.showLongBottom);
                }
            }, function (error) {
                $translate('AnErrorOccured').then($cordovaToast.showLongBottom);
                console.error("The following error occurred: " + error);
            });
        }
    })
    .directive('windonload', function () {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                element.bind('load', function () {
                    element[0].style.transform = "rotate(" + scope.weather.VALUE.wind.deg + "deg)";
                });
                element.bind('error', function () {
                    console.log('image could not be loaded');
                });
            }
        };
    });