angular.module('app.controllers')
    .controller('myHuntsCtrl', function ($scope, MyHuntsService, years, $ionicModal, LocalStorage, $translate, $cordovaToast, HuntsListOptionsService) {
        $scope.myHuntsList = [];
        $scope.years = years;
        $scope.data = { year: years[0].value };

        $scope.loadMyHunts = function () {
            MyHuntsService.getMyHuntsList(Number($scope.data.year)).then(function (result) {
                $scope.myHuntsList = result;
                for (var i = 0; i < $scope.myHuntsList.length; i++) {
                    $scope.myHuntsList[i][1] = $scope.myHuntsList[i][1] != null ? $scope.myHuntsList[i][1].substring(0, 10) : "";
                    $scope.myHuntsList[i][3] = $scope.myHuntsList[i][3] != null ? $scope.myHuntsList[i][3].substring(0, 10) : "";
                }
            });
        }

        $scope.loadMyHunts();

        $scope.show = HuntsListOptionsService.getSettings();
        $scope.sizes = HuntsListOptionsService.getSizes();
        $scope.form = {};

        $scope.saveOptions = function () {
            HuntsListOptionsService.saveSettings($scope.show);
            $scope.form.settings.$setPristine();
        }

        /* Modal for Options */

        $ionicModal.fromTemplateUrl('templates/huntsListOptions.html', {
            scope: $scope,
            animation: 'slide-in-up',
        }).then(function (modal) {
            $scope.modal = modal;
        });

        $scope.openModal = function () {
            $scope.modal.show();
        };

        $scope.closeModal = function () {
            $scope.modal.hide();
        };

        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.modal.remove();
        });

        // Execute action on hide modal
        $scope.$on('modal.hidden', function () {
            // Execute action
        });

        // Execute action on remove modal
        $scope.$on('modal.removed', function () {
            // Execute action
        });
    });