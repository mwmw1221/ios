angular.module('app.controllers')
    .controller('loginCtrl', function ($scope, $http, $rootScope, $state, ApiEndpoint, Session, LocalStorage, $cordovaToast, $translate, serverStatus, versionInfo) {
        // Klucz używany do przechowywania loginu użytkownika w LocalStorage
        const USER_LOGIN_KEY = 'lastLoggedInUser';
        
        // APK URL dla aktualizacji
        var apkUrl = "";

        // Ustawienia ikony serwera i sprawdzanie wersji
        $rootScope.serverIcon = serverStatus;
        if (versionInfo) {
            // Logika sprawdzania wersji została zachowana
            if (ApiEndpoint.version.replace('.', '') < versionInfo.replace('.', '')) {
                $translate('ClickToDownloadNewVersion').then(function (text) {
                    $rootScope.update = text;
                })
                $rootScope.updateImage = 'img/updateWarning.jpg';
            }
        }
        $rootScope.openLink = function () {
            // Używamy bezpiecznego sprawdzania cordova
            if (window.cordova && cordova.InAppBrowser) {
                //cordova.InAppBrowser.open(apkUrl, '_blank', 'location=yes');
            } else {
                console.warn('InAppBrowser is not available. Opening in default window.');
                //window.open(apkUrl, '_blank');
            }
        }

        // --- Model danych ---
        $scope.user = {
            login: '',
            password: ''
        };

        // Domyślnie panel logowania jest schowany, ponieważ sprawdzimy LocalStorage
        $scope.hide = { panel: true }; 
        $scope.pin = { code: "" };
        $rootScope.first = $rootScope.first || {};
        $rootScope.first.pin = true;
        
        // --- USUNIĘTO CAŁY BLOK document.addEventListener("deviceready", ...) ---
        
        // --- Funkcja pomocnicza do przejścia po logowaniu ---
        function navigateToPinPage(user, isFirstPin) {
            $rootScope.first = $rootScope.first || {};
            $rootScope.first.pin = isFirstPin; 
            
            // Jeśli nie jest to pierwsze logowanie PIN, zapisujemy login do LocalStorage
            if (!isFirstPin) {
                LocalStorage.set(USER_LOGIN_KEY, user.login);
            }
            
            $state.go("pinPage", { accountName: user.login, firstPin: isFirstPin });
        }

        // --- Logika sprawdzania zapisanego konta ---
        function checkSavedAccount() {
            const savedLogin = LocalStorage.get(USER_LOGIN_KEY);
            
            if (savedLogin && savedLogin !== 'null' && savedLogin !== 'undefined') {
                $scope.user.login = savedLogin;
                // Automatyczne przejście do ekranu PIN
                navigateToPinPage({ login: savedLogin }, false); 
            } else {
                // Nie znaleziono zapisanego loginu, pokazujemy panel logowania
                $scope.hide.panel = false;
            }
        }

        // Natychmiastowe sprawdzenie zapisanego konta przy ładowaniu kontrolera
        checkSavedAccount();


        $scope.reset = function () {
            $scope.user.login = '';
            $scope.user.password = '';
        }

        $scope.loginAction = function () {
            // Ustawiamy $scope.hide.panel na true, aby pokazać loader jeśli to możliwe
            $scope.hide.panel = true; 
            
            Session.login($scope.user).then(function (data) {
                if (data === "Login success") {
                    // Po udanym logowaniu przechodzimy do ekranu PIN. 
                    // To jest moment, w którym użytkownik ustawi PIN, więc isFirstPin=true.
                    // Po ustawieniu PIN, logika przejdzie do navigateToPinPage(..., false)
                    // i login zostanie zapisany.
                    navigateToPinPage($scope.user, true); 
                } else {
                    $cordovaToast.showLongCenter("Niepoprawne dane logowania");
                    $scope.reset();
                    // Pokazujemy panel ponownie po niepowodzeniu
                    $scope.hide.panel = false; 
                }
            }, function(error) {
                // Obsługa błędu sieci/serwera
                console.error("Login failed due to error:", error);
                $cordovaToast.showLongCenter("Błąd połączenia z serwerem");
                $scope.hide.panel = false; 
            });
        }

        function sendToken() {
            // Ta funkcja była pusta i zostaje pusta.
        }
    });
