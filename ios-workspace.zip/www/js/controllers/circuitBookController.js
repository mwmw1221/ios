angular.module('app.controllers')
    .controller('circuitBookCtrl', function ($scope, $http, $state, ApiEndpoint, CircuitService, circuits, CircuitBookService, years, $ionicModal, HuntsListOptionsService, LocalStorage, Session) {
        LOCAL_SETTINGS = LocalStorage.getObject("localSettings");

        $scope.loadMoreAvailable = false;
        var currentRegion = Session.getCurrentRegion();

        var data = {
            cId: 'region' in LOCAL_SETTINGS && LOCAL_SETTINGS.region[currentRegion[0]] != null ? LOCAL_SETTINGS.region[currentRegion[0]] : null,
            year: years[0].value,
            currentPage: 1
        };

        $scope.data = data;

        $scope.circuits = circuits;
        $scope.years = years;

        $scope.maxSize = 3;

        $scope.selectCircuit = function () {

        }

        $scope.huntings;
        $scope.pages = [];

        $scope.loadBook = function (cId, year, currentPage) {
            $scope.data.currentPage = currentPage;
            if (cId != null) {
                CircuitBookService.getHuntingFromObw(cId, year, currentPage).then(function (response) {
                    if (response.hunting.length > 0) {
                        $scope.huntings = response.hunting;
                        $scope.pages = [];
                        for (var i = 0; i < response.pages; i++) {
                            $scope.pages.push(i + 1);
                        }
                        if ($scope.pages.length > 1) {
                            $scope.loadMoreAvailable = true;
                        }
                    } else {
                        $scope.huntings = null;
                        $scope.pages = [];
                        $scope.loadMoreAvailable = false;
                    }
                })
            }
        }

        $scope.loadMore = function () {
            $scope.data.currentPage++;
            var d = $scope.data;
            CircuitBookService.getHuntingFromObw(d.cId, d.year, d.currentPage).then(function (response) {
                if (response.hunting.length > 0) {
                    $scope.huntings = $scope.huntings.concat(response.hunting);
                    if (d.currentPage == $scope.pages.length) {
                        $scope.loadMoreAvailable = false;
                    }
                } else {
                    $scope.loadMoreAvailable = false;
                }
            }).finally(function () {
                $scope.$broadcast("scroll.infiniteScrollComplete");
            });
        };


        $scope.show = HuntsListOptionsService.getSettings();
        $scope.sizes = HuntsListOptionsService.getSizes();
        $scope.form = {};

        $scope.saveOptions = function () {
            HuntsListOptionsService.saveSettings($scope.show);
            $scope.form.settings.$setPristine();
        }

        /* Modal for Options */

        $ionicModal.fromTemplateUrl('templates/huntsListOptions.html', {
            scope: $scope,
            animation: 'slide-in-up',
        }).then(function (modal) {
            $scope.modal = modal;
        });

        $scope.openModal = function () {
            $scope.modal.show();
        };

        $scope.closeModal = function () {
            $scope.modal.hide();
        };

        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.modal.remove();
        });

        // Execute action on hide modal
        $scope.$on('modal.hidden', function () {
            // Execute action
        });

        // Execute action on remove modal
        $scope.$on('modal.removed', function () {
            // Execute action
        });

        if (data.cId != null) {
            $scope.loadBook(data.cId, data.year, data.currentPage);
        }
    });