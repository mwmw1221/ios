angular.module('app.controllers')
    .controller('animalsListCtrl', function ($scope, $state, MyPermissionsService, animalsList,  permission) {
        $scope.permission = permission;
        $scope.animals = animalsList;
    });