angular.module('app.controllers')
    .controller('registersCtrl', function ($scope, $state, LocalStorage, CircuitsMapService, circuitList, Session, registerTypes, $cordovaGeolocation, $ionicPopup, $ionicLoading, $translate, $cordovaToast, Camera, RegistersService) {
        LOCAL_SETTINGS = LocalStorage.getObject("localSettings");
        $scope.circuitList = circuitList;

        var districts = {};
        var currentRegion = Session.getCurrentRegion();
        var map = null;
        var shootingMap;
        var circuitRegisters = null;
        var register = {
            circuitId: 'region' in LOCAL_SETTINGS && LOCAL_SETTINGS.region[currentRegion[0]] != null ? LOCAL_SETTINGS.region[currentRegion[0]] : circuitList[0][0],
            name: null,
            typeId: null,
            districtId: null,
            longitude: null,
            latitude: null,
            coords: null,
            file: new Array()
        }

        $scope.register = register;
        $scope.registerTypes = registerTypes;
        $scope.districts = districts;


        // function initMap() {
        //     var elementId = document.getElementById("registerMap");
        //     var element = document.getElementById(elementId);
        //     map = L.map(elementId).setView([52, 20], 12);
        //     addMapTypes();
        //     map.addControl(new L.Control.Compass({ autoActive: true }));
        // }

        function addMapTypes() {
            var osm = L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
                attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors'
            }).addTo(map);
            var arcGis = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}.png", {
                attribution: 'Source: Esri, DigitalGlobe, GeoEye, Earthstar Geographics, CNES/Airbus DS, USDA, USGS, AeroGRID, IGN, and the GIS User Community'
            });

            //orto
            var geoOrto = L.tileLayer.wms("https://mapy.geoportal.gov.pl/wss/service/img/guest/ORTO/MapServer/WMSServer?", {
                layers: 'Raster',
                format: 'image/png',
                transparent: false,
                id: "GEOPORTAL_ORTO",
                crs: L.CRS.EPSG4326,
                version: '1.3.0'
            })

            var baseLayers = {
                "OpenStreetMap": osm,
                "ArcGis": arcGis,
                "Orto": geoOrto
            };
            // opisy
            var ArcGIS2 = L.tileLayer("https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}.png");
            var dzialki = L.tileLayer.wms("https://mapy.geoportal.gov.pl/wss/service/pub/guest/G2_GO_WMS/MapServer/WMSServer?", {
                layers: 'Dzialki,NumeryDzialek',
                format: 'image/png',
                transparent: true,
                id: "dzialki",
                crs: L.CRS.EPSG4326,
                version: '1.3.0',
                tileSize: 512
            });
            var oddzialy = L.tileLayer.wms("http://mapserver.bdl.lasy.gov.pl/ArcGIS/services/WMS_BDL/mapserver/WMSServer?", {
                layers: '0,1,2,3',
                format: 'image/png',
                transparent: true,
                id: "oddzialy",
                crs: L.CRS.EPSG4326,
                version: '1.3.0',
                tileSize: 512
            });
            var rdpl = L.tileLayer.wms("http://mapserver.bdl.lasy.gov.pl/ArcGIS/services/WMS_BDL/mapserver/WMSServer?", {
                layers: '4,5',
                format: 'image/png',
                transparent: true,
                id: "rdpl",
                crs: L.CRS.EPSG4326,
                version: '1.3.0',
                tileSize: 512
            });

            var overlays = {
                "Opisy": ArcGIS2,
                "Działki": dzialki,
                "Oddziały leśne": oddzialy,
                "Rdpl i nadleśnictwa": rdpl
            }

            L.control.layers(baseLayers, overlays).addTo(map);

            map.on('baselayerchange', function (e) {
                if (e.name == "ArcGis" || e.name == 'Orto') {
                    ArcGIS2.addTo(map)
                } else {
                    ArcGIS2.remove()
                }
            });
        }

        $scope.$watch('register.circuitId', function (newValue, oldValue) {
            CircuitsMapService.getDistrictPolygons(newValue, null)
                .then(function (result) {
                    districts[newValue] = result.data.rewirs;
                });
        });

        $scope.addRegister = function () {
            RegistersService.addRegister($scope.register)
                .then(function (response) {
                    $translate('Saved').then($cordovaToast.showLongBottom);
                    $state.go('menu.hunterOptions');
                }, function (err) {
                    console.log(err);
                })
        }

        $scope.openPopup = function () {
            showLocationPopup();
        }

        function isLocationAvailable() {
            cordova.plugins.diagnostic.isLocationEnabled(function (enabled) {
                if (enabled) {
                    getCurrentPosition();
                } else {
                    setDefaultPosition();
                }
            }, function (error) {
                $translate('AnErrorOccured').then($cordovaToast.showLongBottom);
                console.error("The following error occurred: " + error);
            });
        }

        function getLocationAuthorizationStatus() {
            cordova.plugins.diagnostic.getLocationAuthorizationStatus(function (status) {
                switch (status) {
                    case cordova.plugins.diagnostic.permissionStatus.NOT_REQUESTED:
                        console.log("Permission not requested");
                        requestLocationAuthorization();
                        break;
                    case cordova.plugins.diagnostic.permissionStatus.GRANTED:
                        console.log("Permission granted");
                        isLocationAvailable();
                        break;
                    case cordova.plugins.diagnostic.permissionStatus.DENIED:
                        requestLocationAuthorization();
                        console.log("Permission denied");
                        break;
                    case cordova.plugins.diagnostic.permissionStatus.DENIED_ALWAYS:
                        requestLocationAuthorization();
                        console.log("Permission permanently denied");
                        break;
                }
            }, function (error) {
                $translate('ErrorOccurredDownloadingLocationAuthorizationStatus').then($cordovaToast.showLongBottom);
                console.error("The following error occurred: " + error);
            });
        }

        function requestLocationAuthorization() {
            cordova.plugins.diagnostic.requestLocationAuthorization(function (status) {
                switch (status) {
                    case cordova.plugins.diagnostic.permissionStatus.NOT_REQUESTED:
                        console.log("Permission not requested");
                        break;
                    case cordova.plugins.diagnostic.permissionStatus.GRANTED:
                        $translate('PermissionsGranted').then($cordovaToast.showLongBottom);
                        console.log("Permission granted always");
                        isLocationAvailable();
                        break;
                    case cordova.plugins.diagnostic.permissionStatus.DENIED:
                        $translate('PermissionsHaveBeenDenied').then($cordovaToast.showLongBottom);
                        console.log("Permission denied");
                        break;
                    case cordova.plugins.diagnostic.permissionStatus.DENIED_ALWAYS:
                        console.log("Permission permanently denied");
                        break;
                }
            }, function (error) {
                $translate('ErrorGrantingPermissions').then($cordovaToast.showLongBottom);
                console.error(error);
            });
        }

        function showLocationPopup() {
            locationPopup = $ionicPopup.show({
                templateUrl: 'templates/shootingLocation.html',
                title: $translate.instant('MarkLocationOfRegister'),
                scope: $scope,
                buttons: [
                    {
                        text: 'OK',
                        type: 'button-positive',
                        onTap: function (e) {
                            var position = currentPositionMarker.getLatLng();
                            register.latitude = position.lat;
                            register.longitude = position.lng;
                            $ionicLoading.hide();
                        }
                    },
                    {
                        text: $translate.instant('Cancel'),
                        onTap: function (e) {
                            $ionicLoading.hide();
                            return true;
                        }
                    }
                ]
            });
        }
        function initMap() {
            var elementId = document.getElementById("shootingMap");
            var element = document.getElementById(elementId);
            shootingMap = L.map(elementId).setView([52, 20], 12);
            addMapTypes();
        }

        function addMapTypes() {
            var osm = L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
                attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors'
            }).addTo(shootingMap);
            var arcGis = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}.png", {
                attribution: 'Source: Esri, DigitalGlobe, GeoEye, Earthstar Geographics, CNES/Airbus DS, USDA, USGS, AeroGRID, IGN, and the GIS User Community'
            });

            //orto
            var geoOrto = L.tileLayer.wms("https://mapy.geoportal.gov.pl/wss/service/img/guest/ORTO/MapServer/WMSServer?", {
                layers: 'Raster',
                format: 'image/png',
                transparent: false,
                id: "GEOPORTAL_ORTO",
                crs: L.CRS.EPSG4326,
                version: '1.3.0'
            })

            //TOPO
            var geoTopo = L.tileLayer.wms("https://mapy.geoportal.gov.pl/wss/service/img/guest/TOPO/MapServer/WMSServer?", {
                layers: 'Raster',
                format: 'image/png',
                transparent: false,
                id: "GEOPORTAL_TOPO",
                crs: L.CRS.EPSG4326,
                version: '1.3.0'
            });

            var baseLayers = {
                "OpenStreetMap": osm,
                "ArcGis": arcGis,
                "Orto": geoOrto,
                "TOPO": geoTopo
            };
            
            // opisy
            var ArcGIS2 = L.tileLayer("https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}.png");
            var dzialki = L.tileLayer.wms("https://mapy.geoportal.gov.pl/wss/service/pub/guest/G2_GO_WMS/MapServer/WMSServer?", {
                layers: 'Dzialki,NumeryDzialek',
                format: 'image/png',
                transparent: true,
                id: "dzialki",
                crs: L.CRS.EPSG4326,
                version: '1.3.0',
                tileSize: 512
            });
            var oddzialy = L.tileLayer.wms("http://mapserver.bdl.lasy.gov.pl/ArcGIS/services/WMS_BDL/mapserver/WMSServer?", {
                layers: '0,1,2,3',
                format: 'image/png',
                transparent: true,
                id: "oddzialy",
                crs: L.CRS.EPSG4326,
                version: '1.3.0',
                tileSize: 512
            });
            var rdpl = L.tileLayer.wms("http://mapserver.bdl.lasy.gov.pl/ArcGIS/services/WMS_BDL/mapserver/WMSServer?", {
                layers: '4,5',
                format: 'image/png',
                transparent: true,
                id: "rdpl",
                crs: L.CRS.EPSG4326,
                version: '1.3.0',
                tileSize: 512
            });

            var overlays = {
                "Opisy": ArcGIS2,
                "Działki": dzialki,
                "Oddziały leśne": oddzialy,
                "Rdpl i nadleśnictwa": rdpl
            }

            L.control.layers(baseLayers, overlays).addTo(shootingMap);

            shootingMap.on('baselayerchange', function (e) {
                if (e.name == "ArcGis" || e.name == 'Orto') {
                    ArcGIS2.addTo(shootingMap)
                } else {
                    ArcGIS2.remove()
                }
            });
        }

        $scope.initMap = function () {
            initMap();
            getLocationAuthorizationStatus();
        }
        var currentPositionMarker;

        var currentPositionOptions = {
            timeout: 20000,
            enableHighAccuracy: true,
            maximumAge: 0,
        };

        function getCurrentPosition() {
            $ionicLoading.show();
            $cordovaGeolocation.getCurrentPosition(currentPositionOptions)
                .then(onSuccessPosition, onErrorPosition);
        };

        function onSuccessPosition(position) {
            var lat = register.latitude == null ? position.coords.latitude : register.latitude;
            var long = register.longitude == null ? position.coords.longitude : register.longitude;
            currentPositionMarker = createMarker(lat, long);
            currentPositionMarker.addTo(shootingMap);
            shootingMap.panTo(currentPositionMarker.getLatLng());
            $ionicLoading.hide();
        }

        function setDefaultPosition() {
            var lat = 52.94;
            var long = 18.66;
            currentPositionMarker = createMarker(lat, long);
            currentPositionMarker.addTo(shootingMap);
            shootingMap.panTo(currentPositionMarker.getLatLng());
            $ionicLoading.hide();
        }

        function onErrorPosition(err) {
            $translate('RetrievingLocationError').then($cordovaToast.showLongBottom);
            console.log(err);
            $ionicLoading.hide();
        }

        function createMarker(lat, lng) {
            return L.marker([lat, lng], { draggable: true });
        }

        $scope.showPhotoFormPopup = function () {
            var myPopup = $ionicPopup.show({
                title: $translate.instant('AddingPhoto'),
                scope: $scope,
                buttons: [
                    {
                        text: '<i class="icon ion-camera"></i>',
                        type: 'button-positive',
                        onTap: function (e) {
                            $scope.addPhoto(1);
                            return null;
                        }
                    },
                    {
                        text: '<i class="icon ion-image"></i>',
                        type: 'button-positive',
                        onTap: function (e) {
                            console.log(e);
                            $scope.addPhoto(0);
                            return null;
                        }
                    }
                ]
            });
        };

        $scope.addPhoto = function (source) {
            Camera.getPicture(source).then(function (response) {
                var name = response.split("/");
                var file = {
                    name: name[name.length - 1],
                    url: response
                }
                Camera.resolveFile(file.url).then(function (response) {
                    $scope.register.file.push(response);
                    console.log($scope.register.file);
                    $translate('Saved').then($cordovaToast.showLongBottom);
                }, function (err) {
                    console.log(err);
                    // $cordovaToast.showLongBottom(err);
                });
            }, function (err) {
                console.log(err);
                $cordovaToast.showLongBottom(err);
            });
        };
    });