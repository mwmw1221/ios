angular.module('app.controllers')
    .controller('circuitsMapCtrl', function ($scope, $q, $timeout, $cordovaToast, $sce, $base64, $http, $state, Session, ApiEndpoint, $ionicLoading, LocalStorage, CircuitService, CircuitsMapService, registerTypes, $ionicPopover, $ionicPopup, $cordovaGeolocation, $ionicLoading, $ionicModal, $interval, $translate) {
        var currentRegion = Session.getCurrentRegion();
        LOCAL_SETTINGS = LocalStorage.getObject("localSettings");
        MAP_OPTIONS = LocalStorage.getObject("mapOptions");

        var map = null;
        var environment = ApiEndpoint.HOST;
        var popupGroup = L.featureGroup();
        var layerControls;

        var fullBounds = L.latLngBounds();
        var circuitPolygon = {};

        $scope.carEditing = false;

        $scope.form = {};

        $scope.show = 'region' in MAP_OPTIONS && MAP_OPTIONS.region[currentRegion[0]] != null ? MAP_OPTIONS.region[currentRegion[0]] : {
            circuitId: 'region' in LOCAL_SETTINGS && LOCAL_SETTINGS.region[currentRegion[0]] != null ? LOCAL_SETTINGS.region[currentRegion[0]] : null,
            districts: false,
            myPosition: false,
            carPosition: false,
            dongleCarPosition: false,
            selectedDongleId: null,
            registers: new Array(),
            hunters: false
        };

        $scope.registers = registerTypes;
        $scope.circuitRegisters;
        $scope.chosen = { registers: null };
        $scope.dongleList;
        $scope.hunters;

        var huntersMarkers;
        var circuitRegisters;
        var markers = [];
        var circuitsOnMap = [];
        var districtsOnMap = {};
        var carPositionMarker;
        var donglePositionMarker;
        var dongleList;
        var dongleCircle;

        var carPositionCoords = {
            lat: null,
            lng: null
        };

        var compass;
        var previousCircuitId;

        function sanitizeFilename(name) {
            if (!name) return '';
            //return name.replace(/[^0-9A-Za-ząćęłńóśżźĄĆĘŁŃÓŚŻŹ ._-]/g, '_').replace(/\s+/g, '_');
            return name
        }

        var resolveIcons = function () {
            for (var i = 0; i < registerTypes.length; i++) {
                var name = registerTypes[i].name || registerTypes[i].nazwa || registerTypes[i].typ || ('type' + (i + 1));
                var filename = (i + 1) + '_' + sanitizeFilename(name) + '.png';
                registerTypes[i].zdj = 'img/registers/' + filename;
            }
        }

        var resolveBusyIcons = function () {
            for (var i = 0; i < registerTypes.length; i++) {
                var name = registerTypes[i].name || registerTypes[i].nazwa || registerTypes[i].typ || ('type' + (i + 1));
                var filename = (i + 1) + '_' + sanitizeFilename(name) + '_busy.png';
                registerTypes[i].zdjBusy = 'img/registers/' + filename;
            }
        }

        var getIcon = function (url) {
            // Angular $http() and then() both return promises themselves 
            return $http({
                method: 'GET',
                url: "https://corsproxy.io/?" + encodeURIComponent(environment + url),
                responseType: 'arraybuffer'
            }).then(function (response) {
                var str = _arrayBufferToBase64(response.data);
                return str;
            }, function (response) {
                console.error('error in getting static img.');
            });
        };

        var getImageForPopup = function (url) {
            // Angular $http() and then() both return promises themselves 
            return $http({
                method: 'GET',
                url: url,
                responseType: 'arraybuffer',
                headers: {
                    'Authorization': 'Basic ' + $base64.encode('jpalio' + ':' + 'Torn')
                }
            }).then(function (response) {
                var str = _arrayBufferToBase64(response.data);
                return str;
            }, function (response) {
                console.error('error in getting static img.');
            });
        };

        getCircuitRegisters = function (circuitId) {
            CircuitsMapService.getRegistersDataNew($scope.data.circuitId, null)
                .then(function (result) {
                    circuitRegisters = result;

                    if ($scope.show.registers) {
                        var loadedRegisters = $scope.show.registers;
                        var r = $scope.registers;
                        for (var i = 0; i < loadedRegisters.length; i++) {
                            for (var j = 0; j < r.length; j++) {
                                if (loadedRegisters[i] == r[j].id) {
                                    r[j].checked = true;
                                    $scope.checkRegister(r[j]);
                                }
                            }
                        }
                    }
                });
        }

        function _arrayBufferToBase64(buffer) {
            var binary = '';
            var bytes = new Uint8Array(buffer);
            var len = bytes.byteLength;
            for (var i = 0; i < len; i++) {
                binary += String.fromCharCode(bytes[i]);
            }
            return window.btoa(binary);
        }

        function loadRegisterMarker(register) {
            if (markerList[register.name]) {
                var p = markerList[register.name];
                for (x = 0; x < p.length; x++) {
                    if (register.checked) {
                        p[x].addTo(map);
                    } else {
                        p[x].remove(map);
                    }
                }
            } else {
                var arrayForType = [];
                for (var cr in circuitRegisters) {
                    if (circuitRegisters[cr].typ == register.name) {
                        var marker;
                        var additionalMarker = null;
                        var iconPic = circuitRegisters[cr].isBusy ? register.zdjBusy : register.zdj;
                        var resolvedIconUrl = '';
                        if (typeof iconPic === 'string') {
                            if (iconPic.indexOf('data:') === 0 || iconPic.indexOf('http') === 0 || iconPic.indexOf('img/') === 0 || iconPic.indexOf('/') === 0) {
                                resolvedIconUrl = iconPic;
                            } else if (iconPic.length > 0) {
                                resolvedIconUrl = 'data:image/png;base64,' + iconPic;
                            }
                        }
                        switch (circuitRegisters[cr].mapType) {
                            case 'MARKER':
                                marker = L.marker(circuitRegisters[cr].mapCoords[0], {
                                    title: circuitRegisters[cr].name,
                                    icon: L.icon({
                                        iconUrl: resolvedIconUrl || 'img/male.png',
                                        iconAnchor: [16, 37],
                                        popupAnchor: [0, -37]
                                    }),
                                });
                                break;
                            case 'POLYGON':
                                marker = L.polygon(circuitRegisters[cr].mapCoords, {
                                    title: circuitRegisters[cr].name,
                                });
                                additionalMarker = L.marker([circuitRegisters[cr].cx, circuitRegisters[cr].cy], {
                                    title: circuitRegisters[cr].name,
                                    icon: L.icon({
                                        iconUrl: resolvedIconUrl || 'img/male.png',
                                        iconAnchor: [16, 37],
                                        popupAnchor: [0, -37]
                                    }),
                                });
                                break;
                            case 'CIRCLE':
                                marker = L.circle(circuitRegisters[cr].mapCoords[0], {
                                    radius: circuitRegisters[cr].mapCoords[circuitRegisters[cr].mapCoords.length - 1][0],
                                    title: circuitRegisters[cr].name,
                                });
                                break;
                            case 'POLYLINE':
                                marker = L.polyline(circuitRegisters[cr].mapCoords, {
                                    title: circuitRegisters[cr].name,
                                });
                                break;
                        }
                        marker.myCustomID = cr;
                        if (circuitRegisters[cr].picLink.length > 0) {
                            marker.bindPopup().addTo(popupGroup);
                            marker.on('mousedown', addMarkerPopupInfoWithPicture);
                            if (circuitRegisters[cr].mapType === 'POLYGON' && additionalMarker != null) {
                                additionalMarker.on('mousedown', addMarkerPopupInfoWithPicture);
                            }
                        } else {
                            addMarkerPopupInfo(marker, circuitRegisters[cr]);
                            if (circuitRegisters[cr].mapType === 'POLYGON' && additionalMarker != null) {
                                addMarkerPopupInfo(additionalMarker, circuitRegisters[cr]);
                            }
                        }
                        if (register.checked) {
                            marker.addTo(map);
                            if (circuitRegisters[cr].mapType === 'POLYGON' && additionalMarker != null) {
                                additionalMarker.addTo(map);
                            }
                        }
                        arrayForType.push(marker);
                        if (circuitRegisters[cr].mapType === 'POLYGON' && additionalMarker != null) {
                            arrayForType.push(additionalMarker);
                        }
                    }
                }
                markerList[register.name] = arrayForType;
            }
        }

        function addMarkerPopupInfo(marker, register) {
            var destination;
            /* Because for other types of registers like polygons etc, the variable for latlng is an array and changes its name to latlngs */
            if (Array.isArray(marker._latlngs)) {
                if (Array.isArray(marker._latlngs[0])) {
                    destination = marker._latlngs[0][0].lat + ',' + marker._latlngs[0][0].lng;
                } else {
                    destination = marker._latlngs[0].lat + ',' + marker._latlngs[0].lng;
                }
            } else {
                destination = marker._latlng.lat + ',' + marker._latlng.lng;
            }
            var content = register.name + " <br>" + register.opis;
            content += "<br><br><button onclick=\"window.open(\'geo:0,0?q=" + destination + "\', \'_system\')\" class=\"button button-small icon-right ion-chevron-right button-positive\">" + $translate.instant("GoTo") + "</button><br>";
            // if (!register.isBusy) {
            //     content += "<br><button ng-click=\"" + destination + "\', \'_system\')\" class=\"button button-small icon-right ion-chevron-right button-positive\">" + $translate.instant("SignUpForHunting") + "</button>";
            // }
            marker.bindPopup(content).addTo(popupGroup);
        }

        function addMarkerPopupInfoWithPicture(e) {
            var markerEvent = e.target;
            var promises = new Array();
            for (var i = 0; i < circuitRegisters[markerEvent.myCustomID].picLink.length; i++) {
                var promise = getImageForPopup(circuitRegisters[markerEvent.myCustomID].picLink[i]);
                promises.push(promise);
            }
            $q.all(promises).then(function (response) {
                var pictures = '';
                for (var i = 0; i < response.length; i++) {
                    pictures += "<br><img src=\"data:image/png;base64," + response[i] + "\"/>";
                }

                var destination;
                if (Array.isArray(markerEvent._latlngs)) {
                    if (Array.isArray(markerEvent._latlngs[0])) {
                        destination = markerEvent._latlngs[0][0].lat + ',' + markerEvent._latlngs[0][0].lng;
                    } else {
                        destination = markerEvent._latlngs[0].lat + ',' + markerEvent._latlngs[0].lng;
                    }
                } else {
                    destination = markerEvent._latlng.lat + ',' + markerEvent._latlng.lng;
                }

                var content = "<div class=\"popup-wrapper-scroll\">" + circuitRegisters[markerEvent.myCustomID].name + " <br>" + circuitRegisters[markerEvent.myCustomID].opis;
                content += "<br><br><button onclick=\"window.open(\'geo:0,0?q=" + destination + "\', \'_system\')\" class=\"button button-small icon-right ion-chevron-right button-positive\">" + $translate.instant("GoTo") + "</button><br>";
                content += pictures + "</div>";
                markerEvent.setPopupContent(content);
            })
        }

        var markerList = {};

        $scope.checkRegister = function (register) {
            loadRegisterMarker(register);
        }

        function clearRegisters() {
            for (var i in $scope.registers) {
                $scope.registers[i].checked = false;
            }
            for (var marker in markerList) {
                var p = markerList[marker];
                for (x = 0; x < p.length; x++) {
                    p[x].remove();
                }
            }
            markerList = [];
        }

        function clearHunterPositions() {
            for (var i in huntersMarkers) {
                huntersMarkers[i].remove();
            }
            huntersMarkers = [];
        }

        function clearDistricts() {
            for (var i in districtsOnMap) {
                for (var j in districtsOnMap[i]) {
                    districtsOnMap[i][j].remove();
                }
            }
        }

        function clearDistrictsByCircuitId(circuitId) {
            for (var i in districtsOnMap[circuitId]) {
                districtsOnMap[circuitId][i].remove();
            }
        }

        function deleteCircuitById(id) {
            if (circuitPolygon[id]) {
                var p = circuitPolygon[id];
                p.remove();
            }
        }

        function clearCircuits() {
            for (var i in circuitPolygon) {
                circuitPolygon[i].remove();
            }
        }
        function clearMap() {
            clearCircuits();
            clearDistricts();
            clearRegisters();
            clearHunterPositions();
        }

        function initMap() {
            var elementId = document.getElementById("map");
            var element = document.getElementById(elementId);
            map = L.map(elementId).setView([52, 20], 12);
            addMapTypes();
            var lastZoom;
            map.on('zoomend', function () {
                var zoom = map.getZoom();
                if (zoom < 11 && (!lastZoom || lastZoom >= 11)) {
                    map.eachLayer(function (l) {
                        var toolTip = l.getTooltip();
                        if (toolTip) {
                            if (toolTip.options.className == 'leafletTooltipNoBorder') {
                                l.closeTooltip();
                            }
                        }
                    });
                } else if (zoom >= 11 && (!lastZoom || lastZoom < 11)) {
                    map.eachLayer(function (l) {
                        if (l.getTooltip) {
                            var toolTip = l.getTooltip();
                            if (toolTip) {
                                if (toolTip.options.className == 'leafletTooltipNoBorder') {
                                    map.addLayer(toolTip);
                                    toolTip.openTooltip();
                                }
                            }
                        }
                    });
                }
                lastZoom = zoom;
            })
            compass = new L.Control.Compass({ autoActive: true });
            map.addControl(compass);
            checkScreen();
        }

        window.addEventListener("orientationchange", function () {
            checkScreen()
        }, false);

        function checkScreen() {
            var orientation = screen.orientation.type;
            if (orientation === "landscape-primary") {
                changeOrientation(90);
            } else if (orientation === "landscape-secondary") {
                changeOrientation(270);
            } else if (orientation === "portrait-primary") {
                changeOrientation(0);
            } else if (orientation === "portrait-secondary") {
                changeOrientation(180);
            } else {
                changeOrientation(0);
            }
        }

        function changeOrientation(deg) {
            compass.setOrientation(deg)
        }

        function addMapTypes() {
            var glLayer = L.maplibreGL({
                style: 'map/style.json',
            }).addTo(map);
        }

        function enableMap() {
            $ionicLoading.hide();
        }

        function disableMap() {
            $ionicLoading.show({
                template: 'wczytywanie'
            });
        }

        function loadGoogleMaps() {
            $ionicLoading.show({
                template: 'Wczytywanie'
            });
            initMap();
        }

        loadGoogleMaps();

        $scope.circuitList;
        var districts = {};

        $scope.data = {};

        CircuitService.getList()
            .then(function (result) {
                $scope.circuitList = result;
                $scope.data.circuitId = $scope.show.circuitId != null ? $scope.show.circuitId : $scope.circuitList[0][0];
                $scope.show.circuitId = $scope.data.circuitId;
                $scope.getCircuitMap();
            });

        var circuitMap;

        $scope.getCircuitMap = function () {
            // Clear whole map
            if (circuitPolygon)
                clearMap();
            CircuitsMapService.getCircuitMap($scope.data.circuitId)
                .then(function (result) {
                    circuitMap = result.data;
                    var latLngs = new Array();
                    for (var i = 0; i < circuitMap.coords.length; i++) {
                        latLngs.push(new Array(circuitMap.coords[i][1], circuitMap.coords[i][0]));
                    }
                    var p = L.polygon(latLngs, { color: 'red', fill: false, stroke: true, pmIgnore: false });
                    p.addTo(map);
                    circuitPolygon[$scope.data.circuitId] = p;
                    fullBounds = p.getBounds();
                    map.fitBounds(fullBounds);

                    $scope.show.circuitId = $scope.data.circuitId;

                    CircuitsMapService.getDistrictPolygons($scope.data.circuitId, null)
                        .then(function (result) {
                            districts[$scope.data.circuitId] = result.data.rewirs;
                            $scope.showDistricts();
                        });

                    getCircuitRegisters();

                    if ($scope.show.hunters) {
                        showHunterPositions();
                    }
                });

        };

        $scope.showDistricts = function () {
            var cId = $scope.data.circuitId;
            if ($scope.show.districts) {
                if (districtsOnMap[cId]) {
                    for (var d in districtsOnMap[cId]) {
                        districtsOnMap[cId][d].addTo(map);
                    }
                } else {
                    districtsOnMap[cId] = new Array();
                    for (var i = 0; i < districts[cId].length; i++) {
                        var path = [];
                        for (var j = 0; j < districts[cId][i].wsp.length; j++) {
                            path.push(new Array(districts[cId][i].wsp[j][1], districts[cId][i].wsp[j][0]));
                        }
                        var district = L.polygon(path, {
                            color: districts[cId][i].color,
                            opacity: 0.8,
                            weight: 2,
                            fillColor: districts[cId][i].color,
                            fillOpacity: districts[cId][i].transparent,
                            name: districts[cId][i].name
                        });
                        //district.bindPopup(districts[cId][i].name).addTo(popupGroup);
                        district.addTo(map);
                        district.bindTooltip(districts[cId][i].name,
                            { permanent: true, direction: "center", className: "leafletTooltipNoBorder" }
                        ).openTooltip();
                        districtsOnMap[cId].push(district);
                    }
                }
                map.fitBounds(fullBounds);
            } else {
                clearDistrictsByCircuitId(cId);
            }
        }


        /*************************** Run loading icons *********************************/
        resolveIcons();
        resolveBusyIcons();

        /*************************** Registers popup: **********************************/
        $scope.chooseRegistersPopup = function () {

            var myPopup = $ionicPopup.show({
                templateUrl: 'templates/registersPopup.html',
                title: $translate.instant('SelectRegistersToDisplay'),
                scope: $scope,
                buttons: [
                    {
                        text: 'OK',
                        type: 'button-positive'
                    }
                ]
            });
        };


        /* Hunter Location */
        var watch;
        var currentPositionMarker;

        $scope.myPosition = {
            latitude: null,
            longitude: null
        };

        var watchOptions = {
            timeout: 500,
            enableHighAccuracy: true
        };

        var currentPositionOptions = {
            timeout: 8000,
            enableHighAccuracy: false
        };

        function getCurrentPosition() {
            $ionicLoading.show();
            $cordovaGeolocation.getCurrentPosition(currentPositionOptions)
                .then(onSuccessPosition, onErrorPosition);
        };

        function onSuccessPosition(position) {
            var lat = position.coords.latitude;
            var long = position.coords.longitude;
            currentPositionMarker = createMarker(lat, long);
            currentPositionMarker.addTo(map);
            map.panTo(currentPositionMarker.getLatLng());
            $ionicLoading.hide();
        }

        function onSuccessWatch(position) {
            var lat = position.coords.latitude;
            var long = position.coords.longitude;

            if (currentPositionMarker) {
                currentPositionMarker.setLatLng([lat, long]);
            }
        }

        function onErrorPosition(err) {
            console.log(err);
        }

        $scope.showMyPosition = function () {
            if ($scope.show.myPosition) {
                getCurrentPosition();
                watch = navigator.geolocation.watchPosition(onSuccessWatch, onErrorPosition, watchOptions);
            } else if (!$scope.show.myPosition) {
                removeMarker(currentPositionMarker);
                watch.clearWatch();
            }
        };

        function createMarker(lat, lng) {
            return L.marker([lat, lng]);
        }
        function removeMarker(marker) {
            if (marker)
                marker.remove();
        }

        function removeCircle(circle) {
            if (circle) {
                circle.remove();
                circle = null;
            }
        }

        $scope.showCarPosition = function () {
            if ($scope.show.carPosition) {
                if ($scope.show.dongleCarPosition) {
                    $scope.show.dongleCarPosition = false;
                }
                CircuitsMapService.getCarPosition()
                    .then(function (response) {
                        showCarMarker(response.latitude, response.longitude, false);
                    })
            }
            else if (!$scope.show.carPosition) {
                removeMarker(carPositionMarker);
                carPositionMarker = null
            }
        }

        function showCarMarker(lat, lng, drag) {
            carPositionMarker = L.marker([lat, lng], {
                icon: L.icon({
                    iconUrl: "img/carIcon.png",
                    iconSize: [48, 48],
                    iconAnchor: [24, 48]
                }),
            })
            carPositionMarker.addTo(map);
            map.panTo(carPositionMarker.getLatLng());

            if (drag) {
                carPositionMarker.dragging.enable();
            } else {
                carPositionMarker.on('click', onClickCarPosition);
            }
        }

        function showDongleMarker(lat, lng, drag) {
            donglePositionMarker = L.marker([lat, lng], {
                icon: L.icon({
                    iconUrl: "img/carIcon.png",
                    iconSize: [48, 48],
                    iconAnchor: [24, 48]
                }),
            })
            donglePositionMarker.addTo(map);
            map.panTo(donglePositionMarker.getLatLng());

            if (drag) {
                donglePositionMarker.dragging.enable();
            }
        }

        function showCarDongleCircle(lat, lng, radius) {
            dongleCircle = L.circle([lat, lng], { radius: radius }).addTo(map);
        }

        $scope.enableCarEditing = function (carEditing) {
            $scope.carEditing = carEditing;
            if ($scope.show.dongleCarPosition) {
                $scope.show.dongleCarPosition = false;
            }
            if (carEditing) {
                var dragging = carEditing;
                $cordovaGeolocation.getCurrentPosition(currentPositionOptions)
                    .then(function (position) {
                        var lat = position.coords.latitude;
                        var lng = position.coords.longitude;
                        showCarMarker(lat, lng, dragging);
                    }, function (error) {
                        var coordinates = map.getCenter();
                        showCarMarker(coordinates.lat, coordinates.lng, dragging);
                        carPositionCoords.lat = null;
                        carPositionCoords.lng = null;
                    });
                $scope.show.carPosition = true;
                $scope.closeModal();
            }
        }

        $scope.saveCarPosition = function () {
            if (carPositionMarker) {
                var markerLatLng = carPositionMarker.getLatLng();
                CircuitsMapService.setCarPosition(markerLatLng.lng, markerLatLng.lat)
                    .then(function (response) {
                        if (response.action) {
                            $translate('LocationOfVehicleSaved').then($cordovaToast.showLongBottom);
                            $scope.enableCarEditing(false);
                            carPositionMarker.dragging.disable();
                        }
                    })
            }
        }

        $scope.cancelCarPosition = function () {
            $scope.carEditing = false;
            if (carPositionMarker) {
                $scope.show.carPosition = false;
                removeMarker(carPositionMarker);
                carPositionMarker = null;

                if (carPositionCoords.lat && carPositionCoords.lng) {
                    showCarMarker(carPositionCoords.lat, carPositionCoords.lng, false);
                    $scope.show.carPosition = true;
                }
            }
        }
        /* Modal with options */

        $ionicModal.fromTemplateUrl('templates/circuitMapOptions.html', {
            scope: $scope,
            animation: 'slide-in-up',
        }).then(function (modal) {
            $scope.modal = modal;
        });

        $scope.openModal = function () {
            $scope.modal.show();
        };

        $scope.closeModal = function () {
            $scope.modal.hide();
        };

        //Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function () {
            $scope.modal.remove();
        });

        // Execute action on hide modal
        $scope.$on('modal.hidden', function () {
            // Execute action
        });

        // Execute action on remove modal
        $scope.$on('modal.removed', function () {
            // Execute action
        });

        var stopDongleInterval;

        $scope.loadDongles = function () {
            if ($scope.show.dongleCarPosition) {
                CircuitsMapService.getTtxBox()
                    .then(function (response) {
                        dongleList = response.boxList;
                        $scope.dongleList = dongleList
                    })
            }
        }

        $scope.loadDongleLocalization = function () {
            if ($scope.show.carPosition) {
                $scope.show.carPosition = false;
                removeMarker(carPositionMarker);
                carPositionMarker = null;
            }
            $scope.stopDongleInterval();
            removeDongleLocalization();
            var id = $scope.show.selectedDongleId;
            getTtxBoxPosition(id);
            stopDongleInterval = $interval(getTtxBoxPosition, 15000, 0, true, id);
        };

        $scope.stopDongleInterval = function () {
            $interval.cancel(stopDongleInterval);
            stopDongleInterval = undefined;
        };

        function removeDongleLocalization() {
            removeMarker(donglePositionMarker);
            removeCircle(dongleCircle);
            carPositionMarker = null;
        };

        $scope.$on('$destroy', function () {
            $scope.stopDongleInterval();
        });

        function getTtxBoxPosition(id) {
            CircuitsMapService.getTtxBoxPosition(id)
                .then(function (response) {
                    removeDongleLocalization();
                    var box = response.box;
                    showDongleMarker(box.LATITUDE, box.LONGITUDE, false);
                    showCarDongleCircle(box.LATITUDE, box.LONGITUDE, box.UNCERTAINTY);
                }, function (err) {
                    $scope.stopDongleInterval();
                })
        }

        $scope.$on('$stateChangeSuccess', function () {
            $scope.stopDongleInterval();
        });

        $scope.$watch('show.dongleCarPosition', function (newValue, oldValue) {
            if (!newValue && (newValue != oldValue)) {
                $scope.stopDongleInterval();
                removeDongleLocalization();
                $scope.show.selectedDongleId = null;
            }
        });

        $scope.saveMapOptions = function () {
            var r = $scope.registers;
            $scope.show.registers = new Array();
            for (var i = 0; i < r.length; i++) {
                if (r[i].checked) {
                    $scope.show.registers.push(r[i].id);
                }
            }
            var regionId = currentRegion[0];
            
            if(MAP_OPTIONS.region != null) {
                MAP_OPTIONS.region[regionId] = $scope.show;
            } else {
                MAP_OPTIONS = { region: {
                    [regionId]: $scope.show
                }}
            }
            LocalStorage.setObject("mapOptions", MAP_OPTIONS);
            $translate('Saved').then($cordovaToast.showLongBottom);
        }

        /* Check if loaded values from storage are true - then we need to invoke the logic */
        if ($scope.show.myPosition) {
            $scope.showMyPosition();
        }
        if ($scope.show.carPosition) {
            $scope.showCarPosition();
        }
        if ($scope.show.dongleCarPosition) {
            $scope.loadDongles();
            if ($scope.show.selectedDongleId != null) {
                $scope.loadDongleLocalization();
            }
        }

        function onClickCarPosition(e) {
            var destination = this._latlng.lat + ',' + this._latlng.lng;
            window.open('geo:0,0?q=' + destination, '_system');
        }

        $scope.showHunters = function () {
            if ($scope.show.hunters) {
                showHunterPositions();
            } else {
                clearHunterPositions();
            }
        }

        function showHunterPositions() {
            CircuitsMapService.getHuntersPosition($scope.show.circuitId)
                .then(function (response) {
                    var points = response.points;
                    for (var i in points) {
                        var marker = L.marker([points[i].LATITUDE, points[i].LONGITUDE], {
                            title: points[i].type,
                            icon: L.icon({
                                iconUrl: 'img/male.png',
                                iconAnchor: [16, 37],
                                popupAnchor: [0, -37]
                            }),
                        });
                        marker.addTo(map);
                        marker.bindPopup(points[i].desc).addTo(popupGroup);
                        huntersMarkers.push(marker);
                    }
                })
        }

    });