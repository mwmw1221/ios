angular.module('app.controllers')
    .controller('ddePrintCtrl', function ($scope, LocalStorage, Session, $state, dde, $stateParams, DDEPrintService, $ionicHistory, $translate, $cordovaToast) {
        var dde = dde;
        $scope.dde = dde;

        var newDDE = {
            huntingId: $stateParams.huntingId,
            animalId: $stateParams.animalId,
            wetId: dde.animal.DDE_wet_id,
            age: dde.animal.WIEK,
            asf: dde.animal.DDE_obszar_asf,
            plwNumber: dde.animal.DDE_numer_plw,
            symptoms: dde.animal.DDE_objawy,
            fullWeight: parseFloat(dde.animal.DDE_waga_brutto),
            protAutoNr: null,
            protNr: dde.animal.DDE_numer
        }
        $scope.newDDE = newDDE;

        $scope.saveDDE = function () {
            DDEPrintService.saveDDE($scope.newDDE)
                .then(function (response) {
                    if (response.action) {
                        $translate('Saved').then($cordovaToast.showLongBottom);
                        $ionicHistory.goBack();
                    }
                })
        }

        $scope.openDDE = function (url) {
            window.open(url, '_system', 'location=no');
        }
    });