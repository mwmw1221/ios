angular.module('app.controllers')
    .controller('ohzDemandCtrl', function ($scope, demands) {
        $scope.demands = demands;
    });