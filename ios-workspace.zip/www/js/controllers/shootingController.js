angular.module('app.controllers')
    .controller('shootingCtrl', function ($scope, $http, $state, $ionicHistory, ApiEndpoint, ionicTimePicker, OpenedHuntService, huntingId, shooting, permits, districts, $cordovaGeolocation, $ionicPopup, $ionicLoading, $ionicModal, pptype, Camera, $cordovaToast, UtilsService, $translate) {
        shooting = shooting || {
            'huntingId': huntingId,
            'animalId': null,
            'shotDate': null,
            'shotTime': null,
            'newAnimalPermitId': null,
            'destiny': null,
            'antlerId': null,
            'animalTypeId': null,
            'latitude': null,
            'longitude': null,
            'isMaleSex': null,
            'isMaleSexDefault': null,
            'animalCount': 1,
            'isFat': null,
            'districtId': null,
            'weight': null,
            'clinicalSymptoms' : null
        }

        if (shooting.shotTime) {
            shooting.shotTime = UtilsService.convertingDateTimezone(shooting.shotTime);
        }
        var animal = {
            'id': null,
            'isMaleSex': null,
            'antlers': null,
            'isFat': null
        };

        var pptype = pptype;

        $scope.attachment = {
            name: null,
            url: null,
            fileType: null
        };

        $scope.animal = animal;
        $scope.permits = permits;
        $scope.antlers = null;
        $scope.shootingDateForRevert = null;
        $scope.districts = districts;

        if (districts.length === 1) {
            shooting.districtId = districts[0][0];
        }

        $scope.destinyPicklist =
            [
                { label: $translate.instant('OwnUse'), value: 'W' },
                { label: $translate.instant('CollectionPoint'), value: 'P' },
                { label: $translate.instant('DirectSelling'), value: 'B' },
                { label: $translate.instant('ForAssociation'), value: 'K' }
            ];

        $scope.isMaleQuestion =
            [
                { label: $translate.instant('Yes'), value: 'T' },
                { label: $translate.instant('No'), value: 'N' },
            ];

        var edit = shooting.animalId ? true : false;
        $scope.edit = edit;

        if (!edit && permits.length < 2) {
            $scope.animals = OpenedHuntService.getAnimals();
        }

        $scope.shooting = shooting;

        $scope.$watch('shooting.newAnimalPermitId', function () {
            if ($scope.shooting.newAnimalPermitId) {
                OpenedHuntService.getAnimalsRequest($scope.shooting.newAnimalPermitId).then(function (result) {
                    $scope.animals = result;
                })
            }
        });

        $scope.saveShooting = function () {
            if (pptype == 'S') {
                if (!$scope.shooting.latitude && !$scope.shooting.longitude) {
                    noLocationPopup();
                } else {
                    saveShooting();
                }
            } else {
                saveShooting();
            }
        }

        function saveShooting() {
            $scope.shootingDateForRevert = $scope.shooting.shotDate;
            $scope.shooting.shotDate.setHours(0, -$scope.shooting.shotDate.getTimezoneOffset(), 0, 0);
            $scope.shooting.shotDate = $scope.shooting.shotDate.toISOString().substring(0, 10);

            var shootingTimeBackup = $scope.shooting.shotTime;
            $scope.shooting.shotTime = UtilsService.convertDateToTime($scope.shooting.shotTime);

            if (!edit) {
                OpenedHuntService.addShooting($scope.shooting).then(function (result) {
                    if ($scope.attachment.url) {
                        Camera.uploadPhoto($scope.attachment.url, $scope.shooting.huntingId, result.newAnimalId, $scope.attachment.fileType).then(function (result) {

                            console.log(result);
                            $cordovaToast.showLongBottom(result);
                            $state.go("menu.openedHunt", { openHuntingId: $scope.shooting.huntingId });
                        }, function (err) {
                            $cordovaToast.showLongBottom(err);
                        })
                    } else {
                        $state.go("menu.openedHunt", { openHuntingId: $scope.shooting.huntingId });
                    }
                }, function (error) {
                    $scope.shooting.shotDate = $scope.shootingDateForRevert;
                    $scope.shooting.shotTime = shootingTimeBackup;
                })
            }
            else {
                OpenedHuntService.editShooting($scope.shooting).then(function (result) {
                    if ($scope.attachment.url) {
                        Camera.uploadPhoto($scope.attachment.url, $scope.shooting.huntingId, $scope.shooting.animalId, $scope.attachment.fileType).then(function (result) {
                            console.log(result);
                            $cordovaToast.showLongBottom(result);
                            $state.go("menu.openedHunt", { openHuntingId: $scope.shooting.huntingId });
                        }, function (err) {
                            $cordovaToast.showLongBottom(err);
                        })
                    } else {
                        $state.go("menu.openedHunt", { openHuntingId: $scope.shooting.huntingId });
                    }
                }, function (error) {
                    $scope.shooting.shotDate = $scope.shootingDateForRevert;
                    $scope.shooting.shotTime = shootingTimeBackup;
                })
            }
        }

        function loadAntlers(animalId) {
            return OpenedHuntService.getAntlerTypes(animalId)
                .then(function (response) {
                    return $scope.antlers = response;
                })
        }

        $scope.loadSelectedAnimalData = function (animalId) {
            for (var animal in $scope.animals) {
                var a = $scope.animals[animal];
                if (a[0] == animalId) {
                    $scope.animal.id = a[0];
                    $scope.animal.antlers = loadAntlers(a[0]);
                    $scope.animal.isFat = a[2];
                    $scope.animal.isMaleSex = a[3];
                }
            }
        }

        if (edit) {
            var animalTypeId = shooting.animalTypeId
            $scope.animal.id = animalTypeId;
            $scope.animal.antlers = loadAntlers(animalTypeId);
            $scope.animal.isMaleSex = shooting.isMaleSexDefault;
            $scope.animal.isFat = shooting.isFat;
        }

        $scope.goBack = function () {
            $ionicHistory.goBack();
        };

        $scope.addLocation = function () {

        };

        function initMap() {
            var elementId = document.getElementById("shootingMap");
            var element = document.getElementById(elementId);
            shootingMap = L.map(elementId).setView([52, 20], 12);
            addMapTypes();
        }

        function addMapTypes() {
            var osm = L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
                attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors'
            }).addTo(shootingMap);
            var arcGis = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}.png", {
                attribution: 'Source: Esri, DigitalGlobe, GeoEye, Earthstar Geographics, CNES/Airbus DS, USDA, USGS, AeroGRID, IGN, and the GIS User Community'
            });

            //orto
            var geoOrto = L.tileLayer.wms("https://mapy.geoportal.gov.pl/wss/service/img/guest/ORTO/MapServer/WMSServer?", {
                layers: 'Raster',
                format: 'image/png',
                transparent: false,
                id: "GEOPORTAL_ORTO",
                crs: L.CRS.EPSG4326,
                version: '1.3.0'
            })

            //TOPO
            var geoTopo = L.tileLayer.wms("https://mapy.geoportal.gov.pl/wss/service/img/guest/TOPO/MapServer/WMSServer?", {
                layers: 'Raster',
                format: 'image/png',
                transparent: false,
                id: "GEOPORTAL_TOPO",
                crs: L.CRS.EPSG4326,
                version: '1.3.0'
            });

            var baseLayers = {
                "OpenStreetMap": osm,
                "ArcGis": arcGis,
                "Orto": geoOrto,
                "TOPO": geoTopo
            };
            // opisy
            var ArcGIS2 = L.tileLayer("https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}.png");
            var dzialki = L.tileLayer.wms("https://mapy.geoportal.gov.pl/wss/service/pub/guest/G2_GO_WMS/MapServer/WMSServer?", {
                layers: 'Dzialki,NumeryDzialek',
                format: 'image/png',
                transparent: true,
                id: "dzialki",
                crs: L.CRS.EPSG4326,
                version: '1.3.0',
                tileSize: 512
            });
            var oddzialy = L.tileLayer.wms("http://mapserver.bdl.lasy.gov.pl/ArcGIS/services/WMS_BDL/mapserver/WMSServer?", {
                layers: '0,1,2,3',
                format: 'image/png',
                transparent: true,
                id: "oddzialy",
                crs: L.CRS.EPSG4326,
                version: '1.3.0',
                tileSize: 512
            });
            var rdpl = L.tileLayer.wms("http://mapserver.bdl.lasy.gov.pl/ArcGIS/services/WMS_BDL/mapserver/WMSServer?", {
                layers: '4,5',
                format: 'image/png',
                transparent: true,
                id: "rdpl",
                crs: L.CRS.EPSG4326,
                version: '1.3.0',
                tileSize: 512
            });

            var overlays = {
                "Opisy": ArcGIS2,
                "Działki": dzialki,
                "Oddziały leśne": oddzialy,
                "Rdpl i nadleśnictwa": rdpl
            }

            L.control.layers(baseLayers, overlays).addTo(shootingMap);

            shootingMap.on('baselayerchange', function (e) {
                if (e.name == "ArcGis" || e.name == 'Orto') {
                    ArcGIS2.addTo(shootingMap)
                } else {
                    ArcGIS2.remove()
                }
            });
        }

        $scope.initMap = function () {
            initMap();
            getCurrentPosition();
        }

        $scope.openPopup = function () {
            getLocationAuthorizationStatus();
        }

        function isLocationAvailable() {
            cordova.plugins.diagnostic.isLocationEnabled(function (enabled) {
                if (enabled) {
                    showLocationPopup();
                } else {
                    alert($translate.instant('AlertAboutGPS'));
                }
            }, function (error) {
                $translate('AnErrorOccured').then($cordovaToast.showLongBottom);
                console.error("The following error occurred: " + error);
            });
        }

        function getLocationAuthorizationStatus() {
            cordova.plugins.diagnostic.getLocationAuthorizationStatus(function (status) {
                switch (status) {
                    case cordova.plugins.diagnostic.permissionStatus.NOT_REQUESTED:
                        console.log("Permission not requested");
                        requestLocationAuthorization();
                        break;
                    case cordova.plugins.diagnostic.permissionStatus.GRANTED:
                        console.log("Permission granted");
                        isLocationAvailable();
                        break;
                    case cordova.plugins.diagnostic.permissionStatus.DENIED:
                        requestLocationAuthorization();
                        console.log("Permission denied");
                        break;
                    case cordova.plugins.diagnostic.permissionStatus.DENIED_ALWAYS:
                        requestLocationAuthorization();
                        console.log("Permission permanently denied");
                        break;
                }
            }, function (error) {
                $translate('ErrorOccurredDownloadingLocationAuthorizationStatus').then($cordovaToast.showLongBottom);
                console.error("The following error occurred: " + error);
            });
        }

        function requestLocationAuthorization() {
            cordova.plugins.diagnostic.requestLocationAuthorization(function (status) {
                switch (status) {
                    case cordova.plugins.diagnostic.permissionStatus.NOT_REQUESTED:
                        console.log("Permission not requested");
                        break;
                    case cordova.plugins.diagnostic.permissionStatus.GRANTED:
                        $translate('PermissionsGranted').then($cordovaToast.showLongBottom);
                        console.log("Permission granted always");
                        isLocationAvailable();
                        break;
                    case cordova.plugins.diagnostic.permissionStatus.DENIED:
                        $translate('PermissionsHaveBeenDenied').then($cordovaToast.showLongBottom);
                        console.log("Permission denied");
                        break;
                    case cordova.plugins.diagnostic.permissionStatus.DENIED_ALWAYS:
                        console.log("Permission permanently denied");
                        break;
                }
            }, function (error) {
                $translate('ErrorGrantingPermissions').then($cordovaToast.showLongBottom);
                console.error(error);
            });
        }

        function showLocationPopup() {
            var myPopup = $ionicPopup.show({
                templateUrl: 'templates/shootingLocation.html',
                title: $translate.instant('MarkLocationOfShooting'),
                scope: $scope,
                buttons: [
                    {
                        text: 'OK',
                        type: 'button-positive',
                        onTap: function (e) {
                            var position = currentPositionMarker.getLatLng();
                            $scope.shooting.latitude = position.lat;
                            $scope.shooting.longitude = position.lng;
                            $ionicLoading.hide();
                        }
                    },
                    {
                        text: $translate.instant('Cancel'),
                        onTap: function (e) {
                            $ionicLoading.hide();
                            return true;
                        }
                    }
                ]
            });
        }

        var currentPositionMarker;

        var currentPositionOptions = {
            timeout: 20000,
            enableHighAccuracy: true,
            maximumAge: 360000,
        };

        function getCurrentPosition() {
            $ionicLoading.show();
            $cordovaGeolocation.getCurrentPosition(currentPositionOptions)
                .then(onSuccessPosition, onErrorPosition);
        };

        function onSuccessPosition(position) {
            var lat = $scope.shooting.latitude == null ? position.coords.latitude : $scope.shooting.latitude;
            var long = $scope.shooting.longitude == null ? position.coords.longitude : $scope.shooting.longitude;
            currentPositionMarker = createMarker(lat, long);
            currentPositionMarker.addTo(shootingMap);
            shootingMap.panTo(currentPositionMarker.getLatLng());
            $ionicLoading.hide();
        }

        function onErrorPosition(err) {
            $translate('RetrievingLocationError').then($cordovaToast.showLongBottom);
            console.log(err);
            $ionicLoading.hide();
        }

        function createMarker(lat, lng) {
            return L.marker([lat, lng], { draggable: true });
        }
        function removeMarker(marker) {
            marker.remove();
        }

        /* Camera module */
        $scope.uploadPhoto = function (huntingId, animalId) {
            var photoUrl = Camera.getPicture(huntingId, animalId).then(function (response) {
                console.log(response);
                $cordovaToast.showLongBottom(response);
            }, function (err) {
                console.log(err);
                $cordovaToast.showLongBottom(err);
            });
        };

        function noLocationPopup() {
            var myPopup = $ionicPopup.show({
                title: $translate.instant('Attention'),
                subTitle: $translate.instant('SanitaryShotLocationNotSet'),
                scope: $scope,
                buttons: [
                    {
                        text: $translate.instant('Yes'),
                        type: 'button-positive',
                        onTap: function (e) {
                            $scope.openPopup();
                        }
                    },
                    {
                        text: $translate.instant('No'),
                        type: 'button-assertive',
                        onTap: function (e) {
                            saveShooting();
                            return true;
                        }
                    }
                ]
            })
        };

        /* adding photo */
        $scope.addPhoto = function (source) {
            Camera.getPicture(source).then(function (response) {
                console.log(response);
                var name = response.split("/");
                $scope.attachment.name = name[name.length - 1];
                $scope.attachment.url = response;
            }, function (err) {
                console.log(err);
                $cordovaToast.showLongBottom(err);
            });
        };

        $scope.showPhotoFormPopup = function () {
            $scope.fileTypes = UtilsService.getFileTypes().then(
                function (response) {
                    $scope.fileTypes = response;
                })

            var myPopup = $ionicPopup.show({
                templateUrl: 'templates/photoFormPopup.html',
                title: $translate.instant('AddingPhoto'),
                scope: $scope,
                buttons: [
                    {
                        text: '<i class="icon ion-camera"></i>',
                        type: 'button-positive',
                        onTap: function (e) {
                            $scope.addPhoto(1);
                            return null;
                        }
                    },
                    {
                        text: '<i class="icon ion-image"></i>',
                        type: 'button-positive',
                        onTap: function (e) {
                            $scope.addPhoto(0);
                            return null;
                        }
                    }
                ]
            });
        };

        $scope.showImageModal = function (photoUrl) {
            $scope.photoUrl = photoUrl;
            $ionicModal.fromTemplateUrl('templates/imagePopover.html', {
                scope: $scope,
                animation: 'slide-in-up'
            }).then(function (modal) {
                $scope.modal = modal;
                $scope.modal.show();
            });
        }

        // Close the modal
        $scope.closeModal = function () {
            $scope.modal.hide();
            $scope.modal.remove()
        };

        function loadClinicalSymptoms() {
            return OpenedHuntService.getClinicalSymptoms()
                .then(function (response) {
                    return $scope.clinicalSymptoms = response;
                })
        }

        loadClinicalSymptoms();

    });
