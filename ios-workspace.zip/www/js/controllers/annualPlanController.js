angular.module('app.controllers')
    .controller('annualPlanCtrl', function ($scope, $http, $state, ApiEndpoint, circuitList, AnnualPlanService, Session, LocalStorage) {
        LOCAL_SETTINGS = LocalStorage.getObject("localSettings");
        $scope.circuitList = circuitList;
        var currentRegion = Session.getCurrentRegion();

        $scope.data = { circuitId: 'region' in LOCAL_SETTINGS && LOCAL_SETTINGS.region[currentRegion[0]] != null ? LOCAL_SETTINGS.region[currentRegion[0]]  : circuitList[0][0] };

        $scope.annualPlan = {
            large: null,
            small: null
        };

        $scope.showAnnualPlan = function () {
            AnnualPlanService.getAnnualPlan($scope.data.circuitId).then(function (result) {
                $scope.annualPlan.large = result.large;
                $scope.annualPlan.small = result.small;
            })
        }

        $scope.showAnnualPlan();
    });