angular.module('app.controllers')
	.controller('regionCtrl', function ($scope, $http, $state, ApiEndpoint, Session, LocalStorage) {

		$scope.regionsList = Session.getRegions();
		$scope.data = {};

		$scope.chooseRegion = function () {
			Session.setCurrentRegion($scope.data.region).then(function () {
				Session.permitsRequest().then(function (result) {
					Session.setPermits(result);
					$state.go('menu.hunterOptions');
				});
			});
		}

		function onDeviceReady() {
			if ($scope.regionsList && $scope.regionsList.length === 1) {
				Session.setCurrentRegion($scope.regionsList[0]).then(function() {
					Session.permitsRequest().then(function(result) {
						Session.setPermits(result);
						$state.go('menu.hunterOptions');
					});
				});
			}
		}

		$scope.$watch('regionsList', function(newVal, oldVal) {
			if (newVal) {
				document.addEventListener("deviceready", onDeviceReady, false);
			}
		});
	});