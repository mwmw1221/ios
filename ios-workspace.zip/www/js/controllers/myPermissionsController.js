angular.module('app.controllers')
    .controller('myPermissionsCtrl', function ($scope, $state, myPermissionsList, years, MyPermissionsService) {
        $scope.years = years;
        $scope.data = { year: null };
        $scope.myPermissionsList = myPermissionsList;

        $scope.loadPermissions = function () {
            MyPermissionsService.getMyPermissionsList($scope.data.year)
                .then(function (result) {
                    $scope.myPermissionsList = result;
                });
        };
    });