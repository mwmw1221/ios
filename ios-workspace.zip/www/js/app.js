// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.services' is found in services.js
// 'starter.controllers' is found in controllers.js
angular.module('app', ['ngCordova', 'ionic', 'pascalprecht.translate', 'ionic-timepicker', 'ionic-ajax-interceptor', 'app.controllers', 'app.routes', 'app.directives', 'app.services', 'base64'])
  .constant('ApiEndpoint', {
    //  HOST: 'https://dzik.torn.com.pl',
    //   url: 'https://dzik.torn.com.pl/palio/html.run?_Instance=kl_devel&_PageID=2813&rh=',
    version: '1.8.4',
    // url: 'https://testkl.pzlow.pl/palio/html.run?_Instance=kl_test&_PageID=2813&rh='
    url: 'https://systemkl.pzlow.pl/palio/html.run?_Instance=kl.pzlow.pl&_PageID=2813&rh=',
    HOST: 'https://systemkl.pzlow.pl'
  })
  .config(['$compileProvider', function($compileProvider) {
    $compileProvider.imgSrcSanitizationWhitelist(/^\s*(https?|file|blob|cdvfile|content|ionic):/);
  }])
  .config([
    '$httpProvider',
    '$base64',
    '$httpParamSerializerProvider',
    '$ionicConfigProvider',
    'AjaxInterceptorProvider',
    'ionicTimePickerProvider',
    '$translateProvider',
    function (
      $httpProvider,
      $base64,
      $httpParamSerializerProvider,
      $ionicConfigProvider,
      AjaxInterceptorProvider,
      ionicTimePickerProvider,
      $translateProvider
    ) {
      document.addEventListener("deviceready", function() {
        if (window.StatusBar) {
          //StatusBar.overlaysWebView(false);
          StatusBar.backgroundColorByHexString("#4f8034"); // ← Twój kolor
          StatusBar.styleLightContent(); // białe ikony
        }
      });      
      $httpProvider.interceptors.push(function($q) {
        return {
          responseError: function(rejection) {
            console.error('HTTP error:', rejection);
            return $q.reject(rejection);
          }
        };
      });
      $httpProvider.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
      $httpProvider.defaults.headers.post["Accept"] = "application/json";
      //  $httpProvider.defaults.headers.common['Authorization'] = 'Basic ' + $base64.encode('jpalio' + ':' + 'Torn');
      // Intercept POST requests, convert to standard form encoding
      $httpProvider.defaults.transformRequest.unshift(function (data, headersGetter) {
        return ($httpParamSerializerProvider.$get())(data);
      });

      AjaxInterceptorProvider.config({
        stateChangeError: false
      });

      $translateProvider
        .useStaticFilesLoader({
          prefix: 'locales/',
          suffix: '.json'
        })
        .registerAvailableLanguageKeys(['en', 'pl', 'de'], {
          'en': 'en', 'en_GB': 'en', 'en_US': 'en',
          'pl': 'pl', 'pl_PL': 'pl', 'pl_Pl': 'pl',
          'de': 'de', 'de_DE': 'de', 'de_De': 'de'
        })
        .preferredLanguage('pl')
        .fallbackLanguage('en')
        .determinePreferredLanguage()
        .useSanitizeValueStrategy('escapeParameters');

      var timePickerObj = {
        inputTime: ((new Date()).getHours() * 60 * 60 + (new Date()).getMinutes() * 60),
        step: 1,
        format: 24,
        setLabel: 'Ustaw',
        closeLabel: "Anuluj"
      };
      ionicTimePickerProvider.configTimePicker(timePickerObj);

      // multiselectProvider.setTemplateUrl('bower_components/ionic-multiselect/dist/templates/item-template.html');
      // multiselectProvider.setModalTemplateUrl('bower_components/ionic-multiselect/dist/templates/modal-template.html');

    }])
  .run(function ($ionicPlatform,
    AjaxInterceptor,
    $state,
    $ionicHistory,
    $rootScope,
    Session,
    $ionicPopup,
    $translate,
    LocalStorage,
    PositionService
  ) {
    $ionicPlatform.ready(function () {
      AjaxInterceptor.run();
      // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
      // for form inputs)
      if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
        cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
        cordova.plugins.Keyboard.disableScroll(true);
      }
      if (window.StatusBar) {
        // org.apache.cordova.statusbar required
        StatusBar.styleDefault();
      }

      var localSettings = LocalStorage.getObject("localSettings");

      if (localSettings.language) {
        $translate.use((localSettings.language).split("-")[0]).then(function (data) {
          console.log("SUCCESS -> " + data);
          $rootScope.language = data;
        }, function (error) {
          console.log("ERROR -> " + error);
        });
      } else if (typeof navigator.globalization !== "undefined") {
        navigator.globalization.getPreferredLanguage(function (language) {
          $translate.use((language.value).split("-")[0]).then(function (data) {
            console.log("SUCCESS -> " + data);
            $rootScope.language = data;
          }, function (error) {
            console.log("ERROR -> " + error);
          });
        }, null);
      }

      var pausedTime;

      cordova.plugins.backgroundMode.setDefaults({ silent: true });

      $ionicPlatform.on("pause", function (event) {
        cordova.plugins.backgroundMode.enable();
        $rootScope.background = true;
        pausedTime = Date.now();
      });

      $ionicPlatform.on("resume", function (event) {
        cordova.plugins.backgroundMode.disable();
        $rootScope.background = false;
        var dateNow = Date.now();
        if (!$rootScope.cameraOn) {
          var milliseconds = dateNow - pausedTime;
          durationInSeconds = Math.floor(milliseconds / 1000);

          var localSettings = LocalStorage.getObject("localSettings");
          var inactiveTime = localSettings.inactivityTime * 60;

          if (durationInSeconds > inactiveTime) {
            Session.logout();
            $state.go("login");
            $ionicHistory.clearCache();
            $ionicHistory.clearHistory();
          }
        }
      });

      if(window.FCMPlugin){
        FCMPlugin.onNotification(function (data) {
        var alertPopup = $ionicPopup.alert({
          title: data.title,
          template: data.content
        });
      });
      }

      $ionicPlatform.registerBackButtonAction(function (event) {
        var state = $state.current.name;
        if (state == "pinPage" || state == "choosingRegion" || state == "login") {
          $ionicHistory.clearCache();
          $ionicHistory.clearHistory();
          navigator.app.exitApp();
        }
        else {
          navigator.app.backHistory();
        }
      }, 100);

      PositionService.getCurrentPosition()
        .then(function (response) {
          console.log(response);
          return response;
        }, function (err) {
          console.log(err);
          return 0;
        });

    });

  })

  /*
    This directive is used to disable the "drag to open" functionality of the Side-Menu
    when you are dragging a Slider component.
  */
  .directive('disableSideMenuDrag', ['$ionicSideMenuDelegate', '$rootScope', function ($ionicSideMenuDelegate, $rootScope) {
    return {
      restrict: "A",
      controller: ['$scope', '$element', '$attrs', function ($scope, $element, $attrs) {

        function stopDrag() {
          $ionicSideMenuDelegate.canDragContent(false);
        }

        function allowDrag() {
          $ionicSideMenuDelegate.canDragContent(true);
        }

        $rootScope.$on('$ionicSlides.slideChangeEnd', allowDrag);
        $element.on('touchstart', stopDrag);
        $element.on('touchend', allowDrag);
        $element.on('mousedown', stopDrag);
        $element.on('mouseup', allowDrag);

      }]
    };
  }])

  /*
    This directive is used to open regular and dynamic href links inside of inappbrowser.
  */
  .directive('hrefInappbrowser', function () {
    return {
      restrict: 'A',
      replace: false,
      transclude: false,
      link: function (scope, element, attrs) {
        var href = attrs['hrefInappbrowser'];

        attrs.$observe('hrefInappbrowser', function (val) {
          href = val;
        });

        element.bind('click', function (event) {

          window.open(href, '_system', 'location=yes');

          event.preventDefault();
          event.stopPropagation();

        });
      }
    };
  });